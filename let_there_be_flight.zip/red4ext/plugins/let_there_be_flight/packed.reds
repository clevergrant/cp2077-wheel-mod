// Let There Be Flight 0.3.17
// Copyright (c) 2023 Jack Humbert. All rights reserved.
// Licensed under the MIT license. See the license.md in the root project for details.
// https://github.com/jackhumbert/let_there_be_flight

// This file was automatically generated on 2025-08-29 21:57:31 UTC

// Audio/FlightAudio.reds

public class FlightAudioUpdate {
  public let speed: Float;
  public let surge: Float;
  public let yawDiff: Float;
  public let lift: Float;
  public let yaw: Float;
  public let pitchDiff: Float;
  public let brake: Float;
  public let inside: Float;
  public let damage: Float;
  public let roll: Float;
  public let pitch: Float;
  public let sway: Float;
  public let scrape: Float;
}


public native class FlightAudio extends IScriptable {
  // defined in red4ext part
  public native func Start(emitterName: String, eventName: String) -> Void;
  public native func StartWithPitch(emitterName: String, eventName: String, pitch: Float) -> Void;
  public native func Play(eventName: String) -> Void;
  public native func Stop(emitterName: String) -> Void;
  // public native func Update(emitterName: String, eventLocation: Vector3, eventForward: Vector3, eventUp: Vector3, volume: Float) -> Void;
  public native func UpdateEvent(emitterName: String, eventMatrix: Matrix, volume: Float, update: ref<FlightAudioUpdate>) -> Void;
  public native func UpdateEventMatrix(emitterName: String, eventMatrix: Matrix) -> Void;
  public native func UpdateListenerMatrix(matrix: Matrix) -> Void;
  public native func UpdateParameter(parameterName: String, value: Float) -> Void;


  public static func Get() -> ref<FlightAudio> {
    return FlightSystem.GetInstance().audio;
  }

  private let m_positionProviders: ref<inkHashMap>;
  private let m_orientationProviders: ref<inkHashMap>;
  private let m_positions: ref<inkHashMap>;
  private let m_orientations: ref<inkHashMap>;
  private let slots: array<CName>;
  private let uiBlackboard: wref<IBlackboard>;
  private let menuCallback: ref<CallbackHandle>;
  public let isInMenu: Bool;

  private let uiGameDataBlackboard: wref<IBlackboard>;
  private let popupCallback: ref<CallbackHandle>;
  public let isPopupShown: Bool;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Audio-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Engine-Volume")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "1.0")
  public let engineVolume: Float = 1.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Audio-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Wind-Volume")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "1.0")
  public let windVolume: Float = 0.6;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Audio-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Warning-Volume")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "1.0")
  public let warningVolume: Float = 0.5;

  public static func Create() -> ref<FlightAudio> {
    let self = new FlightAudio();

    self.m_positionProviders = new inkHashMap();
    self.m_positions = new inkHashMap();
    self.m_orientationProviders = new inkHashMap();
    self.m_orientations = new inkHashMap();
    self.slots = [
      // n"steering_wheel",
      // n"roofhatch",
      // n"glove_box",
      // n"Base",
      // n"dseat_a",
      // n"dseat_b",
      // n"bumper_front_a",
      // n"bumper_front_b",
      // n"mirror_front_left",
      // n"mirror_front_right",
      // n"wheel_front",
      // n"wheel_back",
      // n"wheel_front_left",
      // n"wheel_front_right",
      // n"wheel_back_left",
      // n"wheel_back_right",
      // n"bumper_back",
      n"window_front_left_a",
      n"window_front_right_a"
    ];

    // if IsDefined(self.uiBlackboard) && IsDefined(self.menuCallback) {
    //   self.uiBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().UI_System.IsInMenu, self.menuCallback);
    // }
    // if IsDefined(self.uiGameDataBlackboard) && IsDefined(self.popupCallback) {
    //   self.uiGameDataBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().UIGameData.Popup_IsShown, self.popupCallback);
    // }
    
    LTBF_RegisterListener(self);

    return self;
  }
  
  public cb func Initialize() {
    this.m_positionProviders = new inkHashMap();
    this.m_positions = new inkHashMap();
    this.m_orientationProviders = new inkHashMap();
    this.m_orientations = new inkHashMap();
    this.slots = [
      // n"steering_wheel",
      // n"roofhatch",
      // n"glove_box",
      // n"Base",
      // n"dseat_a",
      // n"dseat_b",
      // n"bumper_front_a",
      // n"bumper_front_b",
      // n"mirror_front_left",
      // n"mirror_front_right",
      // n"wheel_front",
      // n"wheel_back",
      // n"wheel_front_left",
      // n"wheel_front_right",
      // n"wheel_back_left",
      // n"wheel_back_right",
      // n"bumper_back",
      n"window_front_left_a",
      n"window_front_right_a"
    ];
    
    LTBF_RegisterListener(this);
  }

  protected cb func OnWorldAttached() {
    let gameInstance = FlightSystem.GetInstance().gameInstance;
    this.uiBlackboard = GameInstance.GetBlackboardSystem(gameInstance).Get(GetAllBlackboardDefs().UI_System);
    if IsDefined(this.uiBlackboard) {
      if !IsDefined(this.menuCallback) {
        this.menuCallback = this.uiBlackboard.RegisterListenerBool(GetAllBlackboardDefs().UI_System.IsInMenu, this, n"OnIsInMenu");
        this.isInMenu = this.uiBlackboard.GetBool(GetAllBlackboardDefs().UI_System.IsInMenu);
      }
    }

    this.uiGameDataBlackboard = GameInstance.GetBlackboardSystem(gameInstance).Get(GetAllBlackboardDefs().UIGameData);
    if IsDefined(this.uiGameDataBlackboard) {
      if !IsDefined(this.popupCallback) {
        this.popupCallback = this.uiGameDataBlackboard.RegisterListenerBool(GetAllBlackboardDefs().UIGameData.Popup_IsShown, this, n"OnPopupIsShown");
        this.isPopupShown = this.uiGameDataBlackboard.GetBool(GetAllBlackboardDefs().UIGameData.Popup_IsShown);
      }
    }
  }

  protected cb func OnWorldPendingDetach() {
    if IsDefined(this.uiBlackboard) && IsDefined(this.menuCallback) {
      this.uiBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().UI_System.IsInMenu, this.menuCallback);
    }
    if IsDefined(this.uiGameDataBlackboard) && IsDefined(this.popupCallback) {
      this.uiGameDataBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().UIGameData.Popup_IsShown, this.popupCallback);
    }
  }

  protected cb func OnIsInMenu(inMenu: Bool) -> Bool {
    this.isInMenu = inMenu;
  }
  protected cb func OnPopupIsShown(isShown: Bool) -> Bool {
    this.isPopupShown = isShown;
  }

  public func GetGameVolume() -> Float {
    let gameInstance = FlightSystem.GetInstance().gameInstance;
    if this.isInMenu || GameInstance.GetTimeSystem(gameInstance).IsPausedState() ||
      GameInstance.GetTimeSystem(gameInstance).IsTimeDilationActive(n"HubMenu") || 
      GameInstance.GetTimeSystem(gameInstance).IsTimeDilationActive(n"WorldMap")
    {
      return 0.0;
    }
    let volume = 1.0;
    let master = Cast<Float>((GameInstance.GetSettingsSystem(gameInstance).GetVar(n"/audio/volume", n"MasterVolume") as ConfigVarInt).GetValue()) / 100.0;
    let sfx = Cast<Float>((GameInstance.GetSettingsSystem(gameInstance).GetVar(n"/audio/volume", n"SfxVolume") as ConfigVarInt).GetValue()) / 100.0;
    volume *= master * sfx;

    // might need to handle just the scanning system's dilation, and the pause menu
    if GameInstance.GetTimeSystem(gameInstance).IsTimeDilationActive(n"radialMenu") {
      volume *= 0.1;
    }
  
    return volume;
  }

  public func GetEngineVolume() -> Float {
    return this.engineVolume;
  }

  public func GetWindVolume() -> Float {
    return this.windVolume;
  }

  public func GetWarningVolume() -> Float {
    return this.warningVolume;
  }

  public func AddSlotProvider(entity: ref<Entity>, slot: CName) {
    this.SetPositionProvider(slot, IPositionProvider.CreateSlotPositionProvider(entity, slot));
    // this.SetOrientationProvider(slot, IOrientationProvider.CreateEntityOrientationProvider(null, slot, entity));
  }

  public func AddSlotProviders(entity: ref<Entity>) {
    for slot in this.slots {
      this.SetPositionProvider(slot, IPositionProvider.CreateSlotPositionProvider(entity, slot));
      // this.SetOrientationProvider(slot, IOrientationProvider.CreateEntityOrientationProvider(null, slot, entity));
    }
  }
  
  public func UpdateSlotProvider(slot: CName) {
    this.UpdatePosition(slot);
    // this.UpdateOrientation(slot);
  }

  public func UpdateSlotProviders() {
    for slot in this.slots {
      this.UpdateSlotProvider(slot);
    }
  }

  // public func DrawSlotPositions(ui: ref<FlightControllerUI>) {
  //   for slot in this.slots {
  //     let position = this.GetPosition(slot);
  //     ui.DrawMark(position);
  //     ui.DrawText(position, NameToString(slot));
  //   }
  // }

	public func UpdatePosition(name: CName) -> Void {
		let key: Uint64 = TDBID.ToNumber(TDBID.Create(NameToString(name)));
		if this.m_positionProviders.KeyExist(key) {
      let position = new Vector4Wrapper();
		  (this.m_positionProviders.Get(key) as IPositionProvider).CalculatePosition(position.vector);
      if this.m_positions.KeyExist(key) {
        this.m_positions.Set(key, position);
      } else {
        this.m_positions.Insert(key, position);
      }
    }
  }

	// public func UpdateOrientation(name: CName) -> Void {
	// 	let key: Uint64 = TDBID.ToNumber(TDBID.Create(NameToString(name)));
	// 	if this.m_orientationProviders.KeyExist(key) {
  //     let orientation = new OrientationWrapper();
	// 	  (this.m_orientationProviders.Get(key) as EntityOrientationProvider).CalculateOrientation(orientation.quaternion);
  //     if this.m_orientations.KeyExist(key) {
  //       this.m_orientations.Set(key, orientation);
  //     } else {
  //       this.m_orientations.Insert(key, orientation);
  //     }
  //   }
	// }

	public func GetPosition(name: CName) -> Vector4 {
    let key: Uint64 = TDBID.ToNumber(TDBID.Create(NameToString(name)));
		if this.m_positions.KeyExist(key) {
		  return (this.m_positions.Get(key) as Vector4Wrapper).vector;
    } else {
      return Vector4.EmptyVector();
    }
  }

	public func SetPositionProvider(name: CName, positionProvider: ref<IPositionProvider>) -> Void {
		let key: Uint64 = TDBID.ToNumber(TDBID.Create(NameToString(name)));

		if this.m_positionProviders.KeyExist(key) {
			this.m_positionProviders.Set(key, positionProvider);
		} else {
			this.m_positionProviders.Insert(key, positionProvider);
		}
    this.UpdatePosition(name);
	}

	// public func SetOrientationProvider(name: CName, orientationProvider: ref<IOrientationProvider>) -> Void {
	// 	let key: Uint64 = TDBID.ToNumber(TDBID.Create(NameToString(name)));

	// 	if this.m_orientationProviders.KeyExist(key) {
	// 		this.m_orientationProviders.Set(key, orientationProvider);
	// 	} else {
	// 		this.m_orientationProviders.Insert(key, orientationProvider);
	// 	}
  //   this.UpdateOrientation(name);
	// }
}

public class Vector4Wrapper {
  public let vector: Vector4;
  public static func Create(v: Vector4) -> ref<Vector4Wrapper> {
    let vw = new Vector4Wrapper();
    vw.vector = v;
    return vw;
  }
}

public class OrientationWrapper {
  public let quaternion: Quaternion;
}

// Compatibility/ModSettings.reds

@if(ModuleExists("ModSettingsModule")) 
public func LTBF_RegisterListener(listener: ref<IScriptable>) {
  // FlightLog.Info("Registering Listener for type: " + NameToString(listener.GetClassName()));
  ModSettings.RegisterListenerToClass(listener);
}

@if(!ModuleExists("ModSettingsModule")) 
public func LTBF_RegisterListener(listener: ref<IScriptable>) { }

@if(ModuleExists("ModSettingsModule")) 
public func LTBF_UnregisterListener(listener: ref<IScriptable>) {
  // FlightLog.Info("Unregistering Listener for type: " + NameToString(listener.GetClassName()));
  ModSettings.UnregisterListenerToClass(listener);
}

@if(!ModuleExists("ModSettingsModule")) 
public func LTBF_UnregisterListener(listener: ref<IScriptable>) { }

// Extensions/DefaultTransition.reds

@addMethod(DefaultTransition)
public final func CanVehicleEnterFlight(const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
  return (scriptInterface.owner as VehicleObject).CanEnterFlight();
}

// @addMethod(DefaultTransition)
// protected final const func IsVehicleFlying(const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   return scriptInterface.IsVehicleFlying();
// }

@addMethod(DefaultTransition)
protected final func SetIsInFlight(value: Bool) -> Void {
  // stateContext.SetPermanentBoolParameter(n"isInFlight", value, true);
  FlightController.GetInstance().GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsActive, value, true);
}
@addMethod(DefaultTransition)
protected final func IsInFlight() -> Bool {
  // let state = stateContext.GetPermanentBoolParameter(n"isInFlight");
  // return state.value;
  return FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.IsActive);
}

@addMethod(DefaultTransition)
protected final func SetInMountedVehicleCombat(value: Bool) -> Void {
  FlightController.GetInstance().GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.InMountedVehicleCombat, value, true);
}

@addMethod(DefaultTransition)
protected final func IsInMountedVehicleCombat() -> Bool {
  return FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.InMountedVehicleCombat);
}

@addMethod(DefaultTransition)
protected final func IsPlayerAllowedToEnterFlight(const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
  let fc = fs().playerComponent;
  let canActivate = IsDefined(fc) && fc.configuration.CanActivate();

  let tweakID = (scriptInterface.owner as VehicleObject).GetRecordID();
  TDBID.Append(tweakID, TDBID.Create(".canEnterFlight"));
  let flightEnabled = TweakDBInterface.GetBool(tweakID, true);
  
  let blockFlight = StatusEffectSystem.ObjectHasStatusEffectWithTag(scriptInterface.executionOwner, n"VehicleBlockFlight");
  
  return canActivate && flightEnabled && !blockFlight; 
}

@addMethod(DefaultTransition)
protected final const func IsPlayerAllowedToExitFlight(const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
  if StatusEffectSystem.ObjectHasStatusEffectWithTag(scriptInterface.executionOwner, n"VehicleBlockFlightExit") {
    return false;
  };
  return true;
}


// Extensions/InputContextTransitionEvents.reds

@addMethod(InputContextTransitionEvents)
protected final func ShowVehicleFlightInputHints(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  this.ShowInputHint(scriptInterface, n"Flight_Toggle", n"VehicleFlight", LocKeyToString(n"Input-Hint-Disable-Flight"), inkInputHintHoldIndicationType.FromInputConfig, true, 2);
  stateContext.SetPermanentBoolParameter(n"isFlightInputHintDisplayed", true, true);
}

@addMethod(InputContextTransitionEvents)
protected final func RemoveVehicleFlightInputHints(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  if this.m_isGameplayInputHintManagerInitialized {
    this.RemoveInputHint(scriptInterface, n"Flight_Toggle", n"VehicleFlight");
    this.RemoveInputHintsBySource(scriptInterface, n"VehicleFlight");
  };
  stateContext.RemovePermanentBoolParameter(n"isFlightInputHintDisplayed");
}

@wrapMethod(InputContextTransitionEvents)
protected final func RemoveAllInputHints(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  wrappedMethod(stateContext, scriptInterface);
  this.RemoveVehicleFlightInputHints(stateContext, scriptInterface);
}

@wrapMethod(InputContextTransitionEvents)
protected final const func ShowVehicleDriverInputHints(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  wrappedMethod(stateContext, scriptInterface);
  
  let object: wref<GameObject>;
  VehicleComponent.GetVehicle(scriptInterface.owner.GetGame(), scriptInterface.executionOwner, object);
  let vehicle = object as VehicleObject;
  if IsDefined(vehicle) && vehicle.CanEnterFlight() {
    this.ShowInputHint(scriptInterface, n"Flight_Toggle", n"VehicleDriver", LocKeyToString(n"Input-Hint-Enable-Flight"), inkInputHintHoldIndicationType.FromInputConfig, true, 2);
  }
}

@addMethod(InputContextTransitionEvents)
protected final func UpdateVehicleFlightInputHints(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  // let isExitVehicleBlocked: Bool;
  // let isVehicleCombatModeBlocked: Bool;
  if this.ShouldForceRefreshInputHints(stateContext) {
    this.RemoveVehicleFlightInputHints(stateContext, scriptInterface);
    this.m_isGameplayInputHintRefreshRequired = false;
  };
  let object: wref<GameObject>;
  VehicleComponent.GetVehicle(scriptInterface.owner.GetGame(), scriptInterface.executionOwner, object);
  let vehicle = object as VehicleObject;
  if IsDefined(vehicle) && vehicle.CanEnterFlight() {
    if stateContext.GetBoolParameter(n"isFlightInputHintDisplayed", true) {
      // isVehicleCombatModeBlocked = this.IsVehicleBlockingCombat(scriptInterface) || this.IsEmptyHandsForced(stateContext, scriptInterface);
      // isExitVehicleBlocked = this.IsExitVehicleBlocked(scriptInterface);
      // if NotEquals(isVehicleCombatModeBlocked, stateContext.GetBoolParameter(n"IsVehicleCombatModeBlocked", true)) {
      //   this.ShowVehicleDrawWeaponInputHint(stateContext, scriptInterface);
      // };
      // if NotEquals(isExitVehicleBlocked, stateContext.GetBoolParameter(n"IsExitVehicleBlocked", true)) {
      //   this.ShowVehicleExitInputHint(stateContext, scriptInterface, n"VehicleFlight");
      // };
    } else {
      this.ShowVehicleFlightInputHints(stateContext, scriptInterface);
    }
  }
}

// Extensions/InputHintManagerGameController.reds

@if(!ModuleExists("Codeware"))
public native class inkHudEntryInfo extends inkUserData {
  public native let size: Vector2;
  public native let offset: Vector2;

  // public native func SetSize(size: Vector2) -> Void;
}

@addMethod(InputHintManagerGameController)
public func LTBF_ResizeHudEntry() -> Void {
  let hudEntry = this.GetRootWidget().GetUserData(n"inkHudEntryInfo") as inkHudEntryInfo;
  hudEntry.size = new Vector2(1024, 1024); // 1027, 680
  hudEntry.offset = new Vector2(-724.0, -974.0); // -724, -630
}

@if(!ModuleExists("LimitedHudConfig"))
@addMethod(InputHintManagerGameController)
protected cb func OnInitialize() -> Bool {
  this.LTBF_ResizeHudEntry();
}

// @if(ModuleExists("LimitedHudConfig"))
// @wrapMethod(InputHintManagerGameController)
// protected cb func OnInitialize() -> Bool {
//  this.LTBF_ResizeHudEntry();
//  return wrappedMethod();
// }


// Extensions/MeshComponent.reds

// Entity

// @addField(Entity)
// @runtimeProperty("offset", "0x50")
// public native let currentAppearance: CName;

@addField(Entity)
@runtimeProperty("offset", "0x138")
public native let entityTags: array<CName>;

// @addMethod(Entity)
// public native func AddComponent(component: ref<IComponent>);

@addMethod(Entity)
public native func AddSlot(boneName: CName, slotName: CName, relativePosition: Vector3, relativeRotation: Quaternion);

// IComponent

@addField(IComponent)
@runtimeProperty("offset", "0x40")
public native let name: CName;

@addField(IComponent)
@runtimeProperty("offset", "0x48")
public native let appearanceName: CName;

// IPlacedComponent

// bindName is component name - can be SlotComponent like vehicle_slots
@addMethod(IPlacedComponent)
public native func SetParentTransform(bindName: CName, slotName: CName);

// MeshComponent

@addMethod(MeshComponent)
public native func SetMesh(mesh: ResRef);

@addField(MeshComponent)
@runtimeProperty("offset", "0x178")
public native let visualScale: Vector3;

@if(!ModuleExists("Codeware"))
enum ERenderObjectType {
    ROT_Static = 0,
    ROT_Terrain = 1,
    ROT_Road = 2,
    ROT_CustomCharacter1 = 12,
    ROT_CustomCharacter2 = 13,
    ROT_CustomCharacter3 = 14,
    ROT_MainPlayer = 15,
    ROT_NoAO = 16,
    ROT_NoLighting = 17,
    ROT_NoTXAA = 18,
    ROT_Skinned = 20,
    ROT_Character = 21,
    ROT_Foliage = 22,
    ROT_Grass = 23,
    ROT_Vehicle = 24,
    ROT_Weapon = 25,
    ROT_Particle = 26,
    ROT_Enemy = 27,
}

@addField(MeshComponent)
@runtimeProperty("offset", "0x188")
public native let objectTypeID: ERenderObjectType;

@addField(MeshComponent)
@runtimeProperty("offset", "0x190")
public native let meshApperance: CName;

@addField(MeshComponent)
@runtimeProperty("offset", "0x198")
public native let chunkMask: Uint64;

@addField(MeshComponent)
@runtimeProperty("offset", "0x1A4")
public native let motionBlurScale: Float;

@if(!ModuleExists("Codeware"))
enum entMeshComponentLODMode {
    AlwaysVisible = 0,
    Appearance = 1,
    AppearanceProxy = 2,
}

@addField(MeshComponent)
@runtimeProperty("offset", "0x1A8")
public native let LODMode: entMeshComponentLODMode;

@addField(MeshComponent)
@runtimeProperty("offset", "0x1AB")
public native let order: Uint8;

// @addField(MeshComponent)
// @runtimeProperty("offset", "0x1AC")
// public native let castShadows: Bool;

// @addField(MeshComponent)
// @runtimeProperty("offset", "0x1AD")
// public native let castLocalShadows: Bool;

// PhysicalMeshComponent

@addField(PhysicalMeshComponent)
@runtimeProperty("offset", "0x228")
public native let visibilityAnimationParam: CName;

@addField(PhysicalMeshComponent)
@runtimeProperty("offset", "0x23A")
public native let startInactive: Bool;


// Extensions/VehicleComponent.reds

@replaceMethod(VehicleComponent)
protected cb func OnVehicleWaterEvent(evt: ref<VehicleWaterEvent>) -> Bool {
  if evt.isInWater  && !this.GetPS().GetIsSubmerged() {
    if !Equals(GetMountedVehicle(FlightController.GetInstance().player), this.GetVehicle()) && FlightController.GetInstance().IsActive() {
      this.BreakAllDamageStageFX(true);
      // this.DestroyVehicle();
      this.DestroyRandomWindow();
      this.ApplyVehicleDOT(n"high");
    }
    GameObjectEffectHelper.BreakEffectLoopEvent(this.GetVehicle(), n"fire");
  }
  ScriptedPuppet.ReevaluateOxygenConsumption(this.m_mountedPlayer);
  if FlightController.GetInstance().IsActive() {
    let playerPuppet = GameInstance.GetPlayerSystem(this.GetVehicle().GetGame()).GetLocalPlayerMainGameObject() as PlayerPuppet;
    let playerStateMachineBlackboard = GameInstance.GetBlackboardSystem(this.GetVehicle().GetGame()).GetLocalInstanced(playerPuppet.GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
    playerStateMachineBlackboard.SetInt(GetAllBlackboardDefs().PlayerStateMachine.Swimming, EnumInt(gamePSMSwimming.Surface), true);
  }
}

@wrapMethod(VehicleComponent)
private final func ExplodeVehicle(instigator: wref<GameObject>) -> Void {
  wrappedMethod(instigator);
  let flight = this.GetVehicle().GetFlightComponent();
  if IsDefined(flight) {
    flight.HandleExplosion();
  }
}

// @wrapMethod(VehicleComponent) 
// protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
//   wrappedMethod(action, consumer);
//   let actionName: CName = ListenerAction.GetName(action);
//   let value: Float = ListenerAction.GetValue(action);
//   if Equals(actionName, n"Choice1") && ListenerAction.IsButtonJustReleased(action) {
//     FlightLog.Info("Attempting to repair vehicle");
//     this.RepairVehicle();
//     let player: ref<PlayerPuppet> = GetPlayer(this.GetVehicle().GetGame());
//     let uiSystem: ref<UISystem> = GameInstance.GetUISystem(this.GetVehicle().GetGame());
//     player.UnregisterInputListener(this, n"Choice1");
//     uiSystem.QueueEvent(FlightController.HideHintFromSource(n"RepairVehicle"));
//   }
// }


// requires vehicle to be off to control? also makes a sound, which is nice
// @replaceMethod(VehicleComponent)
// private final func SetupThrusterFX() -> Void {
//   let toggle: Bool = (this.GetPS() as VehicleComponentPS).GetThrusterState();
//   if toggle || (Equals(FlightController.GetInstance().GetVehicle(), this.GetVehicle()) && FlightController.GetInstance().GetThrusterState()) {
//     GameObjectEffectHelper.StartEffectEvent(this.GetVehicle(), n"thrusters", true);
//   } else {
//     GameObjectEffectHelper.BreakEffectLoopEvent(this.GetVehicle(), n"thrusters");
//   };
// }

// Extensions/VehicleEventsTransition.reds

@replaceMethod(VehicleEventsTransition)
protected final func HandleCameraInput(scriptInterface: ref<StateGameScriptInterface>) -> Void {
  if scriptInterface.IsActionJustPressed(n"ToggleVehCamera") && !this.IsVehicleCameraChangeBlocked(scriptInterface) && !FlightController.GetInstance().active {
    this.RequestToggleVehicleCamera(scriptInterface);
  };
}

// @wrapMethod(vehicleVisualCustomizationHotkeyController)
// protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
//   let isVehicleCustomizationAvailable: Bool = this.m_player.GetMountedVehicle().GetVehicleComponent().GetIsVehicleVisualCustomizationEnabled();
//   if Equals(ListenerAction.GetName(action), n"VehicleVisualCustomization") {
//     if VehicleSystem.IsPlayerInVehicle(this.GetPlayer().GetGame()) && isVehicleCustomizationAvailable {
//       return true;
//     };
//     if Equals(ListenerAction.GetType(action), gameinputActionType.BUTTON_HOLD_COMPLETE) {
//       if IsDefined(this.m_animationProxy) && this.m_animationProxy.IsPlaying() {
//         this.m_animationProxy.GotoEndAndStop(true);
//         this.m_animationProxy = null;
//       };
//       this.m_animationProxy = this.PlayLibraryAnimation(n"onFailUse_carMod");
//     };
//   };
// }

// not the right place
// @replaceMethod(VehicleTransition)
// protected final func ResetVehicleCamera(scriptInterface: ref<StateGameScriptInterface>) -> Void {
//   // let camEvent: ref<vehicleCameraResetEvent> = new vehicleCameraResetEvent();
//   // scriptInterface.executionOwner.QueueEvent(camEvent);
//   return;
// }


// Extensions/VehicleObject.reds

@addField(VehicleObject)
private let m_flightComponent: ref<FlightComponent>;

@wrapMethod(VehicleObject)
protected cb func OnRequestComponents(ri: EntityRequestComponentsInterface) -> Bool {
  if this.CanEnterFlight() {
    EntityRequestComponentsInterface.RequestComponent(ri, n"flightComponent", n"FlightComponent", true);
    // EntityRequestComponentsInterface.RequestComponent(ri, n"flight_ui", n"worlduiWidgetComponent", true);
    // EntityRequestComponentsInterface.RequestComponent(ri, n"flight_ui_info", n"worlduiWidgetComponent", true);
  }
  wrappedMethod(ri);
}

@wrapMethod(VehicleObject)
protected cb func OnTakeControl(ri: EntityResolveComponentsInterface) -> Bool {
  if this.CanEnterFlight() {
    //FlightLog.Info("[VehicleObject] OnTakeControl: " + this.GetDisplayName());
    this.m_flightComponent = EntityResolveComponentsInterface.GetComponent(ri, n"flightComponent") as FlightComponent;
    // this.m_flightComponent.ui = EntityResolveComponentsInterface.GetComponent(ri, n"flight_ui") as worlduiWidgetComponent;
    // this.m_flightComponent.ui_info = EntityResolveComponentsInterface.GetComponent(ri, n"flight_ui_info") as worlduiWidgetComponent;
    // this.m_flightComponent.Toggle(false);
  }
  wrappedMethod(ri);
}

@addMethod(VehicleObject)
public func GetFlightComponent() -> ref<FlightComponent> {
  return this.m_flightComponent;
}

@addMethod(VehicleObject)
public func CanEnterFlight() -> Bool {
  let allVehiclesEnabled = TweakDBInterface.GetBool(t"player.vehicle.canEnterFlight", true);

  let tweakID = this.GetRecordID();
  TDBID.Append(tweakID, t".canEnterFlight");

  let thisVehicleEnabled = TweakDBInterface.GetBool(tweakID, false);
  let thisVehicleDisabled = !TweakDBInterface.GetBool(tweakID, true);

  return (allVehiclesEnabled || thisVehicleEnabled) && !thisVehicleDisabled;
}

@addMethod(VehicleObject)
public func ToggleFlightComponent(state: Bool) -> Void {
  if IsDefined(this.m_flightComponent) {
    this.m_flightComponent.Toggle(state);
  }
}

@addMethod(VehicleObject)
public func GetLocalToWorld() -> Matrix {
  return WorldTransform.ToMatrix(this.GetWorldTransform());
}

@addMethod(VehicleObject)
public func GetCName(const varName: script_ref<String>, opt defaultValue: CName) -> CName {
  let globalValue = TweakDBInterface.GetCName(TDBID.Create("player.vehicle." + varName), defaultValue);

  let tweak = this.GetRecordID();
  TDBID.Append(tweak, TDBID.Create("." + varName));
  return TweakDBInterface.GetCName(tweak, globalValue);
}

@addMethod(VehicleObject)
public func GetResRef(const varName: script_ref<String>, opt defaultValue: ResRef) -> ResRef {
  let globalValue = TweakDBInterface.GetResRef(TDBID.Create("player.vehicle." + varName), defaultValue);

  let tweak = this.GetRecordID();
  TDBID.Append(tweak, TDBID.Create("." + varName));
  return TweakDBInterface.GetResRef(tweak, globalValue);
}

// @addField(VehicleObject)
// public let chassis: ref<vehicleChassisComponent>;

@addField(VehicleObject)
@runtimeProperty("offset", "0x25C")
public native let isOnGround: Bool;

@addField(VehicleObject)
@runtimeProperty("offset", "0x268")
public native let acceleration: Float;

@addField(VehicleObject)
@runtimeProperty("offset", "0x26C")
public native let deceleration: Float;

@addField(VehicleObject)
@runtimeProperty("offset", "0x270")
public native let handbrake: Float;

// @addField(VehicleObject)
// public native let turnX: Float;

// @addField(VehicleObject)
// public native let turnX2: Float;

// @addField(VehicleObject)
// public native let turnX3: Float;

@addField(VehicleObject)
@runtimeProperty("offset", "0x699")
public native let ignoreImpulses: Bool;

@addField(VehicleObject)
@runtimeProperty("offset", "0x27C")
public native let turnX: Float;

@addField(VehicleObject)
@runtimeProperty("offset", "0xB04")
public native let tracePosition: Vector3;

@addMethod(VehicleObject)
public native func EndActions() -> Void;

@addMethod(VehicleObject)
public native func HasGravity() -> Bool;

@addMethod(VehicleObject)
public native func UsesInertiaTensor() -> Bool;

@addMethod(VehicleObject)
public native func GetInertiaTensor() -> Matrix;

// @addMethod(VehicleObject)
// public native func GetWorldInertiaTensor() -> Matrix;

@addMethod(VehicleObject)
public native func GetMomentOfInertiaScale() -> Vector3;

@addMethod(VehicleObject)
public native func GetCenterOfMass() -> Vector3;

@addMethod(VehicleObject)
public native func EnableGravity(enabled: Bool) -> Void;

@addMethod(VehicleObject)
public native func GetAngularVelocity() -> Vector3;

@addMethod(VehicleObject)
public native func TurnOffAirControl() -> Bool;

// public native class vehicleFlightHelper extends IScriptable {
//     public native let force: Vector4;
//     public native let torque: Vector4;
// }

// @addMethod(VehicleObject)
// public native func AddFlightHelper() -> ref<vehicleFlightHelper>;

@addMethod(VehicleObject)
public native func GetComponentsUsingSlot(slotName: CName) -> array<ref<IComponent>>;

@addMethod(VehicleObject)
public native func GetWeaponPlaceholderOrientation(index: Int32) -> Quaternion;

@addMethod(VehicleObject)
public native func GetWeapons() -> array<ref<WeaponObject>>;

@addMethod(VehicleObject)
public native func ForceEnablePhysics() -> Void;

@addMethod(WheeledObject)
public native func GetDampedSpringForce(wheelIndex: Int32) -> Float;

@addField(VehicleObject)
public let bouncy: Bool;

// working
// @addMethod(VehicleObject)
// protected cb func OnPhysicalCollision(evt: ref<PhysicalCollisionEvent>) -> Bool {
//   // FlightLog.Info("[VehicleObject] OnPhysicalCollision");
//   let vehicle = evt.otherEntity as VehicleObject;
//   if IsDefined(vehicle) {
//     let gameInstance: GameInstance = this.GetGame();
//     let player: ref<PlayerPuppet> = GetPlayer(gameInstance);
//     let isPlayerMounted = VehicleComponent.IsMountedToProvidedVehicle(gameInstance, player.GetEntityID(), vehicle);
//     if !isPlayerMounted && this.bouncy {
//       let impulseEvent: ref<PhysicalImpulseEvent> = new PhysicalImpulseEvent();
//       impulseEvent.radius = 1.0;
//       impulseEvent.worldPosition = Vector4.Vector4To3(evt.worldPosition);
//       impulseEvent.worldImpulse = new Vector3(0.0, 0.0, 10000.0);
//       vehicle.QueueEvent(impulseEvent);
//     }
//   }
// }

// @wrapMethod(VehicleObject)
// public final func IsOnPavement() -> Bool {
//   return wrappedMethod() || FlightController.GetInstance().IsActive();
// }

// @wrapMethod(VehicleObject)
// protected cb func OnLookedAtEvent(evt: ref<LookedAtEvent>) -> Bool {
//   wrappedMethod(evt);
//   if this.IsDestroyed() && this.IsCurrentlyScanned() {
//     let player: ref<PlayerPuppet> = GetPlayer(this.GetGame());
//     let uiSystem: ref<UISystem> = GameInstance.GetUISystem(this.GetGame());
//     if evt.isLookedAt {
//         player.RegisterInputListener(this.m_vehicleComponent, n"Choice1");
//         uiSystem.QueueEvent(FlightController.ShowHintHelper("Repair Vehicle", n"Choice1", n"RepairVehicle"));
//     } else {
//         player.UnregisterInputListener(this.m_vehicleComponent, n"Choice1");
//         uiSystem.QueueEvent(FlightController.HideHintFromSource(n"RepairVehicle"));
//     }
//   }
// } 

// @addMethod(VehicleObject)
// public const func IsQuickHackAble() -> Bool {
//   return true;
// }

// @addMethod(VehicleObject)
// public const func IsQuickHacksExposed() -> Bool {
//   return true;
// }


@addMethod(VehicleObject)
public native func ResetQuestEnforceTransform() -> Void;

// Extensions/blackboardDefinitions.reds

public class VehicleFlightDef extends BlackboardDefinition {

  public let IsActive: BlackboardID_Bool;
  public let Mode: BlackboardID_Int;
  public let IsUIActive: BlackboardID_Bool;
  public let Orientation: BlackboardID_Quat;
  public let Force: BlackboardID_Vector4;
  public let Torque: BlackboardID_Vector4;
  public let Position: BlackboardID_Vector4;
  public let Pitch: BlackboardID_Float;
  public let Roll: BlackboardID_Float;
  public let InMountedVehicleCombat: BlackboardID_Bool;
  public let ExitedWhileActive: BlackboardID_Bool;

  public const func AutoCreateInSystem() -> Bool {
    return true;
  }
}

@addField(AllBlackboardDefinitions)
public let VehicleFlight: ref<VehicleFlightDef>;

@addField(PlayerStateMachineDef)
public let VehicleFlight: BlackboardID_Int;

// @addField(VehicleDef)
// public let IsFlightActive: BlackboardID_Bool;

// @addField(VehicleDef)
// public let FlightMode: BlackboardID_Int;

// @addField(VehicleDef)
// public let IsFlightUIActive: BlackboardID_Bool;

// @addField(VehicleDef)
// public let Orientation: BlackboardID_Quat;

// @addField(VehicleDef)
// public let Pitch: BlackboardID_Float;

// @addField(VehicleDef)
// public let Force: BlackboardID_Vector4;

// @addField(VehicleDef)
// public let Torque: BlackboardID_Vector4;

// @addField(VehicleDef)
// public let Position: BlackboardID_Vector4;

// Extensions/hudCarController.reds

// @wrapMethod(hudCarController)
// private final func Reset() -> Void {
//   wrappedMethod();
//   this.OnFlightActiveChanged(false);
// }

// @addField(hudCarController)
// private let m_flightActiveBBConnectionId: ref<CallbackHandle>;

// @addField(hudCarController)
// private let m_flightModeBBConnectionId: ref<CallbackHandle>;

// @addField(hudCarController)
// private let m_flightControllerStatus: wref<inkText>;

// @wrapMethod(hudCarController)
// private final func RegisterToVehicle(register: Bool) -> Void {
//   wrappedMethod(register);
  // let flightControllerBlackboard: wref<IBlackboard>;
  // let vehicle: ref<VehicleObject> = this.m_activeVehicle;
  // if vehicle == null {
  //   return;
  // };
  // flightControllerBlackboard = FlightController.GetInstance().GetBlackboard();
  // if IsDefined(flightControllerBlackboard) {
  //   if register {
  //     // GetRootWidget() returns root widget of base type inkWidget
  //     // GetRootCompoundWidget() returns root widget casted to inkCompoundWidget
  //     if !IsDefined(this.m_flightControllerStatus) {
  //       this.m_flightControllerStatus = FlightController.HUDStatusSetup(this.GetRootCompoundWidget());
  //     }
  //     this.m_flightActiveBBConnectionId = flightControllerBlackboard.RegisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsActive, this, n"OnFlightActiveChanged");
  //     this.m_flightModeBBConnectionId = flightControllerBlackboard.RegisterListenerInt(GetAllBlackboardDefs().VehicleFlight.Mode, this, n"OnFlightModeChanged");
  //     this.FlightActiveChanged(FlightController.GetInstance().active);
  //   } else {
  //     flightControllerBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsActive, this.m_flightActiveBBConnectionId);
  //     flightControllerBlackboard.UnregisterListenerInt(GetAllBlackboardDefs().VehicleFlight.Mode, this.m_flightModeBBConnectionId);
  //   };
  // };
// }

// @addMethod(hudCarController)
// protected cb func OnFlightActiveChanged(active: Bool) -> Bool {
//   if !IsDefined(this.m_flightControllerStatus) {
//     this.m_flightControllerStatus = FlightController.HUDStatusSetup(this.GetRootCompoundWidget());
//   }
//   this.FlightActiveChanged(active);
// }

// @addMethod(hudCarController)
// protected func FlightActiveChanged(active: Bool) -> Void {
//   if active {
//     this.m_flightControllerStatus.SetText("Flight Active: " + fs().playerComponent.GetFlightMode().GetDescription());
//   } else {
//     this.m_flightControllerStatus.SetText("Flight Available");
//   }
// }

// @addMethod(hudCarController)
// protected cb func OnFlightModeChanged(mode: Int32) -> Bool {
//   this.m_flightControllerStatus.SetText("Flight Active: " + fs().playerComponent.GetFlightMode().GetDescription());
// }

@wrapMethod(hudCarController)
protected cb func OnSpeedValueChanged(speedValue: Float) -> Bool {
  // speedValue = AbsF(speedValue);
  // let multiplier: Float = GameInstance.GetStatsDataSystem(this.m_activeVehicle.GetGame()).GetValueFromCurve(n"vehicle_ui", speedValue, n"speed_to_multiplier");
  // inkTextRef.SetText(this.m_SpeedValue, IntToString(RoundMath(speedValue)));

  let fc = fs().playerComponent;
  if fc.active {
    let speed = AbsF(fc.stats.d_speed);
    let multiplier: Float = GameInstance.GetStatsDataSystem(this.m_activeVehicle.GetGame()).GetValueFromCurve(n"vehicle_ui", speed, n"speed_to_multiplier");
    inkTextRef.SetText(this.m_SpeedValue, IntToString(RoundMath(speed * multiplier)));
    this.drawRPMGaugeFull(AbsF(fc.surge) * 5000.0);
  } else {
    wrappedMethod(speedValue);
  }
}
@wrapMethod(hudCarController)
protected cb func OnRpmValueChanged(rpmValue: Float) -> Bool {
  let fc = fs().playerComponent;
  if !fc.active {
    wrappedMethod(rpmValue);
  }
}

// Extensions/inkBorder.reds

@addField(inkBorder)
native let thickness: Float;

@addMethod(inkBorder)
public func GetThickness() -> Float{
    return this.thickness;
}


// Extensions/inkMask.reds

@if(!ModuleExists("Codeware"))
enum inkMaskDataSource {
    TextureAtlas = 0,
    DynamicTexture = 1
}

// public native class inkTextureAtlas {

// }

// @addField(inkMask)
// native let textureAtlas: inkTextureAtlas;
// @addField(inkMask)
// native let texturePart: CName;
@addField(inkMask)
native let dynamicTextureMask: CName;

@addMethod(inkMask)
func SetDynamicTextureMask(value: CName) {
    this.dynamicTextureMask = value;
}

@addField(inkMask)
native let dataSource: inkMaskDataSource;

@if(!ModuleExists("Codeware"))
@addMethod(inkMask)
func SetDataSource(value: inkMaskDataSource) {
    this.dataSource = value;
}

@addField(inkMask)
let useNineSliceScale: Bool;

@addField(inkMask)
let nineSliceScale: inkMargin;

@addMethod(inkMask)
public func UsesNineSliceScale() -> Bool {
	return this.useNineSliceScale;
}

@addMethod(inkMask)
public func SetNineSliceScale(enable: Bool) -> Void {
	this.useNineSliceScale = enable;
}

@addMethod(inkMask)
public func GetNineSliceGrid() -> inkMargin {
	return this.nineSliceScale;
}

@addMethod(inkMask)
public func SetNineSliceGrid(grid: inkMargin) -> Void {
	this.nineSliceScale = grid;
}

@addField(inkMask)
native let invertMask: Bool;

@addMethod(inkMask)
func SetInvertMask(value: Bool) {
    this.invertMask = value;
}

@addField(inkMask)
native let maskTransparency: Float;

@addMethod(inkMask)
func SetMaskTransparency(value: Float) {
    this.maskTransparency = value;
}


// @addMethod(inkMask)
// func SetAtlasResource(textureAtlas: ResRef) {
//     this.textureAtlas = textureAtlas;
// }
@addMethod(inkMask)
public native func SetAtlasResource(atlasResourcePath: ResRef) -> Bool;


// Extensions/inkQuadShape.reds

// public native class inkQuadShape extends inkBaseShapeWidget {
//     // native let textureAtlas: ResRef;
//     native let texturePart: CName;
//     native let vertexList: array<Vector2>;

//     // public func GetTextureAtlas() -> ResRef {
//     //     return this.textureAtlas;
//     // }
//     public func GetTexturePart() -> CName {
//         return this.texturePart;
//     }
//     public func GetVertexList() -> array<Vector2> {
//         return this.vertexList;
//     }
// }

// Extensions/inkWidget.reds

@addMethod(inkWidget)
public native func CreateEffect(typeName: CName, effectName: CName) -> Void;

@if(!ModuleExists("Codeware"))
enum inkEBlurDimension
{
   Horizontal = 0,
   Vertical = 1
}

@addMethod(inkWidget)
public native func SetBlurDimension(effectName: CName, blurDimension : inkEBlurDimension) -> Bool;


// Extensions/vehicleTPPCameraComponent.reds

// public native class vehicleChassisComponent extends IPlacedComponent {
//     public native func GetComOffset() -> Transform;
// }

// native class vehicleTPPCameraComponent extends CameraComponent {
//     // public native let isInAir: Bool;
//     public native let drivingDirectionCompensationAngleSmooth: Float;
//     public native let drivingDirectionCompensationSpeedCoef: Float;
//     public native let lockedCamera: Bool;
//     public native let initialTransform: WorldTransform;
//     public native let pitch: Float;
//     public native let yaw: Float;
//     // public native let pitchDelta: Float; // positive moves camera down
//     // public native let yawDelta: Float; // positive moves camera right
//     // public native let chassis: ref<vehicleChassisComponent>;
// }

// @addMethod(vehicleChassisComponent)
// protected cb func OnRequestComponents(ri: EntityRequestComponentsInterface) -> Bool {
//     super.OnRequestComponents(ri);
//     EntityRequestComponentsInterface.RequestComponent(ri, n"Chassis", n"vehicleChassisComponent", false);
// }


// public native class vehicleDriveToPointEvent extends Event {
//     public native let targetPos: Vector3;
//     public native let useTraffic: Bool;
//     public native let speedInTraffic: Float;
// }

// public importonly class EffectSpawnerComponent extends IVisualComponent {
//     public native func AddEffect() -> Void;
// }


// @addField(ColliderComponent)
// public native let mass: Float;

// @addField(ColliderComponent)
// public native let massOverride: Float;

// @addField(ColliderComponent)
// public native let inertia: Vector3;

// @addField(ColliderComponent)
// public native let comOffset: Transform;

// public native class exEntitySpawner {
//     public native static func Spawn(entityPath: ResRef, worldTransform: WorldTransform, opt appearance: CName, opt recordID: TweakDBID) -> EntityID;
//     public native static func SpawnRecord(recordID: TweakDBID, worldTransform: WorldTransform, opt appearance: CName) -> EntityID;
//     public native static func Despawn(entity: ref<Entity>) -> Void;
// }

// @addField(MappinSystem)
// public native let worldMappins: Array<Ptr<>>;

// @addField(entCameraComponent)
// native let fov: Float;

// @addField(entCameraComponent)
// native let zoom: Float;

// @addField(entCameraComponent)
// native let nearPlaneOverride: Float;

// @addField(entCameraComponent)
// native let farPlaneOverride: Float;

// @addField(entCameraComponent)
// native let motionBlurScale: Float;

//FindVehicleCameraManager


// @addMethod(FxSystem)
// public final native func SpawnEffect(resource: ResRef, transform: WorldTransform, opt ignoreTimeDilation: Bool) -> ref<FxInstance>;

// @addField(FxResource)
// public native let effect: ResRef;

// @addMethod(Entity)
// public native func AddComponent(component: ref<IComponent>) -> Bool;

// @addMethod(Entity)
// public native func AddWorldWidgetComponent() -> Bool;

// @addMethod(IPlacedComponent)
// public native func UpdateHardTransformBinding(bindName: CName, slotName: CName) -> Bool;

// Extensions/weaponRoster.reds

// @addField(weaponRosterGameController)
// let m_FlightStateBlackboardId: ref<CallbackHandle>;

// @wrapMethod(weaponRosterGameController)
// private final func RegisterBB() -> Void {
//   wrappedMethod();
//   let flightBB = FlightController.GetInstance().GetBlackboard();
//   if IsDefined(flightBB) {
//     if !IsDefined(this.m_FlightStateBlackboardId) {
//       this.m_FlightStateBlackboardId = flightBB.RegisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsActive, this, n"OnFlightActivate");
//     }
//   }
// }

// @wrapMethod(weaponRosterGameController)
// private final func UnregisterBB() -> Void {
//   wrappedMethod();
//   let flightBB = FlightController.GetInstance().GetBlackboard();
//   if IsDefined(flightBB) {
//     if IsDefined(this.m_FlightStateBlackboardId) {
//        flightBB.UnregisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsActive, this.m_FlightStateBlackboardId);
//     }
//   }
// }

// @addMethod(weaponRosterGameController)
// private cb func OnFlightActivate() -> Void {
//   this.PlayFold();
// }

// Flight/Configuration/BikeFlightConfiguration.reds

public class BikeFlightConfiguration extends IFlightConfiguration {
  public let frontChild: ref<MeshComponent>;
  public let backChild: ref<MeshComponent>;

  public func OnSetup(vehicle: ref<VehicleObject>) {
    super.OnSetup(vehicle);

    this.flightCameraOffset = new Vector3(0.0, 1.0, 0.5);

    ArrayPush(this.thrusters, new FlightThrusterFront().Create(vehicle, this.CreateMesh(vehicle)));
    ArrayPush(this.thrusters, new FlightThrusterBack().Create(vehicle, this.CreateMesh(vehicle)));

    // if (!Equals(this.type, FlightVehicleType.Corpo)) {
    //   this.frontChild = CreateNomadThruster();
    //   this.frontChild.name = n"FrontThrusterChild";
    //   this.frontChild.visualScale = new Vector3(0.0, 0.0, 0.0);
    //   // this.frontChild.SetLocalPosition(new Vector4(0.0, 0.0, -0.2, 1.0));
    //   this.frontChild.SetLocalOrientation(new Quaternion(0.0, 0.0, 0.707, -0.707));
    //   this.frontChild.SetParentTransform(this.thrusters[0].meshComponent.name, n"None");
    //   // vehicle.AddComponent(this.frontChild);

    //   this.backChild = CreateNomadThruster();
    //   this.backChild.name = n"BackThrusterChild";
    //   this.backChild.visualScale = new Vector3(0.0, 0.0, 0.0);
    //   // this.backChild.SetLocalPosition(new Vector4(0.0, 0.0, -0.2, 1.0));
    //   this.backChild.SetLocalOrientation(new Quaternion(0.0, 0.0, -0.707, -0.707));
    //   this.backChild.SetParentTransform(this.thrusters[1].meshComponent.name, n"None");
    //   // vehicle.AddComponent(this.backChild);
    // }

    this.thrusters[0].hasRetroThruster = false;
    this.thrusters[1].hasRetroThruster = false;

    for thruster in this.thrusters {
      ArrayPush(thruster.fxs, new RegularFlightThrusterFX().Create(thruster));
      // vehicle.AddComponent(thruster.meshComponent);
      thruster.OnSetup(this.component);
    }
  }

  public func OnActivation() {
    super.OnActivation();
    this.frontChild.visualScale = new Vector3(1.0, 1.0, 1.0);
    this.backChild.visualScale = new Vector3(1.0, 1.0, 1.0);
  }

  public func OnDeactivation() {
    this.frontChild.visualScale = new Vector3(0.0, 0.0, 0.0);
    this.backChild.visualScale = new Vector3(0.0, 0.0, 0.0);
  }
}

// Flight/Configuration/CarFlightConfiguration.reds


public class CarFlightConfiguration extends IFlightConfiguration {
  public func OnSetup(vehicle: ref<VehicleObject>) {
    super.OnSetup(vehicle);
    
    //#define PARTICLE R"(base\fx\vehicles\_damage\scratches\car_scratches_sparks.effect)"
    //#define PARTICLE R"(base\fx\_library\sparks\lib_sparks_impact_2-3m.effect)"
    //#define DECAL R"(base\fx\vehicles\_damage\scratches\car_scratches_sparks.effect)"
    //#define DECAL R"(base\fx\vehicles\_damage\scratches\car_scratches_concrete.effect)"
    //#define DECAL R"(base\fx\_library\fire\lib_burnt_mark_01_decal.effect)"

    // base\fx\vehicles\_wheels\tire_tracks\radial\blood\v_tire_track_blood_r_m_01.effect

    // this.particleEffect = r"base\\fx\\_library\\sparks\\lib_sparks_veryfast_constant_01.effect";
    // this.particleEffect = r"base\\fx\\environment\\sparks\\sparks_constant.effect";
    // good
    // this.particleEffect = r"base\\fx\\_library\\sparks\\lib_sparks_welding_big_01.effect";
    // this.particleEffect = r"user\\jackhumbert\\effects\\thruster_sparks.effect";
    // this.decalEffect = r"base\\fx\\_library\\concrete_breaks\\concrete_breaks_medium.effect";
    // this.decalEffect = r"base\\fx\\vehicles\\_damage\\scratches\\v_car_scratches_decal.effect";
    // this.decalEffect = r"base\\fx\\vehicles\\_wheels\\skid_marks\\radial\\v_skid_mark_r_m_01.effect";
    // this.decalEffect = r"base\\fx\\vehicles\\_wheels\\tire_tracks\\radial\\v_tire_track_r_m_01.effect";
    // this.decalEffect = r"user\\jackhumbert\\effects\\thruster_mark.effect";

    ArrayPush(this.thrusters, new FlightThrusterFL().Create(vehicle, this.CreateMesh(vehicle)));
    ArrayPush(this.thrusters, new FlightThrusterFR().Create(vehicle, this.CreateMesh(vehicle)));
    ArrayPush(this.thrusters, new FlightThrusterBR().Create(vehicle, this.CreateMesh(vehicle)));
    ArrayPush(this.thrusters, new FlightThrusterBL().Create(vehicle, this.CreateMesh(vehicle)));

    let retroThrusterTweak = vehicle.GetRecordID();
    TDBID.Append(retroThrusterTweak, t".hasRetroThruster");
    let hasRetroThruster = TweakDBInterface.GetBool(retroThrusterTweak, false);
      
    this.thrusters[0].hasRetroThruster = hasRetroThruster;
    this.thrusters[1].hasRetroThruster = hasRetroThruster;
    this.thrusters[2].hasRetroThruster = hasRetroThruster;
    this.thrusters[3].hasRetroThruster = hasRetroThruster;

    this.thrusters[0].wheelIndex = 0;
    this.thrusters[1].wheelIndex = 1;
    this.thrusters[2].wheelIndex = 2;
    this.thrusters[3].wheelIndex = 3;

    for thruster in this.thrusters {
      if thruster.hasRetroThruster {
        ArrayPush(thruster.fxs, new MainFlightThrusterFX().Create(thruster));
        ArrayPush(thruster.fxs, new SideFlightThrusterFX().Create(thruster));
      } else {
        ArrayPush(thruster.fxs, new RegularFlightThrusterFX().Create(thruster));
      }
      // vehicle.AddComponent(thruster.meshComponent);
      thruster.OnSetup(this.component);
    }

    // this.thrusters[0].fxs[0].SetResource(r"base\\fx\\vehicles\\manticore\\smoke_exhaust.effect"); // black & grey smoke
    // this.thrusters[1].fxs[0].SetResource(r"base\\fx\\vehicles\\av\\av_panzer\\weapons\\v_panzer_bullet_trail.effect"); // nothing i saw? maybe noise
    // this.thrusters[2].fxs[0].SetResource(r"base\\fx\\vehicles\\av\\_lights\\v_av_distant_emissives.effect"); // directional smoke
    // this.thrusters[3].fxs[0].SetResource(r"base\\fx\\vehicles\\drone\\drone_missile_trail.effect"); // cool orange trail actually?
    // this.thrusters[3].fxs[0].SetResource(r"base\\fx\\vehicles\\stratospheric_plane\\v_stratospheric_plane_takeoff_engines.effect"); // giant flashing rings

    // this.thrusters[0].fxs[0].SetResource(r"base\\fx\\vehicles\\_exhaust\\veh_exhaust_backfire.effect"); // no noticable effect
    // this.thrusters[1].fxs[0].SetResource(r"base\\fx\\vehicles\\_exhaust\\v_exhaust_smoke_standard_round.effect");  // no noticable effect
    // this.thrusters[2].fxs[0].SetResource(r"base\\fx\\vehicles\\car\\car_exhaust_smoke.effect");  // no noticable effect
    // this.thrusters[3].fxs[0].SetResource(r"base\\fx\\vehicles\\_exhaust\\v_exhaust_smoke_standard_rectangular.effect"); // no noticable effect

    // this.thrusters[0].fxs[0].SetResource(r"base\\fx\\vehicles\\av\\av_zetatech\\av_zetatech_turret_trail.effect"); // cool trail
    // this.thrusters[1].fxs[0].SetResource(r"base\\fx\\vehicles\\_exhaust\\veh_exhaust_start_sport.effect");   // not sure
    // this.thrusters[2].fxs[0].SetResource(r"base\\fx\\vehicles\\av\\v_av_manticore_vapour_trails.effect");  // not sure
    // this.thrusters[3].fxs[0].SetResource(r"base\\fx\\vehicles\\_exhaust\\v_exhaust_backfire_sport_rectangular.effect"); // forward smoke thing?

    // this.thrusters[0].fxs[0].SetResource(r"base\\fx\\weapons\\firearms\\special\\vehicle_rocket_launcher\\w_special_vehicle_missile_trail.effect"); // tiny smokey trail, short
    // this.thrusters[1].fxs[0].SetResource(r"base\\fx\\quest\\q003\\boss_centaur\\forc e_attack\\force_trail.effect");  // idk
    // this.thrusters[2].fxs[0].SetResource(r"base\\fx\\quest\\q114\\q114_missile_barage_trail.effect"); // smoke with flame - good basis for combustion engine?, short
    // this.thrusters[3].fxs[0].SetResource(r"base\\fx\\weapons\\trails\\smart\\w_trail_smart_rifle_high_low_class.effect");  // tiny little trail, short

    // this.thrusters[0].fxs[0].SetResource(r"base\\fx\\weapons\\throwables\\granades\\basic\\granade_trail_default.effect"); // idk
    // this.thrusters[1].fxs[0].SetResource(r"base\\fx\\quest\\q114\\q114_cars_dust_trail.effect");  // long trail of dust
    // this.thrusters[2].fxs[0].SetResource(r"base\\fx\\weapons\\bullet_trail_green.effect"); // idk
    // this.thrusters[3].fxs[0].SetResource(r"base\\fx\\weapons\\bullet_trail_simple.effect"); // nice bright orange trail
  }
}

// Flight/Configuration/FlightConfiguration_yaiba_kusanagi_basic_player_01.reds

// public class FlightConfiguration_yaiba_kusanagi_basic_player_01 extends IFlightConfiguration {
//   public let frontChild: ref<MeshComponent>;
//   public let backChild: ref<MeshComponent>;

//   public func OnSetup(vehicle: ref<VehicleObject>) {
//     super.OnSetup(vehicle);

//     this.flightCameraOffset = new Vector3(0.0, 1.0, 0.5);

//     // if (Equals(this.type, FlightVehicleType.Corpo)) {
//     //   ArrayPush(this.thrusters, new FlightThrusterFront().Create(vehicle, CreateCorpoThruster()));
//     //   ArrayPush(this.thrusters, new FlightThrusterBack().Create(vehicle, CreateCorpoThruster()));
//     // } else {

//     this.frontChild = this.CreateMesh(vehicle);
//     this.frontChild.name = n"ThrusterF";
//     this.frontChild.visualScale = new Vector3(0.0, 0.0, 0.0);
//     // this.frontChild.SetLocalPosition(new Vector4(0.0, 0.0, -0.2, 1.0));
//     // this.frontChild.SetLocalOrientation(new Quaternion(0.0, 0.0, 0.707, -0.707));
//     this.frontChild.SetLocalOrientation(EulerAngles.ToQuat(MakeEulerAngles(-45.0, 0.0, 0.0)));
//     // this.frontChild.SetParentTransform(this.thrusters[0].meshComponent.name, n"None");
//     // vehicle.AddComponent(this.frontChild);

//     this.backChild = this.CreateMesh(vehicle);
//     this.backChild.name = n"ThrusterB";
//     this.backChild.visualScale = new Vector3(0.0, 0.0, 0.0);
//     // this.backChild.SetLocalPosition(new Vector4(0.0, 0.0, -0.2, 1.0));
//     // this.backChild.SetLocalOrientation(new Quaternion(0.0, 0.0, -0.707, -0.707));
//     this.backChild.SetLocalOrientation(EulerAngles.ToQuat(MakeEulerAngles(0, 0, 0)));
//     // this.backChild.SetParentTransform(this.thrusters[1].meshComponent.name, n"None");
//     // vehicle.AddComponent(this.backChild);

//     ArrayPush(this.thrusters, new FlightThrusterFront().Create(vehicle, this.frontChild));
//     ArrayPush(this.thrusters, new FlightThrusterBack().Create(vehicle, this.backChild));

//     this.thrusters[0].hasRetroThruster = false;
//     this.thrusters[1].hasRetroThruster = false;

//     for thruster in this.thrusters {
//       ArrayPush(thruster.fxs, new RegularFlightThrusterFX().Create(thruster));
//       // vehicle.AddComponent(thruster.meshComponent);
//       thruster.OnSetup(this.component);
//     }
//   }

//   public func OnActivation() {
//     super.OnActivation();
//     this.frontChild.visualScale = new Vector3(1.0, 1.0, 1.0);
//     this.backChild.visualScale = new Vector3(1.0, 1.0, 1.0);
//   }

//   public func OnDeactivation() {
//     this.frontChild.visualScale = new Vector3(0.0, 0.0, 0.0);
//     this.backChild.visualScale = new Vector3(0.0, 0.0, 0.0);
//   }
// }

// Flight/Configuration/IFlightConfiguration.reds

enum FlightVehicleType {
  Streetkid = 0,
  Nomad = 1,
  Corpo = 2,
  Poor = 3,
  Suburban = 4,
  Urban = 5
}

public abstract native class IFlightConfiguration extends IScriptable {
  @runtimeProperty("offset", "0x40")
  public native let component: wref<FlightComponent>;

  @runtimeProperty("offset", "0x50")
  public native let thrusters: array<ref<IFlightThruster>>;

  @runtimeProperty("offset", "0x60")
  public native let flightCameraBone: CName; // "root_border_front"

  @runtimeProperty("offset", "0x68")
  public native let flightCameraOffset: Vector3; // 0, 0, 0

  public native func AddColliders();
  public native func RemoveColliders();
  public native func OnActivationCore();
  public native func OnDeactivationCore();

  public func CanActivate() -> Bool = true;

  public let type: FlightVehicleType = FlightVehicleType.Corpo;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Detachable-Thrusters")
  public let areThrustersDetachable: Bool = true;

  public let percentageAttached: Float = 1.0;

  public func AreThrustersDetachable() -> Bool {
    return this.areThrustersDetachable;
  }

  public func OnSetup(vehicle: ref<VehicleObject>) {
    let name = NameToString(vehicle.GetCurrentAppearanceName());

    // if (VehicleComponent.CheckVehicleDesiredTag(vehicle, n"Sport"))
    
    if StrFindFirst(name, "poor") > -1 {
      this.type = FlightVehicleType.Poor;
    }
    if StrFindFirst(name, "urban") > -1 {
      this.type = FlightVehicleType.Urban;
    }
    if StrFindFirst(name, "suburban") > -1 {
      this.type = FlightVehicleType.Suburban;
    }

    if StrFindFirst(name, "nomad") > -1 {
      this.type = FlightVehicleType.Nomad;
    }

    if StrFindFirst(name, "tyger") > -1 
    || StrFindFirst(name, "6th_street") > -1 
    || StrFindFirst(name, "animals") > -1 
    || StrFindFirst(name, "valentinos") > -1 {
      this.type = FlightVehicleType.Streetkid;
    }
  }

  public func CreateMesh(vehicle: ref<VehicleObject>) -> ref<MeshComponent> {

    let defaultMesh = r"user\\jackhumbert\\meshes\\engine_nomad.mesh";
    
    if (Equals(this.type, FlightVehicleType.Corpo)) {
      defaultMesh = r"user\\jackhumbert\\meshes\\engine_corpo.mesh";
    }

    // let appearanceTweak = vehicle.GetRecordID();
    // TDBID.Append(appearanceTweak, t".thrusterAppearance");
    // let thrusterAppearance = TweakDBInterface.GetCName(appearanceTweak, n"default");
    
    // let meshTweak = vehicle.GetRecordID();
    // TDBID.Append(meshTweak, t".thrusterMesh");
    // let thrusterMesh = TweakDBInterface.GetResRef(meshTweak, defaultMesh);


    let mc = new PhysicalMeshComponent();
    mc.SetMesh(vehicle.GetResRef("thrusterMesh", defaultMesh));
    mc.meshApperance = vehicle.GetCName("thrusterAppearance");
    mc.motionBlurScale = 0.1;
    mc.LODMode = entMeshComponentLODMode.Appearance;
    return mc;
  }

  public func OnActivation() {
    FlightLog.Info("[FlightConfiguration] Activating " + NameToString(this.GetClassName()) + ": " + NameToString(this.component.GetVehicle().GetCurrentAppearanceName()));
  }

  public func OnDeactivation() {
    
  }

  public func GetThrusterTensor() -> Vector4 {
    let total = new Vector4(0.0, 0.0, 0.0, 0.0);
    let vt = this.component.GetVehicle().GetWorldTransform();
    let totalThrusters = 0.0;
    let attachedThrusters = 0.0;
    for thruster in this.thrusters {
      if thruster.attached {
        attachedThrusters += 1.0;
        let v = WorldTransform.TransformInvPoint(vt, thruster.GetLocalToWorld() * Vector4.EmptyVector());
        v -= Vector4.Vector3To4(this.component.GetVehicle().GetCenterOfMass());
        total.X += SqrtF(PowF(v.Y, 2.0) + PowF(v.Z, 2.0));
        total.Y += SqrtF(PowF(v.X, 2.0) + PowF(v.Z, 2.0));
        total.Z += SqrtF(PowF(v.X, 2.0) + PowF(v.Y, 2.0));
      }
      totalThrusters += 1.0;
    }
    this.percentageAttached = attachedThrusters / totalThrusters;
    return total;
  }

  public func GetEffectForMaterial(material: CName, originalFx: MaterialFx) -> MaterialFx {
    if Equals(material, n"concrete.physmat") ||
       Equals(material, n"asphalt.physmat") ||
       Equals(material, n"metal.physmat") ||
       Equals(material, n"metal_painted.physmat")||
       Equals(material, n"default_material.physmat") {
        originalFx.normal.particle.skidMarks = r"user\\jackhumbert\\effects\\thruster_sparks.effect";
        originalFx.normal.particle.tireTracks = r"user\\jackhumbert\\effects\\thruster_sparks.effect";
        originalFx.normal.particle.loaded = true;
        originalFx.wet.particle.skidMarks = r"user\\jackhumbert\\effects\\thruster_sparks.effect";
        originalFx.wet.particle.tireTracks = r"user\\jackhumbert\\effects\\thruster_sparks.effect";
        originalFx.wet.particle.loaded = true;
        originalFx.rain.particle.skidMarks = r"user\\jackhumbert\\effects\\thruster_sparks.effect";
        originalFx.rain.particle.tireTracks = r"user\\jackhumbert\\effects\\thruster_sparks.effect";
        originalFx.rain.particle.loaded = true;
        
        originalFx.normal.decal.skidMarks = r"user\\jackhumbert\\effects\\thruster_mark.effect";
        originalFx.normal.decal.tireTracks = r"user\\jackhumbert\\effects\\thruster_mark.effect";
        originalFx.normal.decal.loaded = true;
        originalFx.wet.decal.skidMarks = r"user\\jackhumbert\\effects\\thruster_mark.effect";
        originalFx.wet.decal.tireTracks = r"user\\jackhumbert\\effects\\thruster_mark.effect";
        originalFx.wet.decal.loaded = true;
        originalFx.rain.decal.skidMarks = r"user\\jackhumbert\\effects\\thruster_mark.effect";
        originalFx.rain.decal.tireTracks = r"user\\jackhumbert\\effects\\thruster_mark.effect";
        originalFx.rain.decal.loaded = true;
    }

    //   case n"dirt.physmat":
    //   case n"grass.physmat":
    //   case n"sand.physmat":
    //   case n"mud.physmat":
 
    return originalFx;
  }
}

// Flight/Configuration/SixWheelCarFlightConfiguration.reds

public class SixWheelCarFlightConfiguration extends CarFlightConfiguration {
  public func OnSetup(vehicle: ref<VehicleObject>) {
    super.OnSetup(vehicle);

    ArrayPush(this.thrusters, new FlightThrusterFLB().Create(vehicle, this.CreateMesh(vehicle)));
    ArrayPush(this.thrusters, new FlightThrusterFRB().Create(vehicle, this.CreateMesh(vehicle)));

    let retroThrusterTweak = vehicle.GetRecordID();
    TDBID.Append(retroThrusterTweak, t".hasRetroThruster");
    let hasRetroThruster = TweakDBInterface.GetBool(retroThrusterTweak, false);

    this.thrusters[4].hasRetroThruster = hasRetroThruster;
    this.thrusters[5].hasRetroThruster = hasRetroThruster;

    if this.thrusters[4].hasRetroThruster {
      ArrayPush(this.thrusters[4].fxs, new MainFlightThrusterFX().Create(this.thrusters[4]));
      ArrayPush(this.thrusters[4].fxs, new SideFlightThrusterFX().Create(this.thrusters[4]));
    } else {
      ArrayPush(this.thrusters[4].fxs, new RegularFlightThrusterFX().Create(this.thrusters[4]));
    }
    this.thrusters[4].OnSetup(this.component);

    if this.thrusters[5].hasRetroThruster {
      ArrayPush(this.thrusters[5].fxs, new MainFlightThrusterFX().Create(this.thrusters[5]));
      ArrayPush(this.thrusters[5].fxs, new SideFlightThrusterFX().Create(this.thrusters[5]));
    } else {
      ArrayPush(this.thrusters[5].fxs, new RegularFlightThrusterFX().Create(this.thrusters[5]));
    }
    this.thrusters[5].OnSetup(this.component);
  }
}

public class SixWheelRearCarFlightConfiguration extends CarFlightConfiguration {
  public func OnSetup(vehicle: ref<VehicleObject>) {
    super.OnSetup(vehicle);

    ArrayPush(this.thrusters, new FlightThrusterBLB().Create(vehicle, this.CreateMesh(vehicle)));
    ArrayPush(this.thrusters, new FlightThrusterBRB().Create(vehicle, this.CreateMesh(vehicle)));

    let retroThrusterTweak = vehicle.GetRecordID();
    TDBID.Append(retroThrusterTweak, t".hasRetroThruster");
    let hasRetroThruster = TweakDBInterface.GetBool(retroThrusterTweak, false);

    this.thrusters[4].hasRetroThruster = hasRetroThruster;
    this.thrusters[5].hasRetroThruster = hasRetroThruster;

    if this.thrusters[4].hasRetroThruster {
      ArrayPush(this.thrusters[4].fxs, new MainFlightThrusterFX().Create(this.thrusters[4]));
      ArrayPush(this.thrusters[4].fxs, new SideFlightThrusterFX().Create(this.thrusters[4]));
    } else {
      ArrayPush(this.thrusters[4].fxs, new RegularFlightThrusterFX().Create(this.thrusters[4]));
    }
    this.thrusters[4].OnSetup(this.component);

    if this.thrusters[5].hasRetroThruster {
      ArrayPush(this.thrusters[5].fxs, new MainFlightThrusterFX().Create(this.thrusters[5]));
      ArrayPush(this.thrusters[5].fxs, new SideFlightThrusterFX().Create(this.thrusters[5]));
    } else {
      ArrayPush(this.thrusters[5].fxs, new RegularFlightThrusterFX().Create(this.thrusters[5]));
    }
    this.thrusters[5].OnSetup(this.component);
  }
}


// Flight/FlightComponent.reds

public native class FlightComponentPS extends GameComponentPS {

}

public native class FlightComponent extends GameComponent {
  @runtimeProperty("offset", "0xA8")
  public native let sys: ref<FlightSystem>;

  @runtimeProperty("offset", "0xB8")
  public native let active: Bool;

  @runtimeProperty("offset", "0xB9")
  public native let hasUpdate: Bool;

  @runtimeProperty("offset", "0xC0")
  public native let force: Vector4;

  @runtimeProperty("offset", "0xD0")
  public native let torque: Vector4;

  // @runtimeProperty("offset", "0xE0")
  // public native let thrusters: array<ref<IFlightThruster>>;

  @runtimeProperty("offset", "0xE0")
  public native let configuration: ref<IFlightConfiguration>;

  @runtimeProperty("offset", "0xF8")
  public native let linearDamp: Float;

  @runtimeProperty("offset", "0xFC")
  public native let angularDamp: Float;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Quickhacks")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Enabled")
  public let isQuickHackable: Bool = true;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Explosion-Threshold")
  @runtimeProperty("ModSettings.description", "UI-Settings-Explosion-Threshold-Description")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "100.0")
  public let explosionThreshold: Float = 0.5;

  public native func ChaseTarget(target: wref<GameObject>) -> Void;
  // public native func ChaseTarget() -> Void;

  // private let helper: ref<vehicleFlightHelper>;
  private let stats: ref<FlightStats>;

  public let m_interaction: ref<InteractionComponent>;
  public let m_healthStatPoolListener: ref<VehicleHealthStatPoolListener>;
  public let m_vehicleBlackboard: wref<IBlackboard>;
  public let m_vehicleTPPCallbackID: ref<CallbackHandle>;

  public let isPlayerMounted: Bool;

  let hoverGroundPID: ref<PID>;
  // let hoverPID: ref<PID>;
  // let pitchGroundPID: ref<DualPID>;
  let pitchPID: ref<PID>;
  // let rollGroundPID: ref<DualPID>;
  let rollPID: ref<PID>;
  let aeroYawPID: ref<PID>;
  let pitchAeroPID: ref<PID>;

  private let sqs: ref<SpatialQueriesSystem>;

  public let bl_tire: ref<IPlacedComponent>;
  public let br_tire: ref<IPlacedComponent>;
  public let fl_tire: ref<IPlacedComponent>;
  public let fr_tire: ref<IPlacedComponent>;
  public let hood: ref<IPlacedComponent>;
  public let trunk: ref<IPlacedComponent>;

  public let collisionTimer: Float;

  public let distance: Float;
  public let hoverHeight: Float;

  private let modes: array<ref<FlightMode>>;
  public let mode: Int32;

  private let surge: Float;
  private let lift: Float;
  private let roll: Float;
  private let pitch: Float;
  private let yaw: Float;
  private let sway: Float;
  private let linearBrake: Float;
  private let angularBrake: Float;

  public let thrusterTensor: Vector4;

  // public let ui: wref<worlduiWidgetComponent>;
  // public let ui_info: wref<worlduiWidgetComponent>;

  public let alarmIsPlaying: Bool;

  protected final func GetVehicle() -> wref<VehicleObject> {
    return this.GetEntity() as VehicleObject;
  }

  private final func GetMyPS() -> ref<FlightComponentPS> {
    return this.GetPS() as FlightComponentPS;
  }

  protected cb func OnVehicleOnPartDetached(evt: ref<VehicleOnPartDetachedEvent>) -> Bool {
    FlightLog.Info("[FlightComponent] Part detached: " + NameToString(evt.partName));
    let oneOfOurs = false;
    for thruster in this.configuration.thrusters {
      if IsDefined(thruster.meshComponent) {
        if Equals(thruster.meshComponent.name, evt.partName) {
          thruster.Detach();
          oneOfOurs = true;
        }
      } else {
        thruster.Detach();
        oneOfOurs = true;
      }
    }

    if oneOfOurs {
      this.thrusterTensor = this.configuration.GetThrusterTensor();
      this.configuration.RemoveColliders();
      this.configuration.AddColliders();
    }
  }

  // interaction layer stuff to add eventually

/*
  private final func CreateObjectActionsCallbackController(instigator: wref<Entity>) -> Void {
    this.m_objectActionsCallbackCtrl = gameObjectActionsCallbackController.Create(this.GetEntity(), instigator, this.GetVehicle().GetGame());
    this.m_objectActionsCallbackCtrl.RegisterSkillCheckCallbacks();
  }

  private final func DestroyObjectActionsCallbackController() -> Void {
    this.m_objectActionsCallbackCtrl.UnregisterSkillCheckCallbacks();
    this.m_objectActionsCallbackCtrl = null;
  }

  protected cb func OnObjectActionRefreshEvent(evt: ref<gameObjectActionRefreshEvent>) -> Bool {
    if IsDefined(this.m_objectActionsCallbackCtrl) {
      this.m_objectActionsCallbackCtrl.UnlockNotifications();
      this.DetermineInteractionState();
    };
  }

  protected cb func OnInteractionActivated(evt: ref<InteractionActivationEvent>) -> Bool {
    let context: VehicleActionsContext;
    if this.GetVehicle().IsCrowdVehicle() && StatusEffectSystem.ObjectHasStatusEffectWithTag(evt.activator, n"BlockTrafficInteractions") {
      return false;
    };
    if Equals(evt.eventType, gameinteractionsEInteractionEventType.EIET_activate) {
      if evt.IsInputLayerEvent() {
        this.CreateObjectActionsCallbackController(evt.activator);
      };
    } else {
      if Equals(evt.eventType, gameinteractionsEInteractionEventType.EIET_deactivate) {
        if evt.IsInputLayerEvent() {
          this.DestroyObjectActionsCallbackController();
        };
      };
    };
    context.requestorID = this.GetVehicle().GetEntityID();
    context.processInitiatorObject = evt.activator;
    context.interactionLayerTag = evt.layerData.tag;
    context.eventType = evt.eventType;
    this.GetPS().DetermineActionsToPush(this.m_interaction, context, this.m_objectActionsCallbackCtrl, false);
    if this.GetVehicle() == (this.GetVehicle() as TankObject) {
      this.EvaluatePanzerInteractions();
    };
  }

  protected cb func OnInteractionUsed(evt: ref<InteractionChoiceEvent>) -> Bool {
    this.ExecuteAction(evt.choice, evt.activator);
    this.m_interaction.ResetChoices();
  }
*/

  private final func OnGameAttach() -> Void {
    LTBF_RegisterListener(this);
    // ArrayResize(this.playingScraping, 4);
    // FlightLog.Info("[FlightComponent] OnGameAttach: " + this.GetVehicle().GetDisplayName());
    this.m_interaction = this.FindComponentByName(n"interaction") as InteractionComponent;
    this.m_healthStatPoolListener = new VehicleHealthStatPoolListener();
    this.m_healthStatPoolListener.m_owner = this.GetVehicle();
    GameInstance.GetStatPoolsSystem(this.GetVehicle().GetGame()).RequestRegisteringListener(Cast(this.GetVehicle().GetEntityID()), gamedataStatPoolType.Health, this.m_healthStatPoolListener);
    this.m_vehicleBlackboard = this.GetVehicle().GetBlackboard();
    // QuickhackModule.RequestRefreshQuickhackMenu(this.GetVehicle().GetGame(), this.GetVehicle().GetEntityID());


    // let vehicleFlight = new PSMAddOnDemandStateMachine();
    // vehicleFlight.stateMachineName = n"VehicleFlight";
    // vehicleFlight.owner = this.GetVehicle();
    // // vehicleFlight.instanceData = instanceData;
    // // needs to be player?
    // // mountChild.QueueEvent(vehicleFlight);
    // // let vehicle: ref<VehicleObject> = this.GetVehicle();
    // // let gameInstance: GameInstance = vehicle.GetGame();
    // // let player: ref<PlayerPuppet> = GetPlayer(gameInstance);
    // GameInstance.GetPlayerSystem(this.GetVehicle().GetGame()).GetLocalPlayerControlledGameObject().QueueEvent(vehicleFlight);

    // this.hoverGroundPID = PID.Create(1.0, 0.01, 0.1);
    this.hoverGroundPID = PID.Create(FlightSettings.GetVector3("hoverModePID"));
    // this.hoverPID = PID.Create(1.0, 0.01, 0.1);
    this.pitchPID = PID.Create(FlightSettings.GetVector3("inputPitchPID"));
    this.rollPID =  PID.Create(FlightSettings.GetVector3("inputRollPID"));
    this.aeroYawPID = PID.Create(FlightSettings.GetVector3("aeroYawPID"));
    this.pitchAeroPID = PID.Create(FlightSettings.GetVector3("aeroPitchPID"));

    // this.sys = FlightSystem.GetInstance();
    // this.sys.RegisterComponent(this);
    this.sqs = GameInstance.GetSpatialQueriesSystem(this.GetVehicle().GetGame());
    // this.fx = FlightFx.Create(this);
    // this.thrusters = FlightThruster.CreateThrusters(this);

    // this.helper = this.GetVehicle().AddFlightHelper();
    // this.stats = FlightStats.Create(this.GetVehicle());

    this.collisionTimer = FlightSettings.GetFloat("collisionRecoveryDelay");
    this.distance = 0.0;
    this.hoverHeight = FlightSettings.GetFloat("defaultHoverHeight");

    let hoverFlyMode = FlightModeHoverFly.Create(this);
    if hoverFlyMode.enabled {
      ArrayPush(this.modes, hoverFlyMode);
    } else {
      hoverFlyMode.Deinitialize();
    }
    let hoverMode = FlightModeHover.Create(this);
    if hoverMode.enabled {
      ArrayPush(this.modes, hoverMode);
    } else {
      hoverMode.Deinitialize();
    }
    let automaticMode = FlightModeAutomatic.Create(this);
    if automaticMode.enabled {
      ArrayPush(this.modes, automaticMode);
    } else {
      automaticMode.Deinitialize();
    }
    let flyMode = FlightModeFly.Create(this);
    if flyMode.enabled {
      ArrayPush(this.modes, flyMode);
    } else {
      flyMode.Deinitialize();
    }
    let agDroneMode = FlightModeDroneAntiGravity.Create(this);
    if agDroneMode.agEnabled {
      ArrayPush(this.modes, agDroneMode);
    } else {
      agDroneMode.Deinitialize();
    }
    let droneMode = FlightModeDrone.Create(this);
    if droneMode.enabled {
      ArrayPush(this.modes, droneMode);
    } else {
      droneMode.Deinitialize();
    }

    this.audioUpdate = new FlightAudioUpdate();

    // if ArraySize(this.configuration.thrusters) == 0 {
    //   this.configuration.thrusters = IFlightThruster.CreateThrusters(this);
    // }
    // this.sys.RegisterComponent(this);
  }

  private final func OnGameDetach() -> Void {
    LTBF_UnregisterListener(this);
    //FlightLog.Info("[FlightComponent] OnGameDetach: " + this.GetVehicle().GetDisplayName());
    GameInstance.GetStatPoolsSystem(this.GetVehicle().GetGame()).RequestUnregisteringListener(Cast(this.GetVehicle().GetEntityID()), gamedataStatPoolType.Health, this.m_healthStatPoolListener);
    this.UnregisterVehicleTPPBBListener();

    // let vehicleFlight = new PSMRemoveOnDemandStateMachine();
    // vehicleFlight.stateMachineIdentifier.definitionName = n"VehicleFlight";
    // GameInstance.GetPlayerSystem(this.GetVehicle().GetGame()).GetLocalPlayerControlledGameObject().QueueEvent(vehicleFlight);

    this.isDestroyed = true;
    this.hasExploded = true;
    if this.active {
      this.Deactivate(true);
    }
    this.hasUpdate = false;
    for mode in this.modes {
      mode.Deinitialize();
    }
  }

  // private final func RegisterInputListener() -> Void {
  //   let playerPuppet: ref<PlayerPuppet> = GameInstance.GetPlayerSystem(this.GetVehicle().GetGame()).GetLocalPlayerMainGameObject() as PlayerPuppet;
  //   playerPuppet.RegisterInputListener(this, n"VehicleInsideWheel");
  //   playerPuppet.RegisterInputListener(this, n"VehicleHorn");
  // }

  // private final func UnregisterInputListener() -> Void {
  //   let playerPuppet: ref<PlayerPuppet> = GameInstance.GetPlayerSystem(this.GetVehicle().GetGame()).GetLocalPlayerMainGameObject() as PlayerPuppet;
  //   if IsDefined(playerPuppet) {
  //     playerPuppet.UnregisterInputListener(this);
  //   };
  // }

  protected final func SetupVehicleTPPBBListener() -> Void {
    let activeVehicleUIBlackboard: wref<IBlackboard>;
    let bbSys: ref<BlackboardSystem>;
    if !IsDefined(this.m_vehicleTPPCallbackID) {
      bbSys = GameInstance.GetBlackboardSystem(this.GetVehicle().GetGame());
      activeVehicleUIBlackboard = bbSys.Get(GetAllBlackboardDefs().UI_ActiveVehicleData);
      this.m_vehicleTPPCallbackID = activeVehicleUIBlackboard.RegisterListenerBool(GetAllBlackboardDefs().UI_ActiveVehicleData.IsTPPCameraOn, this, n"OnVehicleCameraChange");
    };
  }

  protected final func UnregisterVehicleTPPBBListener() -> Void {
    let activeVehicleUIBlackboard: wref<IBlackboard>;
    let bbSys: ref<BlackboardSystem>;
    if IsDefined(this.m_vehicleTPPCallbackID) {
      bbSys = GameInstance.GetBlackboardSystem(this.GetVehicle().GetGame());
      activeVehicleUIBlackboard = bbSys.Get(GetAllBlackboardDefs().UI_ActiveVehicleData);
      activeVehicleUIBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().UI_ActiveVehicleData.IsTPPCameraOn, this.m_vehicleTPPCallbackID);
    };
  }

  private func GetPitch() -> Float{
    return ClampF(700.0 / this.GetVehicle().GetTotalMass() + 0.5, 0.5, 1.5);
  }

  public func GetFlightModeIndex() -> Int32 {
    return this.mode;
  }

  public func GetFlightMode() -> ref<FlightMode> {
    return this.modes[this.mode];
  }

  public func GetNextFlightMode(direction: Int32) -> ref<FlightMode> {
    let mode = this.mode + direction;
    if mode < 0 {
      mode += ArraySize(this.sys.playerComponent.modes);
    }
    mode = mode % ArraySize(this.sys.playerComponent.modes);
    return this.modes[mode];
  }

  public func GetNextFlightModeDescription() -> String {
    if ArraySize(this.modes) > 0 {
      return this.GetNextFlightMode(1).GetDescription();
    } else {
      return "None";
    }
  }

  // callbacks

  // public let uiControl: ref<FlightControllerUI>;

  protected cb func OnMountingEvent(evt: ref<MountingEvent>) -> Bool {


    // this.helper = this.GetVehicle().AddFlightHelper();
    // LTBF_RegisterListener(this);
    this.thrusterTensor = this.configuration.GetThrusterTensor();
    FlightLog.Info("[FlightComponent] thrusterTensor: " + this.thrusterTensor.X + ", " + this.thrusterTensor.Y + ", " + this.thrusterTensor.Z + ", " + this.thrusterTensor.W);
    let mountChild: ref<GameObject> = GameInstance.FindEntityByID(this.GetVehicle().GetGame(), evt.request.lowLevelMountingInfo.childId) as GameObject;
    if mountChild.IsPlayer() {

      // let instanceData: StateMachineInstanceData;
      // let initData = new VehicleFlightInitData();
      // initData.vehicle = this.GetVehicle();
      // initData.driver = mountChild;
      // instanceData.initData = initData;

      let vehicleFlight = new PSMAddOnDemandStateMachine();
      vehicleFlight.stateMachineName = n"VehicleFlight";
      vehicleFlight.owner = this.GetVehicle();
      // vehicleFlight.instanceData = instanceData;
      // needs to be player?
      mountChild.QueueEvent(vehicleFlight);
      // let vehicle: ref<VehicleObject> = this.GetVehicle();
      // let gameInstance: GameInstance = vehicle.GetGame();
      // let player: ref<PlayerPuppet> = GetPlayer(gameInstance);
      // GameInstance.GetPlayerSystem(this.GetVehicle().GetGame()).GetLocalPlayerControlledGameObject().QueueEvent(vehicleFlight);

      FlightLog.Info("[FlightComponent] OnMountingEvent: " + this.GetVehicle().GetDisplayName() + ": " + NameToString(this.GetVehicle().GetCurrentAppearanceName()));
      FlightLog.Info("[FlightComponent] TDBID: " + TDBID.ToStringDEBUG(this.GetVehicle().GetRecordID()));
      // this.GetVehicle().TurnOffAirControl();
      // FlightLog.Info("[FlightComponent] OnMountingEvent: " + this.GetVehicle().GetDisplayName());
      // (this.GetVehicle().FindComponentByName(n"cars_sport_fx") as EffectSpawnerComponent).AddEffect();
      this.sys.SetPlayerComponent(this);
      this.sys.ctlr.ResetInputs();
      this.isPlayerMounted = true;
      this.SetupVehicleTPPBBListener();
      // try without wind
      // FlightAudio.Get().Start("windLeft", "wind_TPP");
      // FlightAudio.Get().Start("windRight", "wind_TPP");
      // this.uiControl = FlightControllerUI.Create(this.ui_info.GetGameController(), this.ui_info.GetGameController().GetRootCompoundWidget());
      // this.uiControl.Setup(this.stats);
    } else {
      // FlightLog.Info("[FlightComponent] OnMountingEvent for other vehicle: " + this.GetVehicle().GetDisplayName());
    }
  }

  protected cb func OnVehicleFinishedMountingEvent(evt: ref<VehicleFinishedMountingEvent>) -> Bool {
    if evt.character.IsPlayer() && evt.isMounting {
      FlightLog.Info("[FlightComponent] OnVehicleFinishedMountingEvent: " + this.GetVehicle().GetDisplayName());
      this.sys.ctlr.Enable();
      if this.active {
        this.sys.ctlr.Activate(true);
        // this.sys.audio.Stop("otherVehicle" + ToString(EntityID.GetHash(this.GetVehicle().GetEntityID())));
        //this.sys.audio.Play("vehicle3_on");
        // this.sys.audio.StartWithPitch("playerVehicle", "vehicle3_TPP", this.GetPitch());
      }
    }
    let normal: Vector4;
    this.SetupTires();
    let wheeled = this.GetVehicle() as WheeledObject;
    if ( evt.character.IsPlayer() && evt.isMounting && !this.FindGround(normal) || this.distance > FlightSettings.GetInstance().autoActivationHeight) && IsDefined(wheeled) && FlightSettings.GetInstance().autoActivationEnabled {
      this.Activate(true);
    }
  }

  protected cb func OnUnmountingEvent(evt: ref<UnmountingEvent>) -> Bool {
    // LTBF_UnregisterListener(this);
    let mountChild: ref<GameObject> = GameInstance.FindEntityByID(this.GetVehicle().GetGame(), evt.request.lowLevelMountingInfo.childId) as GameObject;
    if IsDefined(mountChild) && mountChild.IsPlayer() {

      let vehicleFlight = new PSMRemoveOnDemandStateMachine();
      vehicleFlight.stateMachineIdentifier.definitionName = n"VehicleFlight";
      mountChild.QueueEvent(vehicleFlight);

      this.UnregisterVehicleTPPBBListener();
      // try without wind
      // FlightAudio.Get().Stop("windLeft");
      // FlightAudio.Get().Stop("windRight");
      this.sys.playerComponent = null;
      this.isPlayerMounted = false;
      if this.active {
        this.sys.ctlr.Deactivate(true);
        // this.sys.audio.Stop("playerVehicle");
        // this.sys.audio.StartWithPitch("otherVehicle" + ToString(EntityID.GetHash(this.GetVehicle().GetEntityID())), "vehicle3_TPP", this.GetPitch());
      }
      this.sys.ctlr.ResetInputs();
      this.sys.ctlr.Disable();
    }
  }

  // protected cb func OnVehicleHasExplodedEvent(evt: ref<VehicleHasExplodedEvent>) -> Bool {
  //   this.sys.audio.Stop("vehicleDestroyed" + this.GetUniqueID());
  //   this.Deactivate(true);
  // }

  protected cb func OnVehicleFlightModeChangeEvent(evt: ref<VehicleFlightModeChangeEvent>) -> Bool {
    this.modes[this.mode].Deactivate();
    this.mode = evt.mode;
    this.modes[this.mode].Activate();
  }

  protected cb func OnDeath(evt: ref<gameDeathEvent>) -> Bool {
    let vehicle: ref<VehicleObject> = this.GetVehicle();
    let gameInstance: GameInstance = vehicle.GetGame();
    let player: ref<PlayerPuppet> = GetPlayer(gameInstance);
    if VehicleComponent.IsMountedToProvidedVehicle(gameInstance, player.GetEntityID(), vehicle) {
      FlightLog.Info("[FlightComponent] OnDeath: " + this.GetVehicle().GetDisplayName());
      if this.active {
        this.isDestroyed = true;
        this.hasExploded = true;
        this.Deactivate(true);
      }
      this.hasUpdate = false;
    }
  }

  protected cb func OnVehicleWaterEvent(evt: ref<VehicleWaterEvent>) -> Bool {
    if evt.isInWater  {
      // this.audioUpdate.water = 1.0;
      FlightAudio.Get().UpdateParameter("water", 1.0);
    } else {
      // this.audioUpdate.water = 0.0;
      FlightAudio.Get().UpdateParameter("water", 0.0);
    }
  }

  // protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
  //   FlightLog.Info("[FlightComponent] OnAction: " + this.GetVehicle().GetDisplayName());
  // }

  protected cb func OnVehicleFlightActivationEvent(evt: ref<VehicleFlightActivationEvent>) -> Bool {
    this.Activate();
  }

  // Toggles flight on summon button press
  // protected cb func OnSummonStartedEvent(evt: ref<SummonStartedEvent>) -> Bool {
  //   if Equals(evt.state, vehicleSummonState.EnRoute) || Equals(evt.state, vehicleSummonState.AlreadySummoned) {
  //     // this.CreateMappin();
  //     if Equals(evt.state, vehicleSummonState.EnRoute) {
  //       // this.SendParkEvent(false);
  //     };
  //     if Equals(evt.state, vehicleSummonState.AlreadySummoned) {
  //       // this.HonkAndFlash();
  //       if this.active {
  //         this.Deactivate(false);
  //       } else {
  //         this.Activate();
  //       }
  //       // this.GetVehicle().PhysicsWakeUp();
  //     };
  //   };
  // }

  public func Activate(opt silent: Bool) -> Void {
    // this.helper = this.GetVehicle().AddFlightHelper();
    FlightLog.Info("[FlightComponent] Activating Flight: " + this.GetVehicle().GetDisplayName());
    FlightLog.Info("[FlightComponent] AppearanceName: " + NameToString(this.GetVehicle().GetCurrentAppearanceName()));
    // this.GetVehicle().ScheduleAppearanceChange(this.GetVehicle().GetCurrentAppearanceName());
    if !this.active {
      this.stats = FlightStats.Create(this.GetVehicle());
      // this.sys.ctlr.ui.Setup(this.stats);

      this.SetupTires();
      for thruster in this.configuration.thrusters {
        thruster.Start();
      }
      // these stop engine noises if they were already playing?
      this.GetVehicle().TurnEngineOn(false);
      // this.GetVehicle().TurnOn(true);
      // this.GetVehicle().GetVehicleComponent().GetVehicleControllerPS().SetLightMode(vehicleELightMode.HighBeams);
      this.GetVehicle().GetVehicleComponent().GetVehicleController().ToggleLights(true);

      this.hoverGroundPID.Reset();
      // this.hoverPID.Reset();
      // this.pitchGroundPID.Reset();
      this.pitchPID.Reset();
      // this.rollGroundPID.Reset();
      this.rollPID.Reset();
      this.aeroYawPID.Reset();
      this.pitchAeroPID.Reset();

      this.modes[this.mode].Activate();

      if this.isPlayerMounted {
        this.mode = this.sys.ctlr.mode;
        this.sys.ctlr.Activate(silent);
        FlightAudio.Get().Play("vehicle3_on");
        // this.sys.audio.StartWithPitch("playerVehicle", "vehicle3_TPP", this.GetPitch());
        // this.sys.audio.Start("leftFront", "vehicle3_TPP");
        // this.sys.audio.Start("rightFront", "vehicle3_TPP");
        // this.sys.audio.Start("leftRear", "vehicle3_TPP");
        // this.sys.audio.Start("rightRear", "vehicle3_TPP");
      }
      // this.sys.audio.StartWithPitch("vehicle" + this.GetUniqueID(), "vehicle3_TPP", this.GetPitch());
      this.active = true;
      this.hasUpdate = true;

      this.configuration.OnActivationCore();
    }
  }

  protected cb func OnInteractionUsed(evt: ref<InteractionChoiceEvent>) -> Bool {
    FlightLog.Info("[FlightComponent] OnInteractionUsed: " + ToString(evt.actionType));
  }

  public let trick: ref<FlightTrick>;

  let smoothForce: Vector4;
  let smoothTorque: Vector4;
  let isDestroyed: Bool;
  let hasExploded: Bool;
  let lastVelocity: Vector4;
  public let accelerationFx: ref<FxInstance>;
  public let smoothFx: Float = 1.0;
  public let accThreshold: Float = 1.0;

  protected func OnUpdate(timeDelta: Float) -> Void {
    if this.GetVehicle().IsDestroyed() {
      if !this.isDestroyed {
        FlightAudio.Get().Start("vehicleDestroyed" + this.GetUniqueID(), "vehicle3_destroyed");
        this.alarmIsPlaying = true;
        this.isDestroyed = true;
      }
      if this.GetVehicle().GetVehicleComponent().GetPS().GetHasExploded() {
        this.hasExploded = true;
      }
      if this.hasExploded {
        this.Deactivate(true);
        return;
      }
    }

    let vehicle: ref<VehicleObject> = this.GetVehicle();
    let gameInstance: GameInstance = vehicle.GetGame();

    let photoModeSys: ref<PhotoModeSystem> = GameInstance.GetPhotoModeSystem(gameInstance);
    if photoModeSys.IsPhotoModeActive() {
      return;
    }

    if timeDelta <= 0.0 {
      this.stats.UpdateDynamic();
      this.UpdateAudioParams(1.0/60.0);

      for thruster in this.configuration.thrusters {
        thruster.Update(this.smoothForce, this.smoothTorque);
      }
      return;
    }
    // something that responds to acceleration & collisions
    // maybe just need a custom effect
    // let velocity = this.GetVehicle().GetLinearVelocity();
    // let acceleration = velocity - this.lastVelocity;
    // this.lastVelocity = velocity;
    // if Vector4.Length(acceleration) > this.accThreshold {
    //   // if !IsDefined(this.accelerationFx) {
    //     let fx = ResRefToFxResource(r"base\\fx\\player\\p_damage\\p_health_low.effect");
    //     this.accelerationFx = GameInstance.GetFxSystem(this.GetVehicle().GetGame()).SpawnEffect(fx, new WorldTransform());
    //   // }
    //   this.smoothFx = LerpF(0.1, this.smoothFx, Vector4.Length(acceleration));
    //   this.accelerationFx.SetBlackboardValue(n"health_state", ClampF(1.0 - (this.smoothFx - this.accThreshold) * 0.5, 0.0, 1.0));
    // } else {
    //   // if IsDefined(this.accelerationFx) {
    //     this.accelerationFx.BreakLoop();
    //   // }
    // }
    if this.active {
      if this.isPlayerMounted {
        this.GetVehicle().ResetQuestEnforceTransform();
        this.sys.ctlr.OnUpdate(timeDelta);
        let fc = this.sys.ctlr;
        this.yaw = fc.yaw.GetValue();
        this.roll = fc.roll.GetValue();
        this.pitch = fc.pitch.GetValue();
        this.lift = fc.lift.GetValue();
        this.linearBrake = fc.linearBrake.GetValue();
        this.angularBrake = fc.angularBrake.GetValue();
        this.surge = fc.surge.GetValue();
        this.sway = fc.sway.GetValue();

        let total = SqrtF(PowF(this.surge, 2.0) + PowF(this.lift, 2.0) + PowF(this.sway, 2.0));
        if (total > 1.0) {
          this.surge /= total;
          this.lift /= total;
          this.sway /= total;
        }
        total = SqrtF(PowF(this.yaw, 2.0) + PowF(this.roll, 2.0) + PowF(this.pitch, 2.0));
        if (total > 1.0) {
          this.yaw /= total;
          this.roll /= total;
          this.pitch /= total;
        }
      } else {
        let v = this.GetVehicle();
        this.surge = v.acceleration * 0.5 - v.deceleration * 0.1;
        this.yaw = -v.turnX;
        this.linearBrake = v.handbrake * 0.5;
        this.angularBrake = v.handbrake * 0.5;
      }
    } else {
      this.yaw = 0.0;
      this.roll = 0.0;
      this.pitch = 0.0;
      this.lift = 0.0;
      this.linearBrake = 0.0;
      this.angularBrake = 0.0;
      this.surge = 0.0;
      this.sway = 0.0;
    }

    this.stats.UpdateDynamic();

    let force = new Vector4(0.0, 0.0, 0.0, 0.0);
    let torque = new Vector4(0.0, 0.0, 0.0, 0.0);

    let shouldModeUpdate = this.active;
    if IsDefined(this.trick) {
      if this.trick.Update(timeDelta) {
        this.trick = null;
      } else {
        force += this.trick.force;
        torque += this.trick.torque;
        shouldModeUpdate = !this.trick.suspendMode;
      }
    }

    if this.mode < ArraySize(this.modes) {
      if shouldModeUpdate {
        this.modes[this.mode].Update(timeDelta);
        force += this.modes[this.mode].force * this.configuration.percentageAttached;
        torque += this.modes[this.mode].torque;
      }
    }



    // process user-inputted force/torque in visuals/audio
    this.UpdateAudioParams(timeDelta, force, torque);
    this.smoothForce = force;
    this.smoothTorque = torque;
    for thruster in this.configuration.thrusters {
      thruster.Update(force, torque);
    }

    if this.isPlayerMounted {
      // this.sys.ctlr.GetBlackboard().SetVector4(GetAllBlackboardDefs().VehicleFlight.Force, force);
      // this.sys.ctlr.GetBlackboard().SetVector4(GetAllBlackboardDefs().VehicleFlight.Torque, torque);
      this.sys.ctlr.GetBlackboard().SetFloat(GetAllBlackboardDefs().VehicleFlight.Pitch, 90.0 - Vector4.GetAngleBetween(this.stats.d_forward, FlightUtils.Up())); //(this.stats.d_forward, this.stats.d_forward2D, Vector4.Cross(this.stats.d_forward2D, FlightUtils.Up())), false);
      this.sys.ctlr.GetBlackboard().SetFloat(GetAllBlackboardDefs().VehicleFlight.Roll, Vector4.GetAngleDegAroundAxis(this.stats.d_localUp, FlightUtils.Up(), FlightUtils.Forward()), false);
      // this.sys.ctlr.GetBlackboard().SignalFloat(GetAllBlackboardDefs().VehicleFlight.Pitch);
      // this.sys.ctlr.GetBlackboard().SetVector4(GetAllBlackboardDefs().VehicleFlight.Position, this.stats.d_position);
      // this.sys.ctlr.GetBlackboard().SignalVector4(GetAllBlackboardDefs().VehicleFlight.Position);
    }

    // apply physics helpers
    if this.mode < ArraySize(this.modes) {
      this.modes[this.mode].ApplyPhysics(timeDelta);
      force += this.modes[this.mode].force;
      torque += this.modes[this.mode].torque;
      // this.angularDamp = this.modes[this.mode].angularDamp;
      // this.linearDamp = this.modes[this.mode].linearDamp;
    }

    force *= timeDelta;
    // force *= 1.0/60.0;

    // factor in mass
    force *= this.stats.s_mass;
    // convert to global
    force = this.stats.d_orientation * force;

    // need something similar that affects force
    // force.X *= this.thrusterTensor.X;
    // force.Y *= this.thrusterTensor.Y;
    // force.Z *= this.thrusterTensor.Z;

    torque *= timeDelta;
    // torque *= 1.0/60.0;

    // factor in inertia tensor - maybe half?
    // let it = this.GetVehicle().GetInertiaTensor();
    // let v = Vector4.Normalize(new Vector4(PowF(it.X.X, 0.5), PowF(it.Y.Y, 0.5), PowF(it.Z.Z, 0.5), 0.0));
    // torque.X *= v.X;
    // torque.Y *= v.Y;
    // torque.Z *= v.Z;
    // torque *= it;

    // assume thrusters combined are capable of holding the weight of the vehicle
    torque *= this.stats.s_mass;
    // torque *= 1500.0;

    // factor in where thrusters are
    torque.X *= this.thrusterTensor.X;
    torque.Y *= MaxF(this.thrusterTensor.Y, 1.0); // prevents bikes from rolling excessively
    torque.Z *= this.thrusterTensor.Z;

    // convert to global
    torque = this.stats.d_orientation * torque;

    if this.collisionTimer < FlightSettings.GetFloat("collisionRecoveryDelay") + FlightSettings.GetFloat("collisionRecoveryDuration") {
      let collisionDampener = MinF(MaxF(0.0, (this.collisionTimer - FlightSettings.GetFloat("collisionRecoveryDelay")) / FlightSettings.GetFloat("collisionRecoveryDuration")), 1.0);
      torque *= collisionDampener;
      force *= collisionDampener;
      this.collisionTimer += timeDelta;
    }

    this.force += force;
    this.torque += torque;
  }

  protected cb func OnVehicleFlightDeactivationEvent(evt: ref<VehicleFlightDeactivationEvent>) -> Bool {
    FlightLog.Info("[FlightComponent] OnVehicleFlightDeactivationEvent: " + this.GetVehicle().GetDisplayName());
    this.Deactivate(evt.silent);
  }

  protected cb func OnFlightFxCleanedUp(evt: ref<FlightFxCleanedUpEvent>) -> Bool {
    if !this.active {
      this.hasUpdate = false;
    }
  }

  public func Deactivate(silent: Bool) -> Void {
    this.active = false;
    for thruster in this.configuration.thrusters {
      thruster.Stop();
    }

    if this.isDestroyed && this.hasExploded && this.alarmIsPlaying {
        FlightAudio.Get().Stop("vehicleDestroyed" + this.GetUniqueID());
    }

    if !silent {
      this.GetVehicle().TurnEngineOn(true);
    }

    if !FlightSettings.GetInstance().generalApplyFlightPhysicsWhenDeactivated {
      let evt = new FlightFxCleanedUpEvent();
      GameInstance.GetDelaySystem(this.GetVehicle().GetGame()).DelayEvent(this.GetVehicle(), evt, evt.delay);
    }

    if this.isPlayerMounted {
      this.sys.ctlr.Deactivate(silent);
      if !silent {
        FlightAudio.Get().Play("vehicle3_off");
      }
      // this.sys.audio.Stop("playerVehicle");
      // this.sys.audio.Stop("leftFront");
      // this.sys.audio.Stop("rightFront");
      // this.sys.audio.Stop("leftRear");
      // this.sys.audio.Stop("rightRear");
    }
    // this.sys.audio.Stop("vehicle" + this.GetUniqueID());

    this.configuration.OnDeactivationCore();
  }

  protected cb func OnGridDestruction(evt: ref<VehicleGridDestructionEvent>) -> Bool {
    let biggestImpact: Float;
    let desiredChange: Float;
    let gridState: Float;
    let i: Int32 = 0;
    let gridID = 0;
    while i < 16 {
      gridState = evt.state[i];
      desiredChange = evt.desiredChange[i];
      if desiredChange > biggestImpact {
        biggestImpact = desiredChange;
        gridID = i;
      };
      i += 1;
    };
      // FlightLog.Info("[FlightComponent] OnGridDestruction: " + FloatToStringPrec(biggestImpact, 2));
    if biggestImpact > 0.00 {
      this.ProcessImpact(biggestImpact);
      if this.isPlayerMounted {
        this.sys.ctlr.ProcessImpact(biggestImpact);
      } else {
        // let pc = FlightSystem.GetInstance().playerComponent;
        // if IsDefined(pc) && IsDefined(pc.GetVehicle()) {
        //   this.ChaseTarget(pc.GetVehicle());
        //   // this.ChaseTarget();
        // }
        // if biggestImpact > 0.00 {
        //   if !this.active {
        //     this.Activate();
        //   } else {
        //     // this.Deactivate(true);
        //   }
        // }
        if !this.active && this.GetVehicle().bouncy {
          this.FireVerticalImpulse(gridID);
        }
        if biggestImpact > this.explosionThreshold {
          GameObjectEffectHelper.StartEffectEvent(this.GetVehicle(), n"explosion");
        }
        // let event = new vehicleDriveToPointEvent();
        // event.targetPos = new Vector3(0.0, 0.0, 0.0);
        // vehicle.QueueEvent(event);
      }
    }
  }

  public func HandleExplosion() -> Void {
    this.isDestroyed = true;
    this.hasExploded = true;
    this.hasUpdate = false;
    this.Deactivate(true);
  }

  // protected cb func OnHit(evt: ref<gameHitEvent>) -> Bool {
  //   let vehicle: ref<VehicleObject> = this.GetVehicle();
  //   let gameInstance: GameInstance = vehicle.GetGame();
  //   let player: ref<PlayerPuppet> = GetPlayer(gameInstance);
  //   let isPlayerMounted = VehicleComponent.IsMountedToProvidedVehicle(gameInstance, player.GetEntityID(), vehicle);
  //   FlightLog.Info("[FlightComponent] OnPhysicalCollision: " + FloatToStringPrec(evt.attackData.vehicleImpactForce, 2));
  //   if isPlayerMounted {
  //       this.sys.ctlr.ProcessImpact(evt.attackData.vehicleImpactForce);
  //   } else {
  //     let impulseEvent: ref<PhysicalImpulseEvent> = new PhysicalImpulseEvent();
  //     impulseEvent.radius = 1.0;
  //     impulseEvent.worldPosition = Vector4.Vector4To3(evt.hitPosition);
  //     impulseEvent.worldImpulse = new Vector3(0.0, 0.0, evt.attackData.vehicleImpactForce);
  //     this.GetVehicle().QueueEvent(impulseEvent);
  //   }
  // }

  // idk if this is needed still
  // protected cb func OnInteractionActivated(evt: ref<InteractionActivationEvent>) -> Bool {
  //   let radialRequest: ref<ResolveQuickHackRadialRequest>;
  //   if !IsDefined(evt.activator as PlayerPuppet) && !IsDefined(evt.activator as Muppet) {
  //     return false;
  //   };
  //   radialRequest = new ResolveQuickHackRadialRequest();
  //   this.GetVehicle().GetHudManager().QueueRequest(radialRequest);
  // }

  // idk if this is needed still
  // protected cb func OnSetExposeQuickHacks(evt: ref<SetExposeQuickHacks>) -> Bool {
  //   let request: ref<RefreshActorRequest> = new RefreshActorRequest();
  //   request.ownerID = this.GetVehicle().GetEntityID();
  //   this.GetVehicle().GetHudManager().QueueRequest(request);
  // }

  // protected cb func OnActionEngineering(evt: ref<ActionEngineering>) -> Bool {
  //   FlightLog.Info("[FlightComponent] OnActionEngineering");
  //   // this.FireVerticalImpulse();
  // }

  // public func OnQuickHackFlightMalfunction(evt: ref<QuickHackFlightMalfunction>) -> EntityNotificationType {
  //   FlightLog.Info("[FlightComponent] OnQuickHackFlightMalfunction");
  //   // let type: EntityNotificationType = this.OnQuickHackFlightMalfunction(evt);
  //   // if Equals(type, EntityNotificationType.DoNotNotifyEntity) {
  //   //   return type;
  //   // };
  //   if evt.IsStarted() {
  //     // this.ExecutePSAction(this.FireVerticalImpulse());
  //     // this.FireVerticalImpulse();
  //   };
  //   return EntityNotificationType.SendThisEventToEntity;
  // }

  // gridID
  // 0 rear left
  // 1 rear right
  // 2 -
  // 3 -
  // 4 door left
  // 5 door right
  // 6 front left
  // 7 front right

  public func FireVerticalImpulse(gridID: Int32, opt impulse: Float) {
    let impulseEvent: ref<PhysicalImpulseEvent> = new PhysicalImpulseEvent();
    impulseEvent.radius = 1.0;
    let offset = new Vector4(0.0, 0.0, 0.0, 0.0);
    if gridID == 0 {
      offset = new Vector4(-0.5, -0.5, 0.0, 0.0);
    }
    if gridID == 1 {
      offset = new Vector4(0.5, -0.5, 0.0, 0.0);
    }
    if gridID == 4 {
      offset = new Vector4(-0.5, 0.0, 0.0, 0.0);
    }
    if gridID == 5 {
      offset = new Vector4(0.5, 0.0, 0.0, 0.0);
    }
    if gridID == 6 {
      offset = new Vector4(-0.5, 0.5, 0.0, 0.0);
    }
    if gridID == 7 {
      offset = new Vector4(0.5, 0.5, 0.0, 0.0);
    }
    if impulse == 0.0 {
      impulse = 1.0;
    }
    // FlightLog.Info("[FlightComponent] FireVerticalImpulse: " + gridID);
    impulseEvent.worldPosition = Vector4.Vector4To3(this.GetVehicle().GetLocalToWorld() * offset);
    impulseEvent.worldImpulse = new Vector3(0.0, 0.0, 20.0 * impulse * this.GetVehicle().GetTotalMass());
    // impulseEvent.worldImpulse = new Vector3(0.0, 0.0, 10000.0 * impulse);
    this.GetVehicle().QueueEvent(impulseEvent);
  }

  // protected cb func OnPhysicalCollision(evt: ref<PhysicalCollisionEvent>) -> Bool {
  //   FlightLog.Info("[FlightComponent] OnPhysicalCollision");
  //   let vehicle = this.GetVehicle();
  //   let gameInstance: GameInstance = vehicle.GetGame();
  //   let player: ref<PlayerPuppet> = GetPlayer(gameInstance);
  //   let isPlayerMounted = VehicleComponent.IsMountedToProvidedVehicle(gameInstance, player.GetEntityID(), this);
  //   if isPlayerMounted {
  //     // this.sys.ctlr.ProcessImpact(evt.attackData.vehicleImpactForce);
  //   } else {
  //     let impulseEvent: ref<PhysicalImpulseEvent> = new PhysicalImpulseEvent();
  //     impulseEvent.radius = 1.0;
  //     impulseEvent.worldPosition = Vector4.Vector4To3(evt.worldPosition);
  //     impulseEvent.worldImpulse = new Vector3(0.0, 0.0, 10000.0);
  //     vehicle.QueueEvent(impulseEvent);
  //   }
  // }

  // protected cb func OnHit(evt: ref<gameHitEvent>) -> Bool {
  //   FlightLog.Info("[FlightComponent] OnHit: " + FloatToStringPrec(evt.attackData.vehicleImpactForce, 2));
  //   let vehicle = this.GetVehicle();
  //   let gameInstance: GameInstance = vehicle.GetGame();
  //   let player: ref<PlayerPuppet> = GetPlayer(gameInstance);
  //   let isPlayerMounted = VehicleComponent.IsMountedToProvidedVehicle(gameInstance, player.GetEntityID(), this);
  //   if isPlayerMounted {
  //     this.sys.ctlr.ProcessImpact(evt.attackData.vehicleImpactForce);
  //   } else {
  //     let impulseEvent: ref<PhysicalImpulseEvent> = new PhysicalImpulseEvent();
  //     impulseEvent.radius = 1.0;
  //     impulseEvent.worldPosition = Vector4.Vector4To3(evt.hitPosition);
  //     impulseEvent.worldImpulse = new Vector3(0.0, 0.0, evt.attackData.vehicleImpactForce);
  //     vehicle.QueueEvent(impulseEvent);
  //   }
  // }

  // public cb func OnAnyEvent(evt: ref<Event>) {
  //   FlightLog.Info("[FlightComponent] OnAnyEvent: " + ToString(evt.GetClassName()));
  // }

  // hook into sound somehow
  // protected cb func OnVehicleOnPartDetached(evt: ref<VehicleOnPartDetachedEvent>) -> Bool {
  //   let partName: CName = evt.partName;
  //   if Equals(partName, n"Trunk") {
  //     (this.GetPS() as VehicleComponentPS).SetDoorState(EVehicleDoor.trunk, VehicleDoorState.Detached);
  //   } else {
  //     if Equals(partName, n"Hood") {
  //       (this.GetPS() as VehicleComponentPS).SetDoorState(EVehicleDoor.hood, VehicleDoorState.Detached);
  //     } else {
  //       if Equals(partName, n"DoorFrontLeft") || Equals(partName, n"DoorFrontLeft_A") || Equals(partName, n"DoorFrontLeft_B") || Equals(partName, n"DoorFrontLeft_C") {
  //         (this.GetPS() as VehicleComponentPS).SetDoorState(EVehicleDoor.seat_front_left, VehicleDoorState.Detached);
  //       } else {
  //         if Equals(partName, n"DoorFrontRight") || Equals(partName, n"DoorFrontRight_A") || Equals(partName, n"DoorFrontRight_B") || Equals(partName, n"DoorFrontRight_C") {
  //           (this.GetPS() as VehicleComponentPS).SetDoorState(EVehicleDoor.seat_front_right, VehicleDoorState.Detached);
  //         } else {
  //           if Equals(partName, n"DoorBackLeft") {
  //             (this.GetPS() as VehicleComponentPS).SetDoorState(EVehicleDoor.seat_back_left, VehicleDoorState.Detached);
  //           } else {
  //             if Equals(partName, n"DoorBackRight") {
  //               (this.GetPS() as VehicleComponentPS).SetDoorState(EVehicleDoor.seat_back_right, VehicleDoorState.Detached);
  //             };
  //           };
  //         };
  //       };
  //     };
  //   };
  // }

  protected final func OnVehicleCameraChange(state: Bool) -> Void {
    this.sys.ctlr.isTPP = state;
  }

  public func ProcessImpact(impact: Float) {
    this.collisionTimer = (FlightSettings.GetFloat("collisionRecoveryDelay") + FlightSettings.GetFloat("collisionRecoveryDuration")) * (1.0 - (impact * this.GetFlightMode().collisionPenalty));
    // this.ui_info.StartGlitching(impact, FlightSettings.GetFloat("collisionRecoveryDuration") + impact);
  }

  public let audioUpdate: ref<FlightAudioUpdate>;

  public func UpdateAudioParams(timeDelta: Float, force: Vector4, torque: Vector4) -> Void {
    let ratio = 1.0;
    if this.collisionTimer < FlightSettings.GetFloat("collisionRecoveryDelay") + FlightSettings.GetFloat("collisionRecoveryDuration") {
      ratio = MaxF(0.0, (this.collisionTimer - FlightSettings.GetFloat("collisionRecoveryDelay")) / FlightSettings.GetFloat("collisionRecoveryDuration"));
    }

    let vehicleID = Cast<StatsObjectID>(this.GetVehicle().GetEntityID());
    let vehHealthPercent = GameInstance.GetStatPoolsSystem(this.GetVehicle().GetGame()).GetStatPoolValue(vehicleID, gamedataStatPoolType.Health);
    // this.audioUpdate.damage = 1.0 - MaxF(GameInstance.GetStatPoolsSystem(this.GetVehicle().GetGame()).GetStatPoolValue(Cast<StatsObjectID>(this.GetVehicle().GetEntityID()), gamedataStatPoolType.Health, false) + ratio, 1.0);
    if this.isDestroyed {
      this.audioUpdate.damage = 0.25;
    } else {
      this.audioUpdate.damage = (1.0 - (vehHealthPercent / 100.0)) * 0.2;
    }
    if this.isPlayerMounted {
      // more responsive-sounding
      this.audioUpdate.surge = this.sys.ctlr.surge.GetInput() * ratio;
      this.audioUpdate.yaw = this.sys.ctlr.yaw.GetInput() * ratio;
      this.audioUpdate.sway = this.sys.ctlr.sway.GetInput() * ratio;
      if IsDefined(this.GetFlightMode() as FlightModeDrone) {
        this.audioUpdate.lift = this.sys.ctlr.lift.GetInput() * ratio;
        this.audioUpdate.roll = this.sys.ctlr.roll.GetInput() * ratio;
        this.audioUpdate.pitch = this.sys.ctlr.pitch.GetInput() * ratio;
      } else {
        this.audioUpdate.lift = (Vector4.Dot(Vector4.Normalize(force), this.stats.d_localUp) * 0.1 + this.sys.ctlr.lift.GetInput()) * ratio;
        this.audioUpdate.roll = this.roll * ratio;
        this.audioUpdate.pitch = this.pitch * ratio;
      }
    } else {
      this.audioUpdate.surge = this.surge * ratio;
      this.audioUpdate.lift = (Vector4.Dot(Vector4.Normalize(force), this.stats.d_localUp) * 0.1 + this.lift) * ratio;
      this.audioUpdate.roll = this.roll * ratio;
      this.audioUpdate.pitch = this.pitch * ratio;
      this.audioUpdate.yaw = this.yaw * ratio;
    }
    // if this.mode == 3 {
    //   this.audioUpdate.surge *= 0.5;
    //   this.audioUpdate.surge += this.lift * ratio * 0.5;
    // }
    // this.audioUpdate.lift = this.lift * ratio;
    // this.audioUpdate.brake = this.brake;
    this.audioUpdate.brake = MaxF(this.sys.ctlr.linearBrake.GetInput(), this.sys.ctlr.angularBrake.GetInput());
    // this.audioUpdate.brake = Vector4.Dot(-force, this.stats.d_direction);

    this.UpdateAudioParams(timeDelta);
  }

  public func UpdateAudioParams(timeDelta: Float) -> Void {
    this.sys.audio.UpdateSlotProviders();

    // let leftFrontPosition = this.sys.audio.GetPosition(n"wheel_front_left") - (this.stats.d_velocity * timeDelta);
    // let rightFrontPosition = this.sys.audio.GetPosition(n"wheel_front_right") - (this.stats.d_velocity * timeDelta);
    // let leftRearPosition = this.sys.audio.GetPosition(n"wheel_back_left") - (this.stats.d_velocity * timeDelta);
    // let rightRearPosition = this.sys.audio.GetPosition(n"wheel_back_right") - (this.stats.d_velocity * timeDelta);

    // try without wind
    // let windLeftPosition = this.sys.audio.GetPosition(n"window_front_left_a"); // - (this.stats.d_velocity * timeDelta);
    // let windRightPosition = this.sys.audio.GetPosition(n"window_front_right_a"); //- (this.stats.d_velocity * timeDelta);

    // let listenerMatrix = (this.sys.player.FindComponentByName(n"soundListener") as IPlacedComponent).GetLocalToWorld();
    // let listenerMatrix = this.sys.tppCamera.GetLocalToWorld();
    // FlightAudio.Get().UpdateListener(Matrix.GetTranslation(listenerMatrix), Matrix.GetAxisY(listenerMatrix), Matrix.GetAxisZ(listenerMatrix));
    // FlightAudio.Get().UpdateListener(listenerMatrix);

    this.audioUpdate.speed = this.stats.d_speed;
    this.audioUpdate.yawDiff = Vector4.GetAngleDegAroundAxis(this.stats.d_forward, this.stats.d_direction, this.stats.d_up);
    this.audioUpdate.pitchDiff = Vector4.GetAngleDegAroundAxis(this.stats.d_forward, this.stats.d_direction, this.stats.d_right);

    // engineVolume *= (ratio * 0.5 + 0.5);

    // this.sys.audio.Update("leftFront", leftFrontPosition, engineVolume);
    // this.sys.audio.Update("rightFront", rightFrontPosition, engineVolume);
    // this.sys.audio.Update("leftRear", leftRearPosition, engineVolume);
    // this.sys.audio.Update("rightRear", rightRearPosition, engineVolume);
    if this.isPlayerMounted {
      this.audioUpdate.inside = this.sys.ctlr.isTPP ? MaxF(0.0, this.audioUpdate.inside - timeDelta * 4.0) : MinF(1.0, this.audioUpdate.inside + timeDelta * 4.0);
      // try without wind
      // FlightAudio.Get().UpdateEvent("windLeft", Matrix.BuiltTranslation(windLeftPosition), 1.0, this.audioUpdate);
      // FlightAudio.Get().UpdateEvent("windRight",  Matrix.BuiltTranslation(windRightPosition), 1.0, this.audioUpdate);
    } else {
      this.audioUpdate.inside = 0.0;
    }
    if this.active {
      // this.sys.audio.Update("vehicle" + this.GetUniqueID(), this.GetVehicle().GetLocalToWorld(), engineVolume, this.audioUpdate);
    }
    if this.isDestroyed && !this.GetVehicle().GetVehicleComponent().GetPS().GetHasExploded() && this.alarmIsPlaying {
      FlightAudio.Get().UpdateEvent("vehicleDestroyed" + this.GetUniqueID(), this.GetVehicle().GetLocalToWorld(), 1.0, this.audioUpdate);
    }
  }

  private func GetUniqueID() -> String {
    return ToString(EntityID.GetHash(this.GetVehicle().GetEntityID()));
  }

  public func SetupTires() -> Void {
    if this.GetVehicle() == (this.GetVehicle() as CarObject) {
      // this.fl_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"front_left_tire") as IPlacedComponent;
      // this.fr_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"front_right_tire") as IPlacedComponent;
      // this.bl_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"back_left_tire") as IPlacedComponent;
      // this.br_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"back_right_tire") as IPlacedComponent;
      this.fl_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"WheelAudioEmitterFL") as IPlacedComponent;
      this.fr_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"WheelAudioEmitterFR") as IPlacedComponent;
      this.bl_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"WheelAudioEmitterBL") as IPlacedComponent;
      this.br_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"WheelAudioEmitterBR") as IPlacedComponent;
      this.hood = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"VehicleHoodEmitter") as IPlacedComponent;
      this.trunk = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"VehicleTrunkEmitter") as IPlacedComponent;
    } else {
      this.fl_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"WheelAudioEmitterFront") as IPlacedComponent;
      this.fr_tire = this.fl_tire;
      this.bl_tire = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"WheelAudioEmitterBack") as IPlacedComponent;
      this.br_tire = this.bl_tire;
    }
  }

  public func FindGround(out normal: Vector4) -> Bool {
    // let lookAhead = this.stats.d_velocity * timeDelta * this.lookAheadMax;
    // let fl_tire: Vector4 = Matrix.GetTranslation(this.fl_tire.GetLocalToWorld()) - this.stats.d_velocity * timeDelta;
    // let fr_tire: Vector4 = Matrix.GetTranslation(this.fr_tire.GetLocalToWorld()) - this.stats.d_velocity * timeDelta;
    // let bl_tire: Vector4 = Matrix.GetTranslation(this.bl_tire.GetLocalToWorld()) - this.stats.d_velocity * timeDelta;
    // let br_tire: Vector4 = Matrix.GetTranslation(this.br_tire.GetLocalToWorld()) - this.stats.d_velocity * timeDelta;
    let fl_tire: Vector4 = Matrix.GetTranslation(this.fl_tire.GetLocalToWorld());
    let fr_tire: Vector4 = Matrix.GetTranslation(this.fr_tire.GetLocalToWorld());
    let bl_tire: Vector4 = Matrix.GetTranslation(this.bl_tire.GetLocalToWorld());
    let br_tire: Vector4 = Matrix.GetTranslation(this.br_tire.GetLocalToWorld());


    let findGround1: TraceResult;
    let findGround2: TraceResult;
    let findGround3: TraceResult;
    let findGround4: TraceResult;

    // all in engine\physics\collision_presets.json
    // VehicleBlocker? RagdollVehicle?
    let lookDown = new Vector4(0.0, 0.0, -FlightSettings.GetFloat("hoverModeMaxHoverHeight") - 10.0, 0.0);
    // this.sqs.SyncRaycastByCollisionGroup(fl_tire, fl_tire + lookDown, n"VehicleBlocker", findGround1, false, false);
    // this.sqs.SyncRaycastByCollisionGroup(fr_tire, fr_tire + lookDown, n"VehicleBlocker", findGround2, false, false);
    // this.sqs.SyncRaycastByCollisionGroup(bl_tire, bl_tire + lookDown, n"VehicleBlocker", findGround3, false, false);
    // this.sqs.SyncRaycastByCollisionGroup(br_tire, br_tire + lookDown, n"VehicleBlocker", findGround4, false, false);

    let queryFilter: QueryFilter;
    QueryFilter.AddGroup(queryFilter, n"VehicleBlocker");
    QueryFilter.AddGroup(queryFilter, n"Water");

    this.sqs.SyncRaycastByQueryFilter(fl_tire, fl_tire + lookDown, queryFilter, findGround1, false, false);
    this.sqs.SyncRaycastByQueryFilter(fr_tire, fr_tire + lookDown, queryFilter, findGround2, false, false);
    this.sqs.SyncRaycastByQueryFilter(bl_tire, bl_tire + lookDown, queryFilter, findGround3, false, false);
    this.sqs.SyncRaycastByQueryFilter(br_tire, br_tire + lookDown, queryFilter, findGround4, false, false);

    let groundPoint1: Vector4;
    let groundPoint2: Vector4;
    let groundPoint3: Vector4;
    let groundPoint4: Vector4;

    if TraceResult.IsValid(findGround1) {
      groundPoint1 = Vector4.Vector3To4(findGround1.position);// - this.stats.d_velocity * timeDelta;
      // if this.showUI {
      //   this.ui.DrawMark(groundPoint1);
      //   this.ui.DrawText(groundPoint1, FloatToStringPrec(Vector4.Distance(fl_tire, Cast(findGround1.position)), 2));
      // }
    }
    if TraceResult.IsValid(findGround2) {
      groundPoint2 = Vector4.Vector3To4(findGround2.position);// - this.stats.d_velocity * timeDelta;
      // if this.showUI {
      //   this.ui.DrawMark(groundPoint2);
      //   this.ui.DrawText(groundPoint2, FloatToStringPrec(Vector4.Distance(fr_tire, Cast(findGround2.position)), 2));
      // }
    }
    if TraceResult.IsValid(findGround3) {
      groundPoint3 = Vector4.Vector3To4(findGround3.position);// - this.stats.d_velocity * timeDelta;
      // if this.showUI {
      //   this.ui.DrawMark(groundPoint3);
      //   this.ui.DrawText(groundPoint3, FloatToStringPrec(Vector4.Distance(bl_tire, Cast(findGround3.position)), 2));
      // }
    }
    if TraceResult.IsValid(findGround4) {
      groundPoint4 = Vector4.Vector3To4(findGround4.position);// - this.stats.d_velocity * timeDelta;
      // if this.showUI {
      //   this.ui.DrawMark(groundPoint4);
      //   this.ui.DrawText(groundPoint4, FloatToStringPrec(Vector4.Distance(br_tire, Cast(findGround4.position)), 2));
      // }
    }

    if TraceResult.IsValid(findGround1) && TraceResult.IsValid(findGround2) && TraceResult.IsValid(findGround3) && TraceResult.IsValid(findGround4) {
      // let distance = MinF(
      //   MinF(Vector4.Distance(fl_tire, Cast(findGround1.position)),
      //   Vector4.Distance(fr_tire, Cast(findGround2.position))),
      //   MinF(Vector4.Distance(bl_tire, Cast(findGround3.position)),
      //   Vector4.Distance(br_tire, Cast(findGround4.position))));
      let distance = (Vector4.Distance(fl_tire, Vector4.Vector3To4(findGround1.position)) +
        Vector4.Distance(fr_tire, Vector4.Vector3To4(findGround2.position)) +
        Vector4.Distance(bl_tire, Vector4.Vector3To4(findGround3.position)) +
        Vector4.Distance(br_tire, Vector4.Vector3To4(findGround4.position))) / 4.0;
      // this.distance = distance * (1.0 - this.distanceEase) + this.distance * (this.distanceEase);
      this.distance = distance;

      // FromVariant(scriptInterface.GetStateVectorParameter(physicsStateValue.Radius)) maybe?
      let n = (Vector4.Normalize(Cast(findGround1.normal)) + Vector4.Normalize(Cast(findGround2.normal)) + Vector4.Normalize(Cast(findGround3.normal)) + Vector4.Normalize(Cast(findGround4.normal))) / 4.0;
      // this.normal = Vector4.Interpolate(this.normal, normal, this.normalEase);
      normal = Vector4.Normalize(n);

      return true;
    } else {
      return false;
    }
  }

  // idk if this is needed still
  // protected cb func OnHUDInstruction(evt: ref<HUDInstruction>) -> Bool {
  //   // working
  //   // FlightLog.Info("[FlightComponent] OnHUDInstruction");
  //   if evt.quickhackInstruction.ShouldProcess() {
  //     // FlightLog.Info("[FlightComponent] quickhackInstructions.ShouldProcess");
  //     // this.GetVehicle().TryOpenQuickhackMenu(true);
  //     this.GetVehicle().TryOpenQuickhackMenu(evt.quickhackInstruction.ShouldOpen());
  //   };
  // }


	// protected cb func OnFlightMalfunction(evt : ref<FlightMalfunction>) -> Bool {
  //     FlightLog.Info("[FlightComponent] OnFlightMalfunction");
	// 	if evt.IsCompleted() {
	// 		this.Activate(false);
	// 	} else {
	// 		this.Activate(true);
	// 	}
	// }


	// protected event OnHUDInstruction( evt : HUDInstruction )
	// {
	// 	super.OnHUDInstruction( evt );
	// 	if( evt.highlightInstructions.GetState() == InstanceState.ON )
	// 	{
	// 		GetDevicePS().SetFocusModeData( true );
	// 		ResolveDeviceOperationOnFocusMode( gameVisionModeType.Focus, true );
	// 	}
	// 	else
	// 	{
	// 		if( evt.highlightInstructions.WasProcessed() )
	// 		{
	// 			GetDevicePS().SetFocusModeData( false );
	// 			ToggleAreaIndicator( false );
	// 			ResolveDeviceOperationOnFocusMode( gameVisionModeType.Default, false );
	// 			NotifyConnectionHighlightSystem( false, false );
	// 		}
	// 	}
	// 	if( evt.quickhackInstruction.ShouldProcess() )
	// 	{
	// 		TryOpenQuickhackMenu( evt.quickhackInstruction.ShouldOpen() );
	// 	}
	// }


  protected let m_attacksSpawned: array<ref<EffectInstance>>;

  public func OnFireWeapon(placeholderQuat: Quaternion, weaponItem:TweakDBID, attachmentSlot: TweakDBID) -> Void {
    // let weapon = TweakDBInterface.GetWeaponItemRecord(weaponItem);
    let wt: WorldTransform;
    let vehicleSlots = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"vehicle_slots") as SlotComponent;
    vehicleSlots.GetSlotTransform(StringToName(TweakDBInterface.GetAttachmentSlotRecord(attachmentSlot).EntitySlotName()), wt);
    let quat = WorldTransform.GetOrientation(wt);
    // let start = WorldPosition.ToVector4(WorldTransform.GetWorldPosition(wt));
    // let end = Vector4.Vector3To4(tracePosition);
    // WorldTransform.SetPosition(wt, start)
    WorldTransform.SetOrientation(wt, quat * placeholderQuat);

    let effect = ResRefToFxResource(r"base\\fx\\vehicles\\av\\av_panzer\\weapons\\v_panzer_muzzle_flash.effect");
    // let effect = ResRefToFxResource(r"base\\fx\\weapons\\firearms\\_muzzle_lights\\smart\\w_s_rifles_mq_muzzle_lights_tpp.effect");
    let fxSystem = GameInstance.GetFxSystem(this.GetVehicle().GetGame());
    if IsDefined(fxSystem) {
      fxSystem.SpawnEffect(effect, wt);
    }


    // let attack: ref<Attack_GameEffect>;
    // let attackContext: AttackInitContext;
    // let effect: ref<EffectInstance>;
    // let position: Vector4;
    // let slotTransform: WorldTransform;
    // let statMods: array<ref<gameStatModifierData>>;
    // let slotName = StringToName(TweakDBInterface.GetAttachmentSlotRecord(attachmentSlot).EntitySlotName());
    // let validSlotPosition: Bool = vehicleSlots.GetSlotTransform(slotName, slotTransform);
    // if validSlotPosition {
    //   position = WorldPosition.ToVector4(WorldTransform.GetWorldPosition(slotTransform));
    // } else {
    //   position = WorldPosition.ToVector4(WorldTransform.GetWorldPosition(this.GetVehicle().GetWorldTransform()));
    // };
    // attackContext.source = this.GetVehicle();
    // attackContext.record = weapon.RangedAttacks().DefaultFire().PlayerAttack();
    // attackContext.instigator = this.sys.player;
    // attack = IAttack.Create(attackContext) as Attack_GameEffect;
    // attack.GetStatModList(statMods);
    // effect = attack.PrepareAttack(this.sys.player);
    // EffectData.SetVector(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.position, position);
    // EffectData.SetVector(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.muzzlePosition, position);
    // EffectData.SetVector(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.forward, Quaternion.GetForward(placeholderQuat));
    // EffectData.SetVariant(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.attack, ToVariant(attack));
    // EffectData.SetVariant(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.attackStatModList, ToVariant(statMods));
    // attack.StartAttack();

    // effect.AttachToSlot(this.GetVehicle(), slotName, GetAllBlackboardDefs().EffectSharedData.position, GetAllBlackboardDefs().EffectSharedData.forward);

    // ArrayPush(this.m_attacksSpawned, effect);

    let broadcaster = this.sys.player.GetStimBroadcasterComponent();
    if IsDefined(broadcaster) {
      broadcaster.TriggerSingleBroadcast(this.sys.player, gamedataStimType.Gunshot, 25.0);
      let data: stimInvestigateData;
      data.illegalAction = true;
      data.attackInstigator = this.sys.player;
      broadcaster.TriggerSingleBroadcast(this.sys.player, gamedataStimType.Gunshot, 100.0, data, true);
    };

    // let tp: WorldPosition;
    // WorldPosition.SetVector4(tp, Vector4.Vector3To4(tracePosition));
    // fxi.UpdateTargetPosition(tp);
  }

/*  private final func RegisterToHUDManager(shouldRegister: Bool) -> Void {
    let hudManager: ref<HUDManager>;
    let registration: ref<HUDManagerRegistrationRequest>;
    if this.GetVehicle().IsCrowdVehicle() && !this.GetVehicle().ShouldForceRegisterInHUDManager() {
      return;
    };
    hudManager = GameInstance.GetScriptableSystemsContainer(this.GetVehicle().GetGame()).Get(n"HUDManager") as HUDManager;
    if IsDefined(hudManager) {
      registration = new HUDManagerRegistrationRequest();
      registration.SetProperties(this.GetVehicle(), shouldRegister);
      hudManager.QueueRequest(registration);
    };
  }
*/
}


// Flight/FlightController.reds

// public class FlightSettingsListener extends ConfigVarListener {

//   private let m_ctrl: wref<FlightController>;

//   public final func RegisterController(ctrl: ref<FlightController>) -> Void {
//     this.m_ctrl = ctrl;
//   }

//   public func OnVarModified(groupPath: CName, varName: CName, varType: ConfigVarType, reason: ConfigChangeReason) -> Void {
//     this.m_ctrl.OnVarModified(groupPath, varName, varType, reason);
//   }
// }

// could watch this
// this.m_callbackID = scriptInterface.localBlackboard.RegisterListenerInt(allBlackboardDef.PlayerStateMachine.Vehicle, this, n"OnVehicleStateChanged");

public func fc() -> wref<FlightController> {
  return FlightController.GetInstance();
}

// public static func fcv() -> wref<VehicleObject> {
//   return FlightController.GetInstance().GetVehicle();
// }

public native class FlightController extends IScriptable {
  // defined on the RED4ext side
  private native let enabled: Bool;
  private native let active: Bool;
  public native let mode: Int32;
  public static native func GetInstance() -> ref<FlightController>;

  // redscript-only
  private let sys: ref<FlightSystem>;
  private let gameInstance: GameInstance;
  private let player: wref<PlayerPuppet>;
  private let m_callbackID: ref<CallbackHandle>;
  private let m_vehicleCollisionBBStateID: ref<CallbackHandle>;
  // private let ui: ref<FlightControllerUI>;
  // public final func SetUI(ui: ref<FlightControllerUI>) {
  //   this.ui = ui;
  // }
  public final func IsEnabled() -> Bool {
    return this.enabled;
  }
  public final func IsActive() -> Bool {
    return this.active;
  }

  public let showOptions: Bool;
  public let showUI: Bool;
  public let linearBrake: ref<InputPID>;
  public let angularBrake: ref<InputPID>;
  public let lift: ref<InputPID>;
  public let surge: ref<InputPID>;
  public let roll: ref<InputPID>;
  public let pitch: ref<InputPID>;
  public let yaw: ref<InputPID>;
  public let sway: ref<InputPID>;

  private let secondCounter: Float;

  public let isInAnyMenu: Bool;
  public let audioEnabled: Bool;

  public let isTPP: Bool;

  private let uiBlackboard: ref<IBlackboard>;
  private let uiSystemBB: ref<UI_SystemDef>;

  public let initialized: Bool;
  public let usingKB: Bool;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Flight-Toggle")
  public let vehicleFlight: EInputKey = EInputKey.IK_O;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Yaw-Left")
  public let vehicleFlightYawLeft: EInputKey = EInputKey.IK_A;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Yaw-Right")
  public let vehicleFlightYawRight: EInputKey = EInputKey.IK_D;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Pitch-Forward")
  public let vehicleFlightPitchForward: EInputKey = EInputKey.IK_L;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Pitch-Backward")
  public let vehicleFlightPitchBackward: EInputKey = EInputKey.IK_Period;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Roll-Left")
  public let vehicleFlightRollLeft: EInputKey = EInputKey.IK_Slash;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Roll-Right")
  public let vehicleFlightRollRight: EInputKey = EInputKey.IK_Comma;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Lift-Up")
  public let vehicleFlightLiftUp: EInputKey = EInputKey.IK_Space;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Lift-Down")
  public let vehicleFlightLiftDown: EInputKey = EInputKey.IK_LControl;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Sway-Left")
  public let vehicleFlightSwayLeft: EInputKey = EInputKey.IK_Left;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Sway-Right")
  public let vehicleFlightSwayRight: EInputKey = EInputKey.IK_Right;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Linear-Brake")
  public let vehicleFlightLinearBrake: EInputKey = EInputKey.IK_C;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Angular-Brake")
  public let vehicleFlightAngularBrake: EInputKey = EInputKey.IK_C;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Flight-Options")
  public let vehicleFlightOptions: EInputKey = EInputKey.IK_R;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Next-Mode")
  public let vehicleFlightModeSwitchForward: EInputKey = EInputKey.IK_G;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Prev-Mode")
  public let vehicleFlightModeSwitchBackward: EInputKey = EInputKey.IK_None;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Key-Bindings")
  @runtimeProperty("ModSettings.displayName", "Input-Hint-Toggle-UI")
  public let vehicleFlightUIToggle: EInputKey = EInputKey.IK_Y;

  // public let effectInstance: ref<EffectInstance>;

  // protected let m_settingsListener: ref<FlightSettingsListener>;
  // protected let m_groupPath: CName;

  private func Initialize() {
    FlightLog.Info("[FlightController] Initialize");
    this.sys = FlightSystem.GetInstance();
    // this.sys = GameInstance.GetScriptableSystemsContainer(player.GetGame()).Get(n"FlightSystem") as FlightSystem;
    this.enabled = false;
    this.active = false;
    this.showOptions = false;
    this.showUI = true;

    this.linearBrake = InputPID.Create(0.5, 0.5);
    this.angularBrake = InputPID.Create(0.5, 0.5);

    this.lift = InputPID.Create(0.1, 1.0);
    this.surge = InputPID.Create(0.1, 1.0);
    this.sway = InputPID.Create(0.1, 1.0);

    this.roll = InputPID.Create(0.5, 1.0);
    this.pitch = InputPID.Create(0.5, 1.0);
    this.yaw = InputPID.Create(0.5, 1.0);

    this.secondCounter = 0.0;

    this.audioEnabled = true;

    this.uiBlackboard = GameInstance.GetBlackboardSystem(this.gameInstance).Get(GetAllBlackboardDefs().UI_System);
    this.uiSystemBB = GetAllBlackboardDefs().UI_System;

    this.initialized = true;

    // this.trackedMappinId = this.uiBlackboard.RegisterListenerVariant(this.uiSystemBB.TrackedMappin, this, n"OnTrackedMappinUpdated");
    // this.uiBlackboard.SignalVariant(this.uiSystemBB.TrackedMappin);

    // this.waypoint = new Vector4(313.6, 208.2, 62.3, 0.0);


    // this.m_groupPath = n"/controls/flight";
    // this.m_settingsListener = new FlightSettingsListener();
    // this.m_settingsListener.RegisterController(this);
    // this.m_settingsListener.Register(this.m_groupPath);
  }

  private func SetPlayer(player: ref<PlayerPuppet>) {
    this.sys.Setup(player);
    this.gameInstance = player.GetGame();
    this.player = player;

    this.GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive, FlightSettings.GetFloat("isFlightUIActive") > 0.5);
  }

  public func GetBlackboard() -> ref<IBlackboard> {
    return GameInstance.GetBlackboardSystem(this.gameInstance).Get(GetAllBlackboardDefs().VehicleFlight);
  }

  public static func CreateInstance(player: ref<PlayerPuppet>) {
    // FlightLog.Info("[FlightController] CreateInstance Started");
    // let self: ref<FlightController> = new FlightController();
    let self = FlightController.GetInstance();
    if !self.initialized {
      self.Initialize();
    }
    self.SetPlayer(player);

    // This strong reference will tie the lifetime of the singleton
    // to the lifetime of the player entity
    // player.flightController = self;

    // This weak reference is used as a global variable
    // to access the mod instance anywhere
    // GetAllBlackboardDefs().flightController = self;
    // FlightLog.Info("[FlightController] CreateInstance Finished");
  }

  // public static func GetInstance() -> wref<FlightController> {
  //   return GetAllBlackboardDefs().flightController;
  // }

  // public final func OnVarModified(groupPath: CName, varName: CName, varType: ConfigVarType, reason: ConfigChangeReason) -> Void {
  //   switch varName {
  //     case n"HoverHeight":
  //       let configVar: ref<ConfigVarFloat> = GameInstance.GetSettingsSystem(this.gameInstance).GetVar(this.m_groupPath, n"HoverHeight") as ConfigVarFloat;
  //       this.hoverHeight = configVar.GetValue();
  //       break;
  //     default:
  //   };
  // }

  // public func SetupMountedToCallback(psmBB: ref<IBlackboard>) -> Void {
  //   this.m_callbackID = psmBB.RegisterListenerBool(GetAllBlackboardDefs().PlayerStateMachine.MountedToVehicle, this, n"OnMountedToVehicleChange");
  //   if psmBB.GetBool(GetAllBlackboardDefs().PlayerStateMachine.MountedToVehicle) {
  //     this.Enable();
  //   }
  // }

  // public cb func OnMountedToVehicleChange(mounted: Bool) -> Bool {
    // FlightLog.Info("[FlightController] OnMountedToVehicleChange");
    // if (mounted) {
    //   this.Enable();
    // } else {
    //   this.Disable();
    // }
  // }

  public func Enable() -> Void {
    this.enabled = true;
    FlightLog.Info("[FlightController] Enable");
    this.SetupActions();
  }

  public func Disable() -> Void {
    this.enabled = false;
    FlightLog.Info("[FlightController] Disable");
    this.SetupActions();
  }

  private func Activate(silent: Bool) -> Void {
    FlightLog.Info("[FlightController] Activate");
    this.enabled = true;
    this.active = true;
    this.SetupActions();

    this.pitch.Reset();
    this.roll.Reset();
    this.yaw.Reset();
    this.sway.Reset();
    this.surge.Reset();
    this.lift.Reset();
    this.linearBrake.Reset();
    this.angularBrake.Reset();

    // let data: InputHintGroupData;
    // data.localizedTitle = "Flight Control";
    // data.localizedDescription = "The controls used in Let There Be Flight";
    // data.sortingPriority = 0;
    // let evt: ref<AddInputGroupEvent> = new AddInputGroupEvent();
    // evt.data = data;
    // evt.groupId = n"FlightController";
    // evt.targetHintContainer = n"GameplayInputHelper";
    // GameInstance.GetUISystem(this.gameInstance).QueueEvent(evt);

    // let wheel = this.GetVehicle().GetVehicleComponent().FindComponentByName(n"wheel_01_br_a") as MeshComponent;
    // if IsDefined(wheel) {
    //   wheel.UpdateHardTransformBinding(n"vehicle_slots", n"wheel_back_left");
    //   this.GetVehicle().AddComponent(wheel);
    // }

    this.SetupPositionProviders();

    // this.sys.tppCamera = GetPlayer(this.gameInstance).FindComponentByName(n"vehicleTPPCamera") as vehicleTPPCameraComponent;

    // idk what to do with this
    // let uiSystem: ref<UISystem> = GameInstance.GetUISystem(this.gameInstance);
    // uiSystem.PushGameContext(IntEnum(10));

    // if (this.showUI) {
      // this.ui.Show();
      // FlightController.GetInstance().GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive, true);
    // }

    if !silent {
      this.ShowSimpleMessage(n"Simple-Message-Flight-Control-Engaged");
    }

    // this.GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsActive, true, true);
    // this.GetBlackboard().SignalBool(GetAllBlackboardDefs().VehicleFlight.IsActive);
  }

  private func Deactivate(silent: Bool) -> Void {
    this.active = false;
    this.SetupActions();

    //let uiSystem: ref<UISystem> = GameInstance.GetUISystem(this.gameInstance);
    //uiSystem.PopGameContext(IntEnum(10));

    if !silent {
      this.ShowSimpleMessage(n"Simple-Message-Flight-Control-Disengaged");
    }
    // if (this.showUI) {
    //   this.ui.Hide();
    // }
    // FlightController.GetInstance().GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive, false);

    FlightLog.Info("[FlightController] Deactivate");
    // this.GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsActive, false, true);
    // this.GetBlackboard().SignalBool(GetAllBlackboardDefs().VehicleFlight.IsActive);


    // let evt: ref<DeleteInputGroupEvent> = new DeleteInputGroupEvent();
    // evt.groupId = n"FlightControl";
    // evt.targetHintContainer = n"GameplayInputHelper";
    // GameInstance.GetUISystem(this.gameInstance).QueueEvent(evt);
  }

  private func ShowMoreInfo() -> Void {
    // very intrusive - need a prompt/confirmation that they want this popup, eg Detailed Info / About
    let shardUIevent = new NotifyShardRead();
    shardUIevent.title = "Flight Control: Now Available";
    shardUIevent.text = "Your new car is equiped with the state-of-the-art Flight Control!";
    GameInstance.GetUISystem(this.gameInstance).QueueEvent(shardUIevent);
  }

  private func SetupActions() -> Void {
    // FlightLog.Info("[FlightController] SetupActions");
    this.usingKB = this.player.PlayerLastUsedKBM();
    let evt = new UpdateInputHintMultipleEvent();
    evt.targetHintContainer = n"GameplayInputHelper";

    let uiSystem: ref<UISystem> = GameInstance.GetUISystem(this.gameInstance);
    this.player.UnregisterInputListener(this);
    // this.player.RegisterInputListener(this, n"OpenPauseMenu");
    // uiSystem.QueueEvent(FlightController.HideHintFromSource(n"FlightController"));
    if this.enabled {
      // this.player.RegisterInputListener(this, n"Flight_Toggle");
      if this.active {
        this.player.RegisterInputListener(this, n"__DEVICE_CHANGED__");
        this.player.RegisterInputListener(this, n"Pitch");
        this.player.RegisterInputListener(this, n"Sway");
        this.player.RegisterInputListener(this, n"Roll");
        this.player.RegisterInputListener(this, n"SurgePos");
        this.player.RegisterInputListener(this, n"Lift");
        this.player.RegisterInputListener(this, n"Yaw");
        this.player.RegisterInputListener(this, n"SurgeNeg");
        this.player.RegisterInputListener(this, n"Flight_LinearBrake");
        this.player.RegisterInputListener(this, n"Flight_AngularBrake");
        this.player.RegisterInputListener(this, n"Flight_Trick");
        this.player.RegisterInputListener(this, n"Flight_Options");
        this.player.RegisterInputListener(this, n"Flight_UIToggle");
        this.player.RegisterInputListener(this, n"Flight_ModeSwitchForward");
        this.player.RegisterInputListener(this, n"Flight_ModeSwitchBackward");
        this.player.RegisterInputListener(this, n"Flight_RightStickToggle");
        this.player.RegisterInputListener(this, n"Flight_HoodDetach");
      }
    }

    // if this.trick {
    //   evt.AddInputHint(FlightController.CreateInputHint(n"Aileron Roll", n"Yaw"), true);
    // } else {
      // evt.AddInputHint(FlightController.CreateInputHint("nTricks", n"Flight_Trick"), true);
    // }
    // we may want to look at something else besides this input so ForceBrakesUntilStoppedOrFor will work (not entirely sure it doesn't now)
    // vehicle.GetBlackboard().GetInt(GetAllBlackboardDefs().VehicleFlight.IsHandbraking)

    let usesRightStick = this.sys.playerComponent.GetFlightMode().usesRightStickInput;

    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Enable-Flight", n"Flight_Toggle"),       this.enabled && !this.active);

    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Disable-Flight", n"Flight_Toggle"),      this.active && !this.showOptions);
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Yaw", n"Yaw"),                           this.active && !this.showOptions);
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Pitch", n"Pitch"),                       this.active && !this.showOptions && (usesRightStick || this.usingKB));
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Roll", n"Roll"),                         this.active && !this.showOptions && (usesRightStick || this.usingKB));
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Lift", n"Lift"),                         this.active && !this.showOptions);
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Linear-Brake", n"Flight_LinearBrake"),   this.active && !this.showOptions && this.usingKB);
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Angular-Brake", n"Flight_AngularBrake"), this.active && !this.showOptions && this.usingKB);
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Brake", n"Flight_LinearBrake"),          this.active && !this.showOptions && !this.usingKB);
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Flight-Options", n"Flight_Options"),     this.active && !this.showOptions);

    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Sway", n"Sway"),                         this.active && this.showOptions && this.usingKB);
    // let desc: String;
    // desc = this.sys.playerComponent.GetNextFlightModeDescription();
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Next-Mode", n"Flight_ModeSwitchForward"),     this.active && (this.showOptions || this.usingKB));
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Prev-Mode", n"Flight_ModeSwitchBackward"),     this.active && this.showOptions && !this.usingKB);
    // evt.AddInputHint(FlightController.CreateInputHint(n"Raise Hover Height", n"FlightOptions_Up"), true);
    // evt.AddInputHint(FlightController.CreateInputHint(n"Lower Hover Height", n"FlightOptions_Down"), true);
    evt.AddInputHint(FlightController.CreateInputHint(n"Input-Hint-Toggle-UI", n"Flight_UIToggle"),         this.active && this.showOptions);
    // evt.AddInputHint(FlightController.CreateInputHint(n"Fire", n"ShootPrimary"),                 this.active && !this.showOptions);

    uiSystem.QueueEvent(evt);
  }

  private let trick: Bool;

  public func ProcessImpact(impact: Float) {
    // this.surge.Reset(this.surge.GetValue() * MaxF(0.0, 1.0 - impact * 5.0));
  }

  private func CycleMode(direction: Int32) -> Void {
    let newMode = this.sys.playerComponent.GetNextFlightMode(direction);
    this.mode = this.mode + direction;
    if this.mode < 0 {
      this.mode += ArraySize(this.sys.playerComponent.modes);
    }
    this.mode = this.mode % ArraySize(this.sys.playerComponent.modes);
    this.GetBlackboard().SetInt(GetAllBlackboardDefs().VehicleFlight.Mode, this.mode);
    let evt = new VehicleFlightModeChangeEvent();
    evt.mode = this.mode;
    GetMountedVehicle(this.player).QueueEvent(evt);
    this.ShowSimpleMessage(StringToName(newMode.GetDescription() + " " + GetLocalizedTextByKey(n"Simple-Message-Suffix-Enabled")));
    GameInstance.GetAudioSystem(this.gameInstance).Play(n"ui_menu_onpress");
    this.SetupActions();
  }

  protected func ResetInputs() {
      this.lift.SetInput(0.0);
      this.surge.SetInput(0.0);
      this.yaw.SetInput(0.0);
      this.sway.SetInput(0.0);
      this.pitch.SetInput(0.0);
      this.roll.SetInput(0.0);
      this.linearBrake.SetInput(0.0);
      this.angularBrake.SetInput(0.0);
  }

  protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
    if ListenerAction.IsAction(action, n"__DEVICE_CHANGED__") {
      if this.player.PlayerLastUsedKBM() {
        this.usingKB = true;
      } else {
        this.usingKB = false;
      }
      this.SetupActions();
    }
    let actionType: gameinputActionType = ListenerAction.GetType(action);
    let actionName: CName = ListenerAction.GetName(action);
    let value: Float = ListenerAction.GetValue(action);
    // FlightLog.Info(ToString(actionType) + ToString(actionName) + ToString(value));
    // if Equals(actionName, n"Flight_Toggle") && ListenerAction.IsButtonJustPressed(action) {
        // this.Toggle();
        // ListenerActionConsumer.ConsumeSingleAction(consumer);
    // }
    if this.active {
      // if Equals(actionName, n"Flight_ModeSwitchForward") && ListenerAction.IsButtonJustPressed(action) {
      //   this.CycleMode(1);
      // }
      if Equals(actionName, n"Flight_Options") {
        if ListenerAction.IsButtonJustPressed(action) {
          // FlightLog.Info("Options button pressed");
          this.showOptions = true;
          this.ResetInputs();
          // GameObjectEffectHelper.StartEffectEvent(this.GetVehicle(), n"summon_hologram", true);
          // if (this.showUI) {
          //   this.ui.ShowInfo();
          // }
          this.SetupActions();
        }
        if ListenerAction.IsButtonJustReleased(action) {
          // FlightLog.Info("Options button released");
          this.showOptions = false;
          this.ResetInputs();
          // GameObjectEffectHelper.BreakEffectLoopEvent(this.GetVehicle(), n"summon_hologram");
          this.SetupActions();
        }
      }

      // if Equals(actionName, n"Flight_Trick") {
      //   if ListenerAction.IsButtonJustPressed(action) {

          // let ps = this.sys.playerComponent.FindComponentByName(n"projectileSpawn8722") as ProjectileSpawnComponent;
          // ps.Spawn(Cast<Uint32>(0));

          // let attack: ref<Attack_GameEffect>;
          // let attackContext: AttackInitContext;
          // let effect: ref<EffectInstance>;
          // let statMods: array<ref<gameStatModifierData>>;
          // let position: Vector4;
          // let forward: Vector4;
          // attackContext.source = this.sys.playerComponent.GetVehicle();
          // attackContext.record = TweakDBInterface.GetAttackRecord(t"Attacks.ExplodingPanzerBulletProjectile");
          // attackContext.instigator = attackContext.source;
          // attack = IAttack.Create(attackContext) as Attack_GameEffect;
          // attack.GetStatModList(statMods);
          // effect = attack.PrepareAttack(this.sys.playerComponent.GetVehicle());
          // GameInstance.GetTargetingSystem(this.gameInstance).GetDefaultCrosshairData(this.sys.player, position, forward);
          // position = this.sys.playerComponent.stats.d_position + new Vector4(0.0, 0.0, 1.0, 0.0);
          // EffectData.SetVector(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.position, position);
          // EffectData.SetVector(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.muzzlePosition, position);
          // EffectData.SetVector(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.forward, this.sys.playerComponent.stats.d_forward);
          // // EffectData.SetVector(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.forward, forward);
          // EffectData.SetVariant(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.attack, ToVariant(attack));
          // EffectData.SetVariant(effect.GetSharedData(), GetAllBlackboardDefs().EffectSharedData.attackStatModList, ToVariant(statMods));
          // attack.StartAttack();

          // let wt: WorldTransform;
          // WorldTransform.SetPosition(wt, position);
          // WorldTransform.SetOrientation(wt, this.sys.playerComponent.stats.d_orientation);

          // let effect = ResRefToFxResource(r"base\\fx\\vehicles\\av\\av_panzer\\weapons\\v_panzer_muzzle_flash.effect");
          // GameInstance.GetFxSystem(this.sys.playerComponent.GetVehicle().GetGame()).SpawnEffect(effect, wt);
      //   }
      // }

          // // FlightLog.Info("Options button pressed");
          // this.trick = true;
          // let direction = 0.0;
          // if AbsF(this.sway.GetInput()) > 0.9 {
          //   direction = this.sway.GetInput();
          // }
          // if AbsF(this.yaw.GetInput()) > 0.9 {
          //   direction = this.yaw.GetInput();
          // }
          // if this.sys.playerComponent.trick == null  && AbsF(direction) > 0.9 {
          //   this.sys.playerComponent.trick = FlightTrickAileronRoll.Create(this.sys.playerComponent, Cast<Float>(RoundF(direction)));
          // }
          // this.SetupActions();
        // }
        // if ListenerAction.IsButtonJustReleased(action) {
        //   FlightLog.Info("Options button released");
        //   this.trick = false;
        //   this.SetupActions();
        // }
      // }
        // if Equals(actionName, n"FlightOptions_Up") && ListenerAction.IsButtonJustPressed(action) {
        //     this.hoverHeight += 0.1;
        //     GameInstance.GetAudioSystem(this.gameInstance).PlayFlightSound(n"ui_menu_onpress");
        //     FlightLog.Info("hoverHeight = " + ToString(this.hoverHeight));
        // }
        // if Equals(actionName, n"FlightOptions_Down") && ListenerAction.IsButtonJustPressed(action) {
        //     this.hoverHeight -= 0.1;
        //     GameInstance.GetAudioSystem(this.gameInstance).PlayFlightSound(n"ui_menu_onpress");
        //     FlightLog.Info("hoverHeight = " + ToString(this.hoverHeight));
        // }
      if Equals(actionName, n"Flight_HoodDetach") && ListenerAction.IsButtonJustPressed(action) {
        GameInstance.GetAudioSystem(this.gameInstance).Play(n"ui_menu_onpress");
        this.sys.playerComponent.GetVehicle().DetachPart(n"Hood");
        this.sys.playerComponent.GetVehicle().DetachPart(n"Trunk");
      }
      if Equals(actionName, n"Flight_RightStickToggle") && ListenerAction.IsButtonJustPressed(action) {
        GameInstance.GetAudioSystem(this.gameInstance).Play(n"ui_menu_onpress");
        this.sys.playerComponent.GetFlightMode().usesRightStickInput = !this.sys.playerComponent.GetFlightMode().usesRightStickInput;
        this.SetupActions();
      }
      if Equals(actionName, n"Flight_ModeSwitchForward") && ListenerAction.IsButtonJustPressed(action) && (this.showOptions || this.player.PlayerLastUsedKBM()) {
        this.CycleMode(1);
        this.SetupActions();
      }
      if Equals(actionName, n"Flight_ModeSwitchBackward") && ListenerAction.IsButtonJustPressed(action) && (this.showOptions || this.player.PlayerLastUsedKBM()) {
        this.CycleMode(-1);
        this.SetupActions();
      }
      if this.showOptions && Equals(actionName, n"Flight_UIToggle") && ListenerAction.IsButtonJustPressed(action) {
          this.showUI = !this.showUI;
          if (this.showUI) {
            this.GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive, true, true);
            this.ShowSimpleMessage(n"Simple-Message-Flight-UI-Shown");
          } else {
            this.GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive, false, true);
            this.ShowSimpleMessage(n"Simple-Message-Flight-UI-Hidden");
          }
          GameInstance.GetAudioSystem(this.gameInstance).Play(n"ui_menu_onpress");
      }

      if Equals(actionType, gameinputActionType.AXIS_CHANGE) {
        switch(actionName) {
          case n"Roll":
           if this.sys.playerComponent.GetFlightMode().usesRightStickInput || this.player.PlayerLastUsedKBM() {
            this.roll.SetInput(value);
           } else {
            this.roll.SetInput(0.0);
           }
            break;
          case n"Pitch":
            if this.sys.playerComponent.GetFlightMode().usesRightStickInput || this.player.PlayerLastUsedKBM() {
              this.pitch.SetInput(value);
            } else {
              this.pitch.SetInput(0.0);
            }
            break;
          case n"SurgePos":
            this.surge.SetInput(value);
            break;
          case n"Yaw":
            // if this.trick {
            //   if this.sys.playerComponent.trick == null  && AbsF(value) > 0.9 {
            //     this.sys.playerComponent.trick = FlightTrickAileronRoll.Create(this.sys.playerComponent, Cast<Float>(RoundF(value)));
            //   }
            //   this.yaw.SetInput(0.0);
            //   this.sway.SetInput(0.0);
            // } else {
              if this.showOptions {
                this.sway.SetInput(value);
                // this.yaw.SetInput(0.0);
              } else {
                // this.sway.SetInput(0.0);
                this.yaw.SetInput(value);
              }
            // }
            break;
          case n"Sway":
            this.sway.SetInput(value);
            break;
          case n"Lift":
            if this.trick {
              this.lift.SetInput(0.0);
            } else {
              this.lift.SetInput(value);
            }
            break;
          case n"SurgeNeg":
            this.surge.SetInput(-value);
            break;
          case n"Flight_LinearBrake":
            this.linearBrake.SetInput(value);
            break;
          case n"Flight_AngularBrake":
            this.angularBrake.SetInput(value);
            break;
          default:
            // return false;
            break;
        }
      }
        // ListenerActionConsumer.ConsumeSingleAction(consumer);
      // if Equals(actionName, n"Flight_LinearBrake") {
      //   if Equals(actionType, gameinputActionType.BUTTON_PRESSED) {
      //     this.linearBrake.SetInput(1.0);
      //   } else {
      //     this.linearBrake.SetInput(0.0);
      //   }
      // }
      // if Equals(actionName, n"Flight_AngularBrake") {
      //   if Equals(actionType, gameinputActionType.BUTTON_PRESSED) {
      //     this.angularBrake.SetInput(1.0);
      //   } else {
      //     this.angularBrake.SetInput(0.0);
      //   }
      // }
    } else {
      this.lift.SetInput(0.0);
      this.surge.SetInput(0.0);
      this.yaw.SetInput(0.0);
      this.sway.SetInput(0.0);
      this.pitch.SetInput(0.0);
      this.roll.SetInput(0.0);
      this.linearBrake.SetInput(0.0);
      this.angularBrake.SetInput(0.0);
    }
  }

  public func UpdateInputs(timeDelta: Float) -> Void {
    this.yaw.GetValue(timeDelta);
    this.sway.GetValue(timeDelta);
    this.roll.GetValue(timeDelta);
    this.pitch.GetValue(timeDelta);
    this.lift.GetValue(timeDelta);
    this.linearBrake.GetValue(timeDelta);
    this.angularBrake.GetValue(timeDelta);
    this.surge.GetValue(timeDelta);
  }


  public func SetupPositionProviders() -> Void {
    this.sys.audio.AddSlotProviders(GetMountedVehicle(this.player));
  }

  // protected cb func PhysicsUpdate(evt: ref<vehicleFlightPhysicsUpdateEvent>) -> Bool {
    // FlightLog.Info("in the physics update!");
  // }

  // public final func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  public final func OnUpdate(timeDelta: Float) -> Void {

    // let cameraPos = this.ui.camera.GetLocalToWorld() * Vector4.EmptyVector();
    // let localCameraPos = Matrix.GetInverted(this.GetVehicle().chassis.GetLocalToWorld()) * cameraPos;
    // let idealCameraPos = new Vector4(0.0, -6.0, 1.2, 0.0);
    // let yaw = Vector4.GetAngleDegAroundAxis(localCameraPos, idealCameraPos, new Vector4(0.0, 0.0, 1.0, 0.0));
    // let pitch = Vector4.GetAngleDegAroundAxis(localCameraPos, idealCameraPos, new Vector4(1.0, 0.0, 0.0, 0.0));

    // if !IsDefined(this.uiBlackboard) {
    //   this.uiBlackboard = GameInstance.GetBlackboardSystem(this.gameInstance).Get(GetAllBlackboardDefs().UI_System);
    //   this.uiSystemBB = GetAllBlackboardDefs().UI_System;
    //   this.trackedMappinId = this.uiBlackboard.RegisterListenerVariant(this.uiSystemBB.TrackedMappin, this, n"OnTrackedMappinUpdated");
    //   this.uiBlackboard.SignalVariant(this.uiSystemBB.TrackedMappin);
    // }

    // this.isInAnyMenu = this.uiBlackboard.GetBool(this.uiSystemBB.IsInMenu);

    // if !this.active {
    //   if (this.showUI) {
    //     this.ui.ClearMarks();
    //   }
    //   return;
    // }
    // might need to handle just the scanning system's dilation, and the pause menu
    // if GameInstance.GetTimeSystem(this.gameInstance).IsTimeDilationActive(n"radial") {
    //   // this might happpen?
    //   timeDelta *= TimeDilationHelper.GetFloatFromTimeSystemTweak("radialMenu", "timeDilation");
    //   //FlightLog.Info("Radial menu dilation");
    // } else {
    //   if GameInstance.GetTimeSystem(this.gameInstance).IsTimeDilationActive() {
    //     // i think this is what this is called
    //     timeDelta *= TimeDilationHelper.GetFloatFromTimeSystemTweak("focusModeTimeDilation", "timeDilation");
    //     //FlightLog.Info("Other time dilation");
    //   }
    // }

    // let player: ref<PlayerPuppet> = GetPlayer(this.gameInstance);
    // if !IsDefined(this.GetVehicle()) {
    //   // if IsDefined(scriptInterface.owner as VehicleObject) {
    //   //   this.stats = FlightStats.Create(scriptInterface.owner as VehicleObject);
    //   //   FlightLog.Warn("Vehicle undefined. Redefined to " + this.GetVehicle().GetDisplayName());
    //   // } else {
    //     FlightLog.Error("Owner not defined");
    //     return;
    //   // }
    // }
    // if !this.GetVehicle().IsPlayerMounted() {
    //   FlightLog.Error("Vehicle is not player mounted");
    //   return;
    // }

    // if (this.showUI) {
    //   // this.navPath.Update();
    //   this.ui.ClearMarks();
    // }

    this.UpdateInputs(timeDelta);

    // if (this.showUI) {
      // this.ui.Update(timeDelta);
      // this.ui.DrawMark(this.stats.d_visualPosition);
      // this.ui.DrawText(this.stats.d_visualPosition, FloatToStringPrec(1.0 / this.timeDelta, 4));
    // }

    // this.timeDelta = timeDelta * 0.001 + this.timeDelta * 0.999;
  }

  public func ShowSimpleMessage(message: CName) -> Void {
    let msg: SimpleScreenMessage;
    msg.isShown = true;
    msg.duration = 2.00;
    msg.message = GetLocalizedTextByKey(message);
    if StrLen( msg.message) == 0 {
      msg.message = ToString(message);
    };
    msg.isInstant = true;
    GameInstance.GetBlackboardSystem(this.gameInstance).Get(GetAllBlackboardDefs().UI_Notifications).SetVariant(GetAllBlackboardDefs().UI_Notifications.OnscreenMessage, ToVariant(msg), true);
  }

  public static func CreateInputHint(label: CName, action: CName) -> InputHintData {
    let data: InputHintData;
    data.source = n"FlightController";
    data.action = action;
    data.holdIndicationType = inkInputHintHoldIndicationType.FromInputConfig;
    data.sortingPriority = 0;
    data.enableHoldAnimation = false;
    data.localizedLabel = GetLocalizedTextByKey(label);
    if StrLen( data.localizedLabel) == 0 {
         data.localizedLabel = ToString(label);
    };
    // data.groupId = n"FlightController";
    return data;
  }

  public static func HideHintFromSource(source: CName) -> ref<DeleteInputHintBySourceEvent> {
    let evt: ref<DeleteInputHintBySourceEvent> = new DeleteInputHintBySourceEvent();
    evt.source = source;
    evt.targetHintContainer = n"GameplayInputHelper";
    return evt;
  }

  // Method to add new widget requires parent widget
  // inkCompoundWidget is a base class for all widget types that can have children
  // Usually it's inkCanvas or inkFlex containers with absolute positioning
  // And inkHorizontalPanel or inkVerticalPanel containers for auto layouts
  public static func HUDStatusSetup(parent: wref<inkCompoundWidget>) -> ref<inkText> {
    let flightControlStatus: ref<inkText> = new inkText();
    flightControlStatus.SetName(n"flightControlStatus");
    // Add widget instance to the parent
    flightControlStatus.Reparent(parent);

    // Set font
    flightControlStatus.SetFontFamily("base\\gameplay\\gui\\fonts\\industry\\industry.inkfontfamily");
    flightControlStatus.SetFontStyle(n"Medium");
    flightControlStatus.SetFontSize(24);
    flightControlStatus.SetLetterCase(textLetterCase.UpperCase);

    // Set color
    flightControlStatus.SetTintColor(new HDRColor(0.368627, 0.964706, 1.0, 1.0));

    // Set content
    flightControlStatus.SetText("You shouldn't see this!");
    // flightControlStatus.SetHorizontalAlignment(textHorizontalAlignment.Center);
    // flightControlStatus.SetAnchor(inkEAnchor.TopCenter);


    // Set widget position relative to parent
    // Altough the position is absolute for FHD resoltuion,
    // it will be adapted for the current resoltuion
    flightControlStatus.SetMargin(100, 1802, 0, 0);

    // Set widget size
    flightControlStatus.SetSize(220.0, 50.0);
    return flightControlStatus;
  }

}

// @addMethod(AudioSystem)
// public final func PlayFlightSound(sound: CName) -> Void {
//   this.Play(sound);
// }

// @addField(PlayerPuppet)
// public let flightController: ref<FlightController>; // Must be strong reference

// @addMethod(PlayerPuppet)
// public func GetFlightController() -> ref<FlightController> {
//   return this.flightController;
// }

// @addField(AllBlackboardDefinitions)
// public let flightController: wref<FlightController>; // Must be weak reference

// Option 2 -- Get the player instance as soon as it's ready
@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  wrappedMethod();
  if !this.IsReplacer() {
    FlightController.CreateInstance(this);
  }
}

// @wrapMethod(Ground)
// protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   return wrappedMethod(stateContext, scriptInterface) || FlightController.GetInstance().IsActive();
// }

// @wrapMethod(Air)
// protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   return wrappedMethod(stateContext, scriptInterface) && !FlightController.GetInstance().IsActive();
// }

// might be good to replace this
// @wrapMethod(ReactionManagerComponent)
// private final func ShouldStimBeProcessedByCrowd(stimEvent: ref<StimuliEvent>) -> Bool {

// }


//  public const func HasDirectActionsActive() -> Bool {
//     return false;
//   }


  // protected final func MountFromParent(mountingEvent: ref<MountingEvent>, ownerEntity: ref<Entity>) -> Void {
  //   let instanceData: StateMachineInstanceData;
  //   let initData: ref<VehicleTransitionInitData> = new VehicleTransitionInitData();
  //   let relationship: MountingRelationship = mountingEvent.relationship;
  //   let otherObjectType: gameMountingObjectType = relationship.otherMountableType;
  //   let otherObject: wref<GameObject> = IMountingFacility.RelationshipGetOtherObject(relationship);
  //   switch otherObjectType {
  //     case gameMountingObjectType.Vehicle:
  //       if mountingEvent.request.mountData.mountEventOptions.silentUnmount {
  //         return;
  //       };
  //       initData.instant = mountingEvent.request.mountData.isInstant;
  //       initData.entityID = mountingEvent.request.mountData.mountEventOptions.entityID;
  //       initData.alive = mountingEvent.request.mountData.mountEventOptions.alive;
  //       initData.occupiedByNeutral = mountingEvent.request.mountData.mountEventOptions.occupiedByNeutral;
  //       instanceData.initData = initData;
  //       this.AddStateMachine(n"Vehicle", instanceData, otherObject);


// Flight/FlightEvents.reds

public abstract class vehicleFlightEvent extends Event {
  // public native let vehicle: ref<VehicleObject>;
}

// public native class vehicleFlightPhysicsUpdateEvent extends vehicleFlightEvent {
//   public native let timeDelta: Float;
// }

public class VehicleFlightActivationEvent extends vehicleFlightEvent {
}

public class VehicleFlightDeactivationEvent extends vehicleFlightEvent {
  let silent: Bool;
}

public class VehicleFlightUIActivationEvent extends vehicleFlightEvent {
  public let m_activate: Bool;
}


public class VehicleFlightModeChangeEvent extends vehicleFlightEvent {
  let mode: Int32;
}

public class FlightFxCleanedUpEvent extends Event {
  public let delay: Float = 0.5;
}


// Flight/FlightLog.reds

public native class FlightLog {
  // defined in red4ext part
  public static native func Info(value: String) -> Void;
  public static native func Warn(value: String) -> Void;
  public static native func Error(value: String) -> Void;
  public static native func Probe(image: ref<inkImage>, atlasResourcePath: ResRef) -> Void;
}

// Flight/FlightMode.reds

public abstract class FlightMode {
  protected let sys: ref<FlightSystem>;
  protected let component: ref<FlightComponent>;

  public let force: Vector4;
  public let torque: Vector4;
  public let linearDamp: Float;
  public let angularDamp: Float;

  public let gravityFactor: Float;

  public let usesRightStickInput: Bool;
  public let collisionPenalty: Float;

  public let dampAccVector: Vector3;
  // public let lastAngularDamp: Vector4;

  // public let enabled: Bool;

  public func Initialize(component: ref<FlightComponent>) -> Void {
    this.component = component;
    this.sys = component.sys;
    // this.gravityFactor = 2.885;
    this.gravityFactor = 1.0;
  }

  public func Deinitialize() -> Void;

  public func Activate() -> Void;
  public func Deactivate() -> Void;
  public func GetDescription() -> String;

  public func Update(timeDelta: Float) -> Void;

  public func ApplyPhysics(timeDelta: Float) -> Void {
    let fs =  FlightSettings.GetInstance();
    
    let velocityDamp: Vector4; // = this.component.stats.d_speed * this.component.stats.d_localVelocity * fs.generalDampFactorLinear * this.component.stats.s_airResistanceFactor;
    // let angularDamp: Vector4 = this.component.stats.d_angularVelocity * fs.generalDampFactorAngular;
    let angularDamp: Vector4 = this.component.stats.d_angularVelocity * (fs.generalDampFactorAngular + this.component.angularBrake * fs.brakeFactorAngular * this.component.stats.s_brakingFrictionFactor);

    // angularDamp += this.component.stats.d_angularAcceleration;
    
    // let angularDamp = 0.0;

    // only damp if no input is being received on that axis
    // angularDamp += (1.0 - SqrtF(AbsF(this.component.pitch)));
    // angularDamp += (1.0 - SqrtF(AbsF(this.component.roll)));
    // angularDamp += (1.0 - SqrtF(AbsF(this.component.yaw)));
    angularDamp.X *= (1.0 - AbsF(this.component.pitch));
    angularDamp.Y *= (1.0 - AbsF(this.component.roll));
    angularDamp.Z *= (1.0 - AbsF(this.component.yaw));

    // detect when we hit stuff and delay the damping
    // this.dampAccVector.X = ClampF(MaxF(this.dampAccVector.X, AbsF(this.component.stats.d_angularAcceleration.X) / timeDelta / 10.0), 0.0, 1.0);
    // this.dampAccVector.Y = ClampF(MaxF(this.dampAccVector.Y, AbsF(this.component.stats.d_angularAcceleration.Y) / timeDelta / 10.0), 0.0, 1.0);
    // this.dampAccVector.Z = ClampF(MaxF(this.dampAccVector.Z, AbsF(this.component.stats.d_angularAcceleration.Z) / timeDelta / 10.0), 0.0, 1.0);

    // angularDamp.X *= (1.0 - this.dampAccVector.X);
    // angularDamp.Y *= (1.0 - this.dampAccVector.Y);
    // angularDamp.Z *= (1.0 - this.dampAccVector.Z);

    // decay over 200 ms
    // this.dampAccVector.X -= timeDelta / 0.200;
    // this.dampAccVector.Y -= timeDelta / 0.200;
    // this.dampAccVector.Z -= timeDelta / 0.200;

    // clamp the dampening
    if Vector4.Length(angularDamp) > fs.generalDampFactorAngularMax {
      angularDamp = Vector4.Normalize(angularDamp) * fs.generalDampFactorAngularMax;
    }

    // this.angularDamp = fs.generalDampFactorAngular * ClampF(angularDamp, 0.0, 1.0) + this.component.angularBrake * fs.brakeFactorAngular;
    this.linearDamp = fs.generalDampFactorLinear + this.component.linearBrake * fs.brakeFactorLinear;

    // this.lastAngularDamp = angularDamp;

    // let the world throw us around on collisions
    // angularDamp *= this.timeSinceLastCollision;
    // this.timeSinceLastCollision = MinF(this.timeSinceLastCollision + timeDelta, 1.0);

    let direction = this.component.stats.d_direction;
    if Vector4.Dot(this.component.stats.d_direction, this.component.stats.d_forward) < 0.0 {
      direction = -this.component.stats.d_direction;
    }
    let yawDirectionAngle: Float = Vector4.GetAngleDegAroundAxis(direction, this.component.stats.d_forward, this.component.stats.d_up);
    let pitchDirectionAngle: Float = Vector4.GetAngleDegAroundAxis(direction, this.component.stats.d_forward, this.component.stats.d_right);

    // let aeroDynamicYaw = this.component.aeroYawPID.GetCorrectionClamped(yawDirectionAngle, timeDelta, 10.0) * this.component.stats.d_speedRatio;// / 10.0;
    // let aeroDynamicPitch = this.component.pitchAeroPID.GetCorrectionClamped(pitchDirectionAngle, timeDelta, 10.0) * this.component.stats.d_speedRatio;// / 10.0;
    let aeroDynamicYaw = yawDirectionAngle * this.component.stats.d_speedRatio;// / 10.0;
    let aeroDynamicPitch = pitchDirectionAngle * this.component.stats.d_speedRatio;// / 10.0;

    let yawDirectionality: Float = this.component.stats.d_speedRatio * fs.generalYawDirectionalityFactor;
    let pitchDirectionality: Float = this.component.stats.d_speedRatio * fs.generalPitchDirectionalityFactor;
    let aeroFactor = Vector4.Dot(this.component.stats.d_forward, this.component.stats.d_direction);
    // yawDirectionality - redirect non-directional velocity to vehicle forward

    this.force = -velocityDamp;
    
    this.force += FlightUtils.Forward() * AbsF(Vector4.Dot(this.component.stats.d_forward - this.component.stats.d_direction, this.component.stats.d_right)) * yawDirectionality * aeroFactor;
    this.force += -this.component.stats.d_localDirection * AbsF(Vector4.Dot(this.component.stats.d_forward - this.component.stats.d_direction, this.component.stats.d_right)) * yawDirectionality * AbsF(aeroFactor);

    this.force += FlightUtils.Forward() * AbsF(Vector4.Dot(this.component.stats.d_forward - this.component.stats.d_direction, this.component.stats.d_up)) * pitchDirectionality * aeroFactor;
    this.force += -this.component.stats.d_localDirection * AbsF(Vector4.Dot(this.component.stats.d_forward - this.component.stats.d_direction, this.component.stats.d_up)) * pitchDirectionality * AbsF(aeroFactor);

    this.torque = -angularDamp;
    this.torque.Z -= aeroDynamicYaw * fs.generalYawAeroFactor;
    this.torque.X -= aeroDynamicPitch * fs.generalPitchAeroFactor;
  }
}

// Flight/FlightModeAutomatic.reds

public class FlightModeAutomatic extends FlightModeStandard {

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Mode-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Automatic-Mode-Enabled")
  public let enabled: Bool = false;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Automatic-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Auto-Braking-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Auto-Braking-Factor-Description")
  @runtimeProperty("ModSettings.step", "0.1")
  @runtimeProperty("ModSettings.min", "0")
  @runtimeProperty("ModSettings.max", "10")
  public let automaticModeAutoBrakingFactor: Float = 3.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Automatic-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Yaw-Directionality")
  @runtimeProperty("ModSettings.description", "UI-Settings-Yaw-Directionality-Description")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "0")
  @runtimeProperty("ModSettings.max", "1000")
  public let automaticModeYawDirectionality: Float = 300.0;

  protected let hovering: Float;
  protected let referenceZ: Float;

  public static func Create(component: ref<FlightComponent>) -> ref<FlightModeAutomatic> {
    let self = new FlightModeAutomatic();
    self.Initialize(component);
    self.hovering = 1.0;
    return self;
  }

  public func Initialize(component: ref<FlightComponent>) -> Void {
    super.Initialize(component);
    this.collisionPenalty = 1.0;
  }

  public func Activate() -> Void {
    let normal: Vector4;
    this.referenceZ = this.component.stats.d_position.Z;
    this.component.FindGround(normal);
    this.component.hoverHeight = MaxF(this.component.distance, FlightSettings.GetFloat("hoverModeMinHoverHeight"));
  }

  public func Deactivate() {}

  public func GetDescription() -> String = "Automatic";

  public func Update(timeDelta: Float) -> Void {
    let lastHovering = this.hovering;
    let normal: Vector4;
    let foundGround = this.component.FindGround(normal);
    if foundGround {
      this.hovering = ClampF(1.0 - (this.component.distance - FlightSettings.GetFloat("hoverModeMinHoverHeight")) / (FlightSettings.GetFloat("hoverModeMaxHoverHeight") - FlightSettings.GetFloat("hoverModeMinHoverHeight")), 0.0, 1.0);
    } else {
      this.hovering = 0.0;
    }

    if lastHovering == 0.0 && this.hovering > 0.0 {
      this.component.hoverHeight = MaxF(this.component.distance + this.component.lift * timeDelta * this.standardModeLiftFactor, FlightSettings.GetFloat("hoverModeMinHoverHeight"));
    } else {
      this.component.hoverHeight = MaxF(this.component.hoverHeight + this.component.lift * timeDelta * this.standardModeLiftFactor, FlightSettings.GetFloat("hoverModeMinHoverHeight"));
    }

    let heightDifference = this.component.hoverHeight - this.component.distance;
    let idealNormal = Vector4.Interpolate(FlightUtils.Up(), normal, this.hovering);

    let hoverCorrection = this.component.hoverGroundPID.GetCorrectionClamped(heightDifference, timeDelta, FlightSettings.GetFloat("hoverClamp"));// / FlightSettings.GetFloat("hoverClamp");
    let liftFactor = LerpF(this.hovering, this.component.lift - this.component.stats.d_velocity.Z * 0.1, hoverCorrection);

    this.UpdateWithNormalLift(timeDelta, idealNormal, liftFactor * FlightSettings.GetFloat("hoverFactor") + (9.81000042) * this.gravityFactor);

    let aeroFactor = Vector4.Dot(this.component.stats.d_forward, this.component.stats.d_direction);
    let yawDirectionality: Float = this.component.stats.d_speedRatio * this.automaticModeYawDirectionality;

    let directionFactor = AbsF(Vector4.Dot(this.component.stats.d_forward - this.component.stats.d_direction, this.component.stats.d_right));

    this.force += FlightUtils.Forward() * directionFactor * yawDirectionality * aeroFactor;
    this.force += -this.component.stats.d_localDirection * directionFactor * yawDirectionality * AbsF(aeroFactor);

    if AbsF(this.component.surge) < 1.0 {
      // let velocityDamp: Vector4 = (1.0 - AbsF(this.component.surge)) * this.automaticModeAutoBrakingFactor * this.component.stats.d_localDirection2D * (this.component.stats.d_speed2D / 100.0);
      // this.force -= velocityDamp;
      let velocityDamp: Vector4 = (1.0 - AbsF(this.component.surge)) * this.automaticModeAutoBrakingFactor * this.component.stats.s_brakingFrictionFactor * this.component.stats.d_localVelocity;
      this.force.X -= velocityDamp.X;
      this.force.Y -= velocityDamp.Y;
    }
  }
}


// Flight/FlightModeDrone.reds

public class FlightModeDrone extends FlightMode {

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Mode-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Drone-Mode-Enabled")
  public let enabled: Bool = true;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Drone-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Lift-Factor")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0")
  @runtimeProperty("ModSettings.max", "200")
  public let droneModeLiftFactor: Float = 40.0;
  
  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Drone-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Pitch-Factor")
  @runtimeProperty("ModSettings.step", "0.1")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "200")
  public let droneModePitchFactor: Float = 5.0;
  
  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Drone-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Roll-Factor")
  @runtimeProperty("ModSettings.step", "0.1")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "200")
  public let droneModeRollFactor: Float = 8.0;
  
  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Drone-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Surge-Factor")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0")
  @runtimeProperty("ModSettings.max", "200")
  public let droneModeSurgeFactor: Float = 15.0;
  
  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Drone-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Yaw-Factor")
  @runtimeProperty("ModSettings.step", "0.1")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "200")
  public let droneModeYawFactor: Float = 5.0;
  
  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Drone-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Sway-Factor")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0")
  @runtimeProperty("ModSettings.max", "200")
  public let droneModeSwayFactor: Float = 15.0;

  public static func Create(component: ref<FlightComponent>) -> ref<FlightModeDrone> {
    let self = new FlightModeDrone();
    self.Initialize(component);
    return self;
  }

  public func Initialize(component: ref<FlightComponent>) -> Void {
    super.Initialize(component);
    this.usesRightStickInput = true;
    LTBF_RegisterListener(this);
  }

  public func Deinitialize() -> Void {
    LTBF_UnregisterListener(this);
  }

  public func Activate() -> Void {
    // let camera = this.component.sys.player.GetFPPCameraComponent();
    // if IsDefined(camera) {
    //   let slotT: WorldTransform;
    //   let vehicleSlots = this.component.GetVehicle().GetVehicleComponent().FindComponentByName(n"OccupantSlots") as SlotComponent;
    //   vehicleSlots.GetSlotTransform(n"seat_front_left", slotT);
    //   let vwt = Matrix.GetInverted(this.component.GetVehicle().GetLocalToWorld());
    //   let v = WorldPosition.ToVector4(WorldTransform.GetWorldPosition(slotT)) * vwt;
    //   camera.SetLocalPosition(new Vector4(0.0, FlightSettings.GetFloat("FPVCameraOffsetY"), FlightSettings.GetFloat("FPVCameraOffsetZ"), 0.0) - v);
    //   // camera.Activate(1.0);
    // }
  }

  public func Deactivate() -> Void {
    // let camera = this.component.sys.player.GetFPPCameraComponent();
    // if IsDefined(camera) {
    //   camera.SetLocalPosition(new Vector4(0.0, 0.0, 0.0, 0.0));
    // }
  }

  public func GetDescription() -> String = "Drone";

  public func Update(timeDelta: Float) -> Void {
      let velocityDamp: Vector4 = this.component.stats.d_localVelocity * this.component.linearBrake * FlightSettings.GetInstance().brakeFactorLinear * this.component.stats.s_brakingFrictionFactor;   
      // let velocityDamp: Vector4;
      let angularDamp: Vector4 = this.component.stats.d_angularVelocity * this.component.angularBrake * FlightSettings.GetInstance().brakeFactorAngular * this.component.stats.s_brakingFrictionFactor;
      // let angularDamp: Vector4;

      this.force = new Vector4(0.0, 0.0, 0.0, 0.0);
      // lift
      this.force += FlightUtils.Up() * this.component.lift * this.droneModeLiftFactor;
      // surge
      this.force += FlightUtils.Forward() * this.component.surge * this.droneModeSurgeFactor;
      // sway
      this.force += FlightUtils.Right() * this.component.sway * this.droneModeSwayFactor;
      // directional brake
      this.force -= velocityDamp;

      this.torque = new Vector4(0.0, 0.0, 0.0, 0.0);
      // pitch correction
      this.torque.X = -(this.component.pitch * this.droneModePitchFactor + angularDamp.X);
      // roll correction
      this.torque.Y = (this.component.roll * this.droneModeRollFactor - angularDamp.Y);
      // yaw correction
      this.torque.Z = -(this.component.yaw * this.droneModeYawFactor + angularDamp.Z);
  }
}

// Flight/FlightModeDroneAntiGravity.reds

public class FlightModeDroneAntiGravity extends FlightModeDrone {

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Mode-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Anti-Gravity-Drone-Mode-Enabled")
  public let agEnabled: Bool = false;

  public static func Create(component: ref<FlightComponent>) -> ref<FlightModeDroneAntiGravity> {
    let self = new FlightModeDroneAntiGravity();
    self.Initialize(component);
    return self;
  }

  public func GetDescription() -> String = "Anti-Gravity Drone";

  public func Update(timeDelta: Float) -> Void {
    super.Update(timeDelta);
    this.force += this.component.stats.d_localUp *  (9.81000042) * this.gravityFactor;
  }
}

// Flight/FlightModeFly.reds

public class FlightModeFly extends FlightModeStandard {

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Mode-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Fly-Mode-Enabled")
  public let enabled: Bool = false;

  public func Activate() {}
  public func Deactivate() {}

  public static func Create(component: ref<FlightComponent>) -> ref<FlightModeFly> {
    let self = new FlightModeFly();
    self.Initialize(component);
    return self;
  }

  public func GetDescription() -> String = "Fly";

  public func Update(timeDelta: Float) -> Void {
    let idealNormal = FlightUtils.Up();
    // let liftForce: Float = FlightSettings.GetFloat("flyModeLiftFactor") * this.component.lift + (9.81000042) * this.gravityFactor;
    let liftForce: Float = this.standardModeLiftFactor * this.component.lift * timeDelta + (9.81000042) * this.gravityFactor;
    this.UpdateWithNormalLift(timeDelta, idealNormal, liftForce);
  }
}


// Flight/FlightModeHover.reds

public class FlightModeHover extends FlightModeStandard {

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Mode-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Hover-Mode-Enabled")
  public let enabled: Bool = false;

  public static func Create(component: ref<FlightComponent>) -> ref<FlightModeHover> {
    let self = new FlightModeHover();
    self.Initialize(component);
    return self;
  }

  public func GetDescription() -> String = "Hover";

  public func Activate() -> Void {
    let normal: Vector4;
    this.component.FindGround(normal);
    this.component.hoverHeight = MaxF(this.component.distance, FlightSettings.GetFloat("hoverModeMinHoverHeight"));
  }

  public func Deactivate() {}

  public func Update(timeDelta: Float) -> Void {
    this.component.hoverHeight = MaxF(FlightSettings.GetFloat("hoverModeMinHoverHeight"), this.component.hoverHeight);

    // let findWater: TraceResult;
    let heightDifference = 0.0;
    let normal: Vector4;
    let idealNormal = FlightUtils.Up();

    // this.component.sqs.SyncRaycastByCollisionGroup(this.component.stats.d_position, this.component.stats.d_position - FlightSettings.GetFloat("lookDown"), n"Water", findWater, true, false);
    // if !TraceResult.IsValid(findWater) {
      if (this.component.FindGround(normal)) {
          heightDifference = this.component.hoverHeight - this.component.distance;
          idealNormal = normal;
      }
    // }

    this.UpdateWithNormalDistance(timeDelta, idealNormal, heightDifference);
  }
}


// Flight/FlightModeHoverFly.reds

public class FlightModeHoverFly extends FlightModeStandard {
  protected let hovering: Float;
  protected let referenceZ: Float;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Mode-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Hover-And-Fly-Enabled")
  public let enabled: Bool = true;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Hover-And-Fly-Height-Dampening")
  @runtimeProperty("ModSettings.step", "0.25")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "100.0")
  public let heightDampening: Float = 1.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Hover-And-Fly-Height-Correction")
  @runtimeProperty("ModSettings.step", "0.01")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "5.0")
  public let heightCorrectionFactor: Float = 0.5;

  public static func Create(component: ref<FlightComponent>) -> ref<FlightModeHoverFly> {
    let self = new FlightModeHoverFly();
    self.Initialize(component);
    self.hovering = 1.0;
    return self;
  }

  public func Activate() -> Void {
    let normal: Vector4;
    this.referenceZ = this.component.stats.d_position.Z;
    this.component.FindGround(normal);
    this.component.hoverHeight = MaxF(this.component.distance, FlightSettings.GetFloat("hoverModeMinHoverHeight"));
  }

  public func Deactivate() {}

  public func GetDescription() -> String = "Hover & Fly";

  public func Update(timeDelta: Float) -> Void {
    let lastHovering = this.hovering;
    let normal: Vector4;
    let foundGround = this.component.FindGround(normal);
    if foundGround {
      this.hovering = ClampF(1.0 - (this.component.distance - FlightSettings.GetFloat("hoverModeMinHoverHeight")) / (FlightSettings.GetFloat("hoverModeMaxHoverHeight") - FlightSettings.GetFloat("hoverModeMinHoverHeight")), 0.0, 1.0);
    } else {
      this.hovering = 0.0;
    }

    if lastHovering == 0.0 && this.hovering > 0.0 {
      this.component.hoverHeight = this.component.distance;
    }

    // this.component.hoverHeight = MaxF(this.component.hoverHeight + this.component.lift * timeDelta * this.standardModeHoverFactor, FlightSettings.GetFloat("hoverModeMinHoverHeight"));
    this.component.hoverHeight = MaxF(this.component.hoverHeight + this.component.lift * this.heightCorrectionFactor, FlightSettings.GetFloat("hoverModeMinHoverHeight"));
    // this.component.hoverHeight = MaxF(this.component.hoverHeight + this.component.lift, FlightSettings.GetFloat("hoverModeMinHoverHeight"));

    let heightDifference = this.component.hoverHeight - this.component.distance;
    let idealNormal = Vector4.Interpolate(FlightUtils.Up(), normal, this.hovering);

    let hoverCorrection = this.component.hoverGroundPID.GetCorrectionClamped(heightDifference, timeDelta, FlightSettings.GetFloat("hoverClamp"));// / FlightSettings.GetFloat("hoverClamp");
    let flyCorrection = this.component.lift;// * timeDelta;
    let liftFactor = LerpF(this.hovering, flyCorrection * this.standardModeLiftFactor - this.component.stats.d_velocity.Z * this.heightDampening, hoverCorrection * this.standardModeHoverFactor);
    // liftFactor -= this.component.stats.d_velocity.Z * this.heightDampening;
    liftFactor *= (1.0 - this.component.linearBrake);

    this.UpdateWithNormalLift(timeDelta, idealNormal, liftFactor + (9.81000042) * this.gravityFactor);
  }
}


// Flight/FlightMode_Standard.reds

public abstract class FlightModeStandard extends FlightMode {

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Surge-Factor")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "200.0")
  public let standardModeSurgeFactor: Float = 15.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Yaw-Factor")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "50.0")
  public let standardModeYawFactor: Float = 2.5;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Sway-Factor")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "50.0")
  public let standardModeSwayFactor: Float = 5.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Pitch-Factor")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "20.0")
  public let standardModePitchFactor: Float = 3.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Lift-Factor")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "1.0")
  @runtimeProperty("ModSettings.max", "500.0")
  public let standardModeLiftFactor: Float = 25.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Hover-Factor")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "1.0")
  @runtimeProperty("ModSettings.max", "500.0")
  public let standardModeHoverFactor: Float = 10.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Pitch-Input-Angle")
  @runtimeProperty("ModSettings.step", "5.0")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "90.0")
  public let standardModePitchInputAngle: Float = 45.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Roll-Factor")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "20.0")
  public let standardModeRollFactor: Float = 3.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Standard-Mode")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Roll-Input-Angle")
  @runtimeProperty("ModSettings.step", "5.0")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "90.0")
  public let standardModeRollInputAngle: Float = 45.0;

  public func Initialize(component: ref<FlightComponent>) -> Void {
    super.Initialize(component);
    this.collisionPenalty = 0.5;
    LTBF_RegisterListener(this);
  }

  public func Deinitialize() -> Void {
    LTBF_UnregisterListener(this);
  }

  protected func UpdateWithNormalDistance(timeDelta: Float, normal: Vector4, heightDifference: Float) -> Void {
    let hoverCorrection = this.component.hoverGroundPID.GetCorrectionClamped(heightDifference, timeDelta, FlightSettings.GetFloat("hoverClamp"));// / FlightSettings.GetFloat("hoverClamp");
    let liftForce: Float = hoverCorrection * this.standardModeLiftFactor + (9.81000042) * this.gravityFactor;
    this.UpdateWithNormalLift(timeDelta, normal, liftForce);
  }

  protected func UpdateWithNormalLift(timeDelta: Float, normal: Vector4, liftForce: Float) -> Void {
    let pitchCorrection: Float = 0.0;
    let rollCorrection: Float = 0.0;

    normal = Vector4.RotateAxis(normal, this.component.stats.d_forward, this.component.yaw * FlightSettings.GetFloat("rollWithYaw"));
    normal = Vector4.RotateAxis(normal, this.component.stats.d_right, this.component.lift * FlightSettings.GetFloat("pitchWithLift") * Vector4.Dot(this.component.stats.d_forward, this.component.stats.d_direction));
    normal = Vector4.RotateAxis(normal, this.component.stats.d_right, this.component.surge * FlightSettings.GetFloat("pitchWithSurge"));
    // normal = Vector4.RotateAxis(normal, this.component.stats.d_right, this.component.surge * this.component.stats.s_forwardWeightTransferFactor);
    

    // this.component.pitchPID.SetRatio(this.component.stats.d_speedRatio * AbsF(Vector4.Dot(this.component.stats.d_direction, this.component.stats.d_forward)));
    // this.component.rollPID.SetRatio(this.component.stats.d_speedRatio * AbsF(Vector4.Dot(this.component.stats.d_direction, this.component.stats.d_right)));

    // pitchCorrection = this.component.pitchPID.GetCorrectionClamped(FlightUtils.IdentCurve(Vector4.Dot(normal, FlightUtils.Forward())) + this.lift.GetValue() * this.pitchWithLift, timeDelta, 10.0) + this.pitch.GetValue() / 10.0;
    // rollCorrection = this.component.rollPID.GetCorrectionClamped(FlightUtils.IdentCurve(Vector4.Dot(normal, FlightUtils.Right())), timeDelta, 10.0) + this.yaw.GetValue() * this.rollWithYaw + this.roll.GetValue() / 10.0;
    let pitchDegOffNormal = 90.0 - AbsF(Vector4.GetAngleDegAroundAxis(normal, this.component.stats.d_forward, this.component.stats.d_right));
    let pitchDegOffInput = this.component.pitch * this.standardModePitchInputAngle;
    let pitchDegOff = pitchDegOffNormal + pitchDegOffInput;
    let rollDegOffNormal = 90.0 - AbsF(Vector4.GetAngleDegAroundAxis(normal, this.component.stats.d_right, this.component.stats.d_forward));
    let rollDegOffInput = this.component.roll * this.standardModeRollInputAngle;
    let rollDegOff = rollDegOffNormal + rollDegOffInput;
    if AbsF(pitchDegOff) < 120.0  {
      // pitchCorrection = this.component.pitchPID.GetCorrectionClamped(pitchDegOff / 90.0 + this.lift.GetValue() * this.pitchWithLift, timeDelta, 10.0) + this.pitch.GetValue() / 10.0;
      pitchCorrection = this.component.pitchPID.GetCorrectionClamped(pitchDegOff / 90.0, timeDelta, 10.0);// + this.component.pitch / 10.0;
    }
    if AbsF(rollDegOff) < 120.0 {
      // rollCorrection = this.component.rollPID.GetCorrectionClamped(rollDegOff / 90.0 + this.yaw.GetValue() * this.rollWithYaw, timeDelta, 10.0) + this.roll.GetValue() / 10.0;
      rollCorrection = this.component.rollPID.GetCorrectionClamped(rollDegOff / 90.0, timeDelta, 10.0);// + this.component.roll / 10.0;
    }
    // adjust with speed ratio 
    // pitchCorrection = pitchCorrection * (this.pitchCorrectionFactor + 1.0 * this.pitchCorrectionFactor * this.component.stats.d_speedRatio);
    // rollCorrection = rollCorrection * (this.rollCorrectionFactor + 1.0 * this.rollCorrectionFactor * this.component.stats.d_speedRatio);
    pitchCorrection *= this.standardModePitchFactor;
    rollCorrection *= this.standardModeRollFactor;
    // let changeAngle: Float = Vector4.GetAngleDegAroundAxis(Quaternion.GetForward(this.component.stats.d_lastOrientation), this.component.stats.d_forward, this.component.stats.d_up);
    // if AbsF(pitchDegOff) < 30.0 && AbsF(rollDegOff) < 30.0 {

    // }
    // yawCorrection += FlightSettings.GetFloat("yawD") * changeAngle / timeDelta;

    let velocityDamp: Vector4 = this.component.linearBrake * FlightSettings.GetInstance().brakeFactorLinear * this.component.stats.s_brakingFrictionFactor * this.component.stats.d_localVelocity;
    let angularDamp: Vector4 = this.component.stats.d_angularVelocity * this.component.angularBrake * FlightSettings.GetInstance().brakeFactorAngular * this.component.stats.s_brakingFrictionFactor;
    // let velocityDamp: Vector4; 
    // let angularDamp: Vector4;
    
    // let yawDirectionality: Float = (this.component.stats.d_speedRatio + AbsF(this.yaw.GetValue()) * this.swayWithYaw) * this.yawDirectionalityFactor;
    // actual in-game mass (i think)
    // this.averageMass = this.averageMass * 0.99 + (liftForce / 9.8) * 0.01;
    // FlightLog.Info(ToString(this.averageMass) + " vs " + ToString(this.component.stats.s_mass));
    let surgeForce: Float = this.component.surge * this.standardModeSurgeFactor;

    //this.CreateImpulse(this.component.stats.d_position, FlightUtils.Right() * Vector4.Dot(FlightUtils.Forward() - direction, FlightUtils.Right()) * yawDirectionality / 2.0);


    this.force = new Vector4(0.0, 0.0, 0.0, 0.0);
    this.torque = new Vector4(0.0, 0.0, 0.0, 0.0);

    // lift
    // force += new Vector4(0.00, 0.00, liftForce + this.component.stats.d_speedRatio * liftForce, 0.00);
    this.force += liftForce * this.component.stats.d_localUp;
    // this.force += liftForce * FlightUtils.Up();
    // surge
    this.force += FlightUtils.Forward() * surgeForce;
    // sway
    this.force += FlightUtils.Right() * this.component.sway * this.standardModeSwayFactor;
    // directional brake
    this.force -= velocityDamp;

    // pitch correction
    this.torque.X = -(pitchCorrection * (1.0 - this.component.angularBrake) + angularDamp.X);
    // roll correction
    this.torque.Y = (rollCorrection * (1.0 - this.component.angularBrake) - angularDamp.Y);
    // yaw correction
    this.torque.Z = -((this.component.yaw - (rollDegOffInput * pitchDegOffInput / 1800.0)) * this.standardModeYawFactor + angularDamp.Z );
    // rotational brake
    // torque = torque + (angularDamp);

    // if this.showOptions {
    //   this.component.stats.s_centerOfMass.position.X -= torque.Y * 0.1;
    //   this.component.stats.s_centerOfMass.position.Y -= torque.X * 0.1;
    // }
  }
}

// Flight/FlightSettings.reds

public static func GetFlightSettings() -> ref<FlightSettings> {
  return FlightSettings.GetInstance();
}

public native class FlightSettings extends IScriptable {
  public native static func GetInstance() -> ref<FlightSettings>;
  public native static func GetFloat(name: String) -> Float;
  public native static func SetFloat(name: String, value: Float) -> Float;
  public native static func GetBool(name: String) -> Bool;
  public native static func SetBool(name: String, value: Bool) -> Bool;
  public native static func GetVector3(name: String) -> Vector3;
  public native static func SetVector3(name: String, x: Float, y: Float, z: Float) -> Vector3;
  public native static func DebugBreak() -> Void;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-General-Flight-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Enable-Auto-Activation")
  @runtimeProperty("ModSettings.description", "UI-Settings-Enable-Auto-Activation-Description")
  public let autoActivationEnabled: Bool = false;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-General-Flight-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Auto-Activation-Height")
  @runtimeProperty("ModSettings.description", "UI-Settings-Auto-Activation-Height-Description")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.max", "10.0")
  public let autoActivationHeight: Float = 3.0;

  // Flight Control Settings

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Control-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Linear-Brake-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Linear-Brake-Factor-Description")
  @runtimeProperty("ModSettings.step", "0.1")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "5.0")
  public let brakeFactorLinear: Float = 1.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Control-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Angular-Brake-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Angular-Brake-Factor-Description")
  @runtimeProperty("ModSettings.step", "0.1")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "5.0")
  public let brakeFactorAngular: Float = 1.0;

  // Flight Physics Settings

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Apply-Flight-Physics-When-Deactivated")
  @runtimeProperty("ModSettings.description", "UI-Settings-Apply-Flight-Physics-When-Deactivated-Description")
  public let generalApplyFlightPhysicsWhenDeactivated: Bool = false;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Linear-Damp-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Linear-Damp-Factor-Description")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "20.0")
  public let generalDampFactorLinear: Float = 0.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Angular-Damp-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Angular-Damp-Factor-Description")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "20.0")
  public let generalDampFactorAngular: Float = 2.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Angular-Damp-Max")
  @runtimeProperty("ModSettings.description", "UI-Settings-Angular-Damp-Max-Description")
  @runtimeProperty("ModSettings.step", "0.1")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "50.0")
  public let generalDampFactorAngularMax: Float = 3.5;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Pitch-Aero-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Pitch-Aero-Factor-Description")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "1.0")
  public let generalPitchAeroFactor: Float = 0.0;

  // How much the vehicle is rotated (yaw) towards its velocity
  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Yaw-Aero-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Yaw-Aero-Factor-Description")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "1.0")
  public let generalYawAeroFactor: Float = 0.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Pitch-Directionality-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Pitch-Directionality-Factor-Description")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "100.0")
  public let generalPitchDirectionalityFactor: Float = 15.0;

  // How much the vehicle's yaw affects its velocity
  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Physics-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Yaw-Directionality-Factor")
  @runtimeProperty("ModSettings.description", "UI-Settings-Yaw-Directionality-Factor-Description")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "100.0")
  public let generalYawDirectionalityFactor: Float = 5.0;

  // Flight Camera Settings

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Camera-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Driving-Direction-Compensation-Angle-Smoothing")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "180.0")
  public let drivingDirectionCompensationAngleSmooth: Float = 120.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Camera-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Driving-Direction-Compensation-Speed-Coef")
  @runtimeProperty("ModSettings.step", "0.05")
  @runtimeProperty("ModSettings.min", "0.0")
  @runtimeProperty("ModSettings.max", "1.0")
  public let drivingDirectionCompensationSpeedCoef: Float = 0.1;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Camera-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-FPV-Camera-Pitch-Offset")
  @runtimeProperty("ModSettings.description", "UI-Settings-FPV-Camera-Pitch-Offset-Description")
  @runtimeProperty("ModSettings.step", "5.0")
  @runtimeProperty("ModSettings.min", "-60.0")
  @runtimeProperty("ModSettings.max", "60.0")
  public let fpvCameraPitchOffset: Float = 0.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Camera-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-TPP-Camera-Pitch-Offset")
  @runtimeProperty("ModSettings.description", "UI-Settings-TPP-Camera-Pitch-Offset-Description")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "-60.0")
  @runtimeProperty("ModSettings.max", "60.0")
  public let tppCameraPitchOffset: Float = 20.0;

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-Camera-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Enable-Center-On-Mass")
  @runtimeProperty("ModSettings.description", "UI-Settings-Enable-Center-On-Mass-Description")
  public let tppCameraCenterOnMass: Bool = true;

  // public cb func OnModSettingsUpdate(variable: CName, value: Variant) {
  //   switch (variable) {
  //     case n"autoActivationHeight":
  //       this.autoActivationHeight = FromVariant<Float>(value);
  //       break;
  //   }
  // }

  private func OnAttach() -> Void {
    FlightLog.Info("[FlightSettings] OnAttach");
    LTBF_RegisterListener(this);

    FlightSettings.SetVector3("inputPitchPID", 1.0, 0.2, 0.05);
    FlightSettings.SetVector3("inputRollPID", 1.0, 0.5, 0.0);

    FlightSettings.SetVector3("aeroYawPID", 1.0, 0.01, 1.0);
    FlightSettings.SetVector3("aeroPitchPID", 1.0, 0.01, 1.0);

    FlightSettings.SetVector3("hoverModePID", 1.0, 0.005, 0.5);

    FlightSettings.SetFloat("brakeOffset", 0.0);
    FlightSettings.SetFloat("collisionRecoveryDelay", 0.8);
    FlightSettings.SetFloat("collisionRecoveryDuration", 0.8);
    FlightSettings.SetFloat("defaultHoverHeight", 3.50);
    FlightSettings.SetFloat("distance", 0.0);
    FlightSettings.SetFloat("distanceEase", 0.1);

    // FlightSettings.SetFloat("flyModeLiftFactor", 20.0);

    FlightSettings.SetVector3("FPVCameraOffset", 0.0, 0.0, -0.5);

    FlightSettings.SetFloat("fwtfCorrection", 0.0);
    FlightSettings.SetFloat("hoverClamp", 10.0);
    FlightSettings.SetFloat("hoverFactor", 40.0);
    // FlightSettings.SetFloat("hoverModeLiftFactor", 8.0);
    FlightSettings.SetFloat("isFlightUIActive", 1.0);
    FlightSettings.SetFloat("liftFactor", 8.0);
    FlightSettings.SetFloat("lockFPPCameraForDrone", 1.0);
    FlightSettings.SetFloat("lookAheadMax", 10.0);
    FlightSettings.SetFloat("lookAheadMin", 1.0);
    FlightSettings.SetFloat("hoverModeMaxHoverHeight", 7.0);
    FlightSettings.SetFloat("hoverModeMinHoverHeight", 1.0);
    FlightSettings.SetFloat("normalEase", 0.3);
    FlightSettings.SetFloat("referenceZ", 0.0);
    FlightSettings.SetFloat("secondCounter", 0.0);

    FlightSettings.SetFloat("surgeOffset", 0.5);

    FlightSettings.SetFloat("swayWithYaw", 0.5);
    FlightSettings.SetFloat("rollWithYaw", 0.15);
    FlightSettings.SetFloat("pitchWithLift", 0.0);
    FlightSettings.SetFloat("pitchWithSurge", 0.0);

    FlightSettings.SetFloat("yawD", 3.0);

    FlightSettings.SetBool("inTPPDriverCombat", false);
  }
}


// Flight/FlightStats.reds

public class FlightStats {
  public let vehicle: wref<VehicleObject>;
  public let s_record: wref<Vehicle_Record>;
  // public let s_fc_record: wref<FlightControl_Record>;
  public let s_driveModelData: wref<VehicleDriveModelData_Record>;
  public let s_engineData: wref<VehicleEngineData_Record>;
  public let s_wheelDimensions: wref<VehicleWheelDimensionsSetup_Record>;
  public let s_wheelDriving: wref<VehicleWheelDrivingSetup_Record>;
  public let s_mass: Float;
  public let s_centerOfMass: Vector3;
  public let s_momentOfInertia: Vector4;
  public let s_forwardWeightTransferFactor: Float;
  public let s_brakingFrictionFactor: Float;
  public let s_airResistanceFactor: Float;

  public let d_position: Vector4;
  public let d_visualPosition: Vector4;
  public let d_orientation: Quaternion;
  public let d_lastOrientation: Quaternion;
  public let d_forward: Vector4;
  public let d_right: Vector4;
  public let d_up: Vector4;
  public let d_localUp: Vector4;
  public let d_forward2D: Vector4;
  public let d_orientationChange: Quaternion;
  public let d_angularVelocity: Vector4;
  public let d_angularAcceleration: Vector4;
  public let d_velocity: Vector4;
  public let d_localVelocity: Vector4;
  public let d_velocity2D: Vector4;
  public let d_speed: Float;
  public let d_speedRatio: Float;
  public let d_speedRatioSquared: Float;
  public let d_speed2D: Float;
  public let d_direction: Vector4;
  public let d_localDirection: Vector4;
  public let d_direction2D: Vector4;
  public let d_localDirection2D: Vector4;

  private let reset: Bool;
  private let ipp: ref<IPositionProvider>;
  private let iop: ref<IOrientationProvider>;

  public static func Create(vehicle: wref<VehicleObject>) -> ref<FlightStats> {
    let self: ref<FlightStats> = new FlightStats();
    self.vehicle = vehicle;
    // self.vehicle.chassis = self.vehicle.FindComponentByName(n"Chassis") as vehicleChassisComponent;
    self.reset = false;
    self.UpdateStatic();
    // self.d_position = self.vehicle.GetWorldPosition() + self.s_centerOfMass;
    self.ipp = IPositionProvider.CreateEntityPositionProvider(self.vehicle, self.s_centerOfMass);
    // self.ipp = IPositionProvider.CreatePlacedComponentPositionProvider(self.vehicle.chassis);//, Vector4.Vector4To3(-self.vehicle.chassis.GetInitialPosition()));
    self.ipp.CalculatePosition(self.d_position);
    // CreateMoveComponentVelocityProvider(this.player);
    // self.d_position = self.vehicle.chassis.GetLocalToWorld(); * self.s_centerOfMass;
    // self.d_position = self.vehicle.chassis.GetLocalToWorld() * new Vector4(0.0, 0.0, 0.0, 0.0);
    // self.d_position += self.s_centerOfMass;
    // self.d_orientation = Matrix.ToQuat(self.vehicle.chassis.GetLocalToWorld());
    self.d_orientation = self.vehicle.GetWorldOrientation();
    // self.d_orientation = self.vehicle.chassis.GetWorldOrientation();
    // self.d_position = Vector4.EmptyVector();
    return self;
  }

  public func Reset() -> Void {
    this.reset = true;
  }

  public final func UpdateStatic() -> Void {
    this.s_record = this.vehicle.GetRecord();
    // this.s_fcRecord = FlightStatsData.GetInstance(this.vehicle.GetGame()).Get(this.vehicle.GetRecordID());
    // this.s_fc_record = TweakDBInterface.GetFlightRecord(this.vehicle.GetRecordID());
    this.s_driveModelData = this.s_record.VehDriveModelData();  
    this.s_brakingFrictionFactor = this.s_driveModelData.BrakingFrictionFactor();
    // bikes are 0.0
    if (this.s_brakingFrictionFactor < 0.001) {
      this.s_brakingFrictionFactor = 1.4;
    }
    // FlightLog.Info("BrakingFrictionFactor: " + ToString(this.s_brakingFrictionFactor));
    this.s_airResistanceFactor = this.s_driveModelData.AirResistanceFactor();
    // RollingResistanceFactor() -> Float;
    // HandbrakeBrakingTorque() -> Float;
    this.s_wheelDimensions = this.s_record.VehWheelDimensionsSetup();
    // .FrontPreset() & .BackPreset();
      // .TireRadius() -> Float;
      // .RimRadius() -> Float;
      // .TireWidth() -> Float;
      // .WheelOffset() -> Float;
    this.s_wheelDriving = this.s_driveModelData.WheelSetup();
    // .FrontPreset() & .BackPreset();
      // .MaxBrakingTorque() -> Float;
      // .Mass() -> Float;
    // this.s_mass = this.s_fcRecord.mass;
    // this.s_mass = this.s_fc_record.mass;
    // if this.s_mass == 0.0 {
      this.s_mass = this.vehicle.GetTotalMass(); // might be dynamic? pulled from otherPhysicsData->totalMass
      // this.s_playerMass = 60.0;
    // }
    // small sample size (2) for this value under limited circumstances
    // this.s_mass *= 1.396;
    // need to just dynamically calculate this instead of messing around with random values
    // this.s_centerOfMass = Cast(this.s_driveModelData.Center_of_mass_offset());
    this.s_centerOfMass = this.vehicle.GetCenterOfMass();

    // let weightedVector = (this.vehicle.chassis.GetLocalToWorld() * this.s_centerOfMass.position) * this.s_mass;

    // let cbl = this.vehicle.FindComponentByName(n"ColliderBL") as ColliderComponent;
    // if IsDefined(cbl) {
    //   this.s_mass += cbl.mass;
    //   weightedVector += (cbl.GetLocalToWorld() * cbl.comOffset.position) * cbl.mass;
    // }
    // let cbr = this.vehicle.FindComponentByName(n"ColliderBR") as ColliderComponent;
    // if IsDefined(cbr) {
    //   this.s_mass += cbr.mass;
    //   weightedVector += (cbr.GetLocalToWorld() * cbr.comOffset.position) * cbr.mass;
    // }
    // let cfl = this.vehicle.FindComponentByName(n"ColliderFL") as ColliderComponent;
    // if IsDefined(cfl) {
    //   this.s_mass += cfl.mass;
    //   weightedVector += (cfl.GetLocalToWorld() * cfl.comOffset.position) * cfl.mass;
    // }
    // let cfr = this.vehicle.FindComponentByName(n"ColliderFR") as ColliderComponent;
    // if IsDefined(cfr) {
    //   this.s_mass += cfr.mass;
    //   weightedVector += (cfr.GetLocalToWorld() * cfr.comOffset.position) * cfr.mass;
    // }
    // let cc = this.vehicle.FindComponentByName(n"ColliderC") as ColliderComponent;
    // if IsDefined(cc) {
    //   this.s_mass += cc.mass;
    //   weightedVector += (cc.GetLocalToWorld() * cc.comOffset.position) * cc.mass;
    // }
    // weightedVector /= this.s_mass;

    // this.s_centerOfMass.position = Matrix.GetInverted(this.vehicle.chassis.GetLocalToWorld()) * weightedVector;


    // let playerMass = 80.0;
    // this.s_centerOfMass = playerMass * (Matrix.GetInverted(this.vehicle.chassis.GetLocalToWorld()) * this.player.GetWorldPosition()) / (playerMass + this.s_mass);
    // this.s_centerOfMass += this.s_fcRecord.comOffset_position;
    // this.s_momentOfInertia = Cast(this.s_driveModelData.MomentOfInertia());
    // this.s_momentOfInertia = Cast(this.s_fcRecord.inertia);
    // this isn't defined for all vehicles, so throw some numbers in for now
    // would be nice to compute from meshes outside this and import those values in
    // if Vector4.IsXYZFloatZero(this.s_momentOfInertia) {
      // LogChannel(n"DEBUG", "[FlightStats] no MOI, setting to bad defaults");
    let it = this.vehicle.GetInertiaTensor();
    this.s_momentOfInertia.X = it.X.X;
    this.s_momentOfInertia.Y = it.Y.Y;
    this.s_momentOfInertia.Z = it.Z.Z; 
    // this torques the vehicile in some way upon acceleration - the details aren't currently known
    // it could also be tied to Vehicle.RPMValue - we could use vehicle.GetBlackboard().GetFloat(GetAllBlackboardDefs().Vehicle.RPMValue)
    this.s_forwardWeightTransferFactor = this.s_driveModelData.ForwardWeightTransferFactor();
  }
  
  public final func UpdateDynamic() -> Void {
    this.d_lastOrientation = this.d_orientation;
    let orientation = this.vehicle.GetWorldOrientation();
    // let orientation = Matrix.ToQuat(this.vehicle.chassis.GetLocalToWorld());
    this.d_orientation = orientation;
    this.d_orientationChange = Quaternion.MulInverse(this.d_orientation, this.d_lastOrientation);

    let angularVelocity = Quaternion.Conjugate(this.d_orientation) * Vector4.Vector3To4(this.vehicle.GetAngularVelocity());
    this.d_angularAcceleration = (angularVelocity - this.d_angularVelocity);
    this.d_angularVelocity = angularVelocity;

    Quaternion.GetAxes(this.d_orientation, this.d_forward, this.d_right, this.d_up);
    this.d_forward2D = Vector4.Normalize2D(this.d_forward);
    // this.d_forward = Vector4.Normalize(Quaternion.GetForward(this.d_orientation));
    // this.d_right = Vector4.Normalize(Quaternion.GetRight(this.d_orientation));
    // this.d_up = Vector4.Normalize(Quaternion.GetUp(this.d_orientation));
    // this.d_forward = Quaternion.Transform(this.s_centerOfMass.orientation, this.d_forward);
    // this.d_right = Quaternion.Transform(this.s_centerOfMass.orientation, this.d_right);
    // this.d_up = Quaternion.Transform(this.s_centerOfMass.orientation, this.d_up);
    
    // let playerMass = 80.0;

    // this.s_centerOfMass.position = this.s_playerMass * (Matrix.GetInverted(this.vehicle.GetLocalToWorld()) * this.player.GetWorldPosition()) / (this.s_playerMass + this.s_mass);
    // this.s_centerOfMass.position = this.s_playerMass * (Matrix.GetInverted(this.vehicle.chassis.GetLocalToWorld()) * this.player.GetWorldPosition()) / (this.s_playerMass + this.s_mass);
    // this.s_centerOfMass /= this.s_centerOfMass.W;
    
    // GameInstance.GetSpatialQueriesSystem(FlightController.GetInstance().gameInstance).GetGeometryDescriptionSystem();
    let position: Vector4;
    // if IsDefined(this.vehicle.chassis) {
      // position = this.vehicle.GetWorldPosition() * this.s_mass;
      // position += this.player.GetWorldPosition() * this.s_playerMass;
      // position /= (this.s_mass + this.s_playerMass);
      // position /= position.W;
      // position = this.vehicle.chassis.GetLocalToWorld() * -this.vehicle.chassis.GetComOffset();
      // position = this.vehicle.chassis.GetLocalToWorld() * this.s_centerOfMass;
      // position = this.vehicle.GetLocalToWorld() * this.s_centerOfMass;
    // } else {
      // position = this.vehicle.GetWorldPosition() + this.s_centerOfMass;
    // }
    this.ipp.CalculatePosition(position);
    // position += Quaternion.Transform(this.d_orientation, Vector4.Vector3To4(this.s_centerOfMass));

    // if Vector4.Length(position - this.d_position) / timeDelta <= this.d_speed * 1.1 {
    // if this.reset {
    //   this.reset = false;
    //   this.d_position = position;
    // } else {
      // try to smooth out the position some
      // this.d_position = 0.99999 * this.d_position + 0.00001 * position;
      // this.d_position = Vector4.Interpolate(this.d_position, position, 0.4);
      // this.d_position = position;
    // }

    this.d_velocity = this.vehicle.GetLinearVelocity();
    this.d_localVelocity = Quaternion.Conjugate(this.d_orientation) * this.d_velocity;
    this.d_localUp = Quaternion.Conjugate(this.d_orientation) * FlightUtils.Up();
    // this.d_localUp = this.d_orientation * this.d_up;

    this.d_speed = Vector4.Length(this.d_velocity);
    this.d_speedRatio = this.d_speed / 100.0;
    this.d_speedRatioSquared = this.d_speedRatio * this.d_speedRatio;
    this.d_speed2D = Vector4.Length2D(this.d_velocity);
    this.d_direction = Vector4.Normalize(this.d_velocity);
    this.d_localDirection = Vector4.Normalize(this.d_localVelocity);
    this.d_direction2D = Vector4.Normalize2D(this.d_velocity);
    this.d_localDirection2D = Vector4.Normalize2D(this.d_localVelocity);
    this.d_velocity2D = this.d_direction2D * this.d_speed2D;

    // let minS = 0.3;
    // let maxS = 0.7;
    // let factor = Vector4.Distance(position, this.d_position) / timeDelta / this.d_speed;
    // this.d_position = this.d_position * (minS + (maxS - minS) * factor) + position * (1.0 - minS - (maxS - minS) * factor);
    this.d_visualPosition = this.d_position;
    this.d_position =  position;
    // this.d_visualPosition = this.d_position - this.d_velocity * timeDelta;
  }
}

// Flight/FlightSystem.reds

public abstract importonly class IFlightSystem extends IGameSystem {
}

public func fs() -> ref<FlightSystem> = FlightSystem.GetInstance();

// public native class FlightSystem extends IFlightSystem {
public native class FlightSystem extends IGameSystem {
  public static native func GetInstance() -> ref<FlightSystem>;
  public native func RegisterComponent(component: ref<FlightComponent>) -> Void;
  public native func UnregisterComponent(component: ref<FlightComponent>) -> Void;

  @runtimeProperty("offset", "0x48")
  public native let cameraIndex: Int32;

  @runtimeProperty("offset", "0x50")
  public native let soundListener: wref<IPlacedComponent>;

  @runtimeProperty("offset", "0x60")
  public native let audio: ref<FlightAudio>;

  public let gameInstance: GameInstance;
  public let player: wref<PlayerPuppet>;
  public let ctlr: ref<FlightController>;
  public let stats: ref<FlightStats>;
  // public let fx: ref<FlightFx>;
  // public let tppCamera: wref<vehicleTPPCameraComponent>;

  @runtimeProperty("offset", "0xB8")
  public native let playerComponent: wref<FlightComponent>;

  public func Setup(player: ref<PlayerPuppet>) -> Void {
    FlightLog.Info("[FlightSystem] Player updated");
    this.player = player;
    this.soundListener = player.FindComponentByName(n"soundListener") as IPlacedComponent;
    this.gameInstance = player.GetGame();
    // if !IsDefined(this.audio) {
    //   this.audio = FlightAudio.Create();
    //   FlightLog.Info("[FlightSystem] FlightAudio Created");
    // }
    this.ctlr = FlightController.GetInstance();
    // this.tppCamera = player.FindComponentByName(n"vehicleTPPCamera") as vehicleTPPCameraComponent;
    // this.soundListener = this.tppCamera;
  }

  public func SetPlayerComponent(component: wref<FlightComponent>) -> Void {
    FlightLog.Info("[FlightSystem] Player component set");
    this.playerComponent = component;
  }

//   public static func Get(gameInstance: GameInstance) -> ref<FlightSystem> {
//     return GameInstance.GetScriptableSystemsContainer(gameInstance).Get(n"FlightSystem") as FlightSystem;
//   }

  protected final func OnFlightSystemAttach() -> Void {
    FlightLog.Info("[FlightSystem] OnFlightSystemAttach");
  }

  public final func OnPlayerAttach(request: ref<PlayerAttachRequest>) -> Void {
    FlightLog.Info("[FlightSystem] OnPlayerAttach");
  }

//   private func OnDetach() -> Void {
//     FlightLog.Info("[FlightSystem] OnDetach");
//   }

//   private func OnRestored(saveVersion: Int32, gameVersion: Int32) -> Void {
//     FlightLog.Info("[FlightSystem] OnRestored");
//   }

//   // private func IsSavingLocked() -> Bool {
//   //   return FlightController.GetInstance().IsActive();
//   // }
}



// Flight/FlightThrusterFX.reds

// relevant in-game effects
// r"base\\fx\\quest\\q203\\v_av_rayfield_excalibur_thruster_ground.effect"// blue star on ground
// r"base\\fx\\vehicles\\av\\v_av_trauma_team_thruster.effect" // blinking blue streaks with heat
// r"base\\fx\\vehicles\\manticore\\v_av_manticore_medium_thrusters.effect"// blue speckles with little smoke
// r"base\\fx\\vehicles\\av\\av_rayfield_excalibur_thruster.effect"// blinking blue streaks
// r"base\\fx\\vehicles\\av\\av_luxury_thruster.effect"// large heat with little black smoke
// r"base\\fx\\vehicles\\av\\av_panzer\\av_panzer_thruster_quest.effect"// blue dome
// r"base\\fx\\vehicles\\av\\v_av_trauma_team_thruster_start.effect" // short blue streaks
// r"base\\fx\\quest\\q000\\q000_cargo_av_thruster.effect"// giant red circle with center beams and smoke
// r"base\\fx\\quest\\q104\\q104_av_thrusters.effect"// long blue streaks
// r"base\\fx\\vehicles\\manticore\\v_av_manticore_thrusters_idle_land.effect"// blue streaks with heat
// r"base\\fx\\characters\\common\\retro_thrusters\\ch_retro_thrusters.effect" // grey puff of smoke
// r"base\\fx\\vehicles\\manticore\\v_av_manticore_thrusters.effect"// rectangle shape with blue streaks
// r"base\\fx\\quest\\q112\\q112_av_parade_barge_thruster.effect" // large, bright orange block
// r"base\\fx\\devices\\boot_thrusters\\d_boot_thruster.effect"// too tiny
// r"base\\fx\\vehicles\\av\\v_av_valgus_thruster.effect"// medium orange circle
// r"base\\fx\\devices\\boot_thrusters\\d_boot_thruster_burst_rogue_weyland_hack.effect"// too tiny
// r"base\\fx\\vehicles\\av\\av_panzer\\av_panzer_thruster.effect"// orange & blue, long with tan dust
// r"base\\fx\\devices\\boot_thrusters\\d_boot_thruster_burst.effect"// too tiny
// r"base\\fx\\devices\\boot_thrusters\\d_boot_thruster_holo_jump.effect"// too tiny
// r"base\\fx\\vehicles\\av\\av_rayfield_excalibur_thruster_low_power.effect"// tiny blue with heat

public native struct MaterialResource {
  public native let skidMarks: ResRef;
  public native let tireTracks: ResRef;
  public native let loaded: Bool;
}

public native struct MaterialCondition {
  public native let particle: MaterialResource;
  public native let decal: MaterialResource;
}

public native struct MaterialFx {
  public native let normal: MaterialCondition;
  public native let wet: MaterialCondition;
  public native let rain: MaterialCondition;
}

public abstract class IFlightThrusterFX extends IScriptable {
  public let resource: FxResource;
  public let instance: ref<FxInstance>;
  public let thruster: ref<IFlightThruster>;
  public let position: Vector3;
  public let rotation: Quaternion;

  public func SetResource(resource: ResRef) {
    this.resource = ResRefToFxResource(resource);
  }

  public func Create(thruster: ref<IFlightThruster>) -> ref<IFlightThrusterFX> {
    this.thruster = thruster;
    return this;
  }

  public func Start() {
    let effectTransform: WorldTransform;
    let wt = new WorldTransform();

    WorldTransform.SetPosition(effectTransform, this.thruster.flightComponent.stats.d_position);
    WorldTransform.SetPosition(wt, Vector4.Vector3To4(this.position));
    WorldTransform.SetOrientation(wt, this.rotation);
    this.instance = GameInstance.GetFxSystem(this.thruster.vehicle.GetGame()).SpawnEffect(this.resource, effectTransform);
    this.instance.SetBlackboardValue(n"thruster_amount", 0.0);
    this.instance.AttachToComponent(this.thruster.vehicle, entAttachmentTarget.Transform, this.thruster.meshComponent.name, wt);
  }

  public func Stop() {
    if IsDefined(this.instance) {
      this.instance.BreakLoop();
    }
  }

  // returns how much the bone should be affected
  public func UpdateGetDisplacement() -> Float{
    this.instance.SetBlackboardValue(n"thruster_amount", ClampF(0.0, -1.0, 1.0));
    return 0.0;
  }
}

public class RegularFlightThrusterFX extends IFlightThrusterFX {
  public func Create(thruster: ref<IFlightThruster>) -> ref<IFlightThrusterFX> {
    super.Create(thruster);
    // needs work still
    // this.SetResource(r"user\\jackhumbert\\effects\\flame.effect");
    this.SetResource(r"user\\jackhumbert\\effects\\ion_thruster.effect");
    return this;
  }

  public func UpdateGetDisplacement() -> Float {
    let amount = Vector4.Dot(Quaternion.GetUp(this.thruster.GetLocalOrientation()), this.thruster.force);
    let x = this.thruster.torque.X;
    if !this.thruster.isFront {
      x *= -1.0;
    }
    amount += x + this.thruster.torque.Y;

    this.instance.SetBlackboardValue(n"thruster_amount", ClampF(amount + this.thruster.torque.Z, -1.0, 1.0));
    return ClampF(amount, -1.0, 1.0);
  }
}

public class MainFlightThrusterFX extends IFlightThrusterFX {
  public func Create(thruster: ref<IFlightThruster>) -> ref<IFlightThrusterFX> {
    super.Create(thruster);
    this.SetResource(r"user\\jackhumbert\\effects\\ion_thruster.effect");
    return this;
  }

  public func UpdateGetDisplacement() -> Float {
    let amount = Vector4.Dot(Quaternion.GetUp(this.thruster.GetLocalOrientation()), this.thruster.force);
    let x = this.thruster.torque.X;
    let y = this.thruster.torque.Y;
    if !this.thruster.isFront {
      x *= -1.0;
    }
    if this.thruster.isRight {
      y *= -1.0;
    }

    this.instance.SetBlackboardValue(n"thruster_amount", ClampF(amount + x + y, -1.0, 1.0));
    return ClampF(amount, -1.0, 1.0);
  }
}

public class SideFlightThrusterFX extends IFlightThrusterFX {
  public func Create(thruster: ref<IFlightThruster>) -> ref<IFlightThrusterFX> {
    super.Create(thruster);
    this.SetResource(r"user\\jackhumbert\\effects\\retro_thruster.effect");
    this.rotation = EulerAngles.ToQuat(MakeEulerAngles(0.0, 0.0, -90.0));
    return this;
  }

  public func UpdateGetDisplacement() -> Float {
    let tor = this.thruster.torque.Z;
    let vec = new Vector4(1.0, 0.0, 0.0, 0.0);
    if this.thruster.isRight {
      tor *= -1.0;
      vec *= -1.0;
    }
    if !this.thruster.isFront {
      vec *= -1.0;
    }
    let amount = (Vector4.Dot(vec, this.thruster.force) + tor) * 0.1;
    this.instance.SetBlackboardValue(n"thruster_amount", ClampF(amount, -1.0, 1.0));
    return 0.0;
  }
}


// Flight/FlightTricks.reds

public abstract class FlightTrick
{
  public let suspendMode: Bool;
  public let force: Vector4;
  public let torque: Vector4;
  private let time: Float;
  private let component: ref<FlightComponent>;
  public func Initialize(component: ref<FlightComponent>, suspend: Bool) -> Void {
    this.component = component;
    this.suspendMode = suspend;
  }
  // returns true if finished
  public func Update(timeDelta: Float) -> Bool {
    this.time += timeDelta;
    return false;
  }
}

public class FlightTrickAileronRoll extends FlightTrick {
  private let direction: Float;
  public static func Create(component: ref<FlightComponent>, direction: Float) -> ref<FlightTrickAileronRoll> {
    let self = new FlightTrickAileronRoll();
    self.Initialize(component, true);
    self.direction = direction;
    return self;
  }
  public func Update(timeDelta: Float) -> Bool {
    if this.time < 0.3 {
      this.force = this.component.stats.d_localUp * 9.81000042;
      if this.time < 0.3 {
        this.torque.Y = 75.0 * this.direction; 
      }
      return super.Update(timeDelta);
    } else {
      return true;
    }
  }
}

// Flight/InputContext/Extensions/InputContextTransitionDecisions.reds

@addField(InputContextTransitionDecisions)
protected let m_flightCallbackID: ref<CallbackHandle>;

@addField(InputContextTransitionDecisions)
protected let m_isFlying: Bool;

@addField(InputContextTransitionDecisions)
protected let m_vehicleState: Int32;

@addMethod(InputContextTransitionDecisions)
protected func UpdateEnterConditionForFlight() -> Void {
  let value = !this.m_isFlying;
  this.EnableOnEnterCondition(value);
}

@addMethod(InputContextTransitionDecisions)
protected cb func OnVehicleFlightChanged(value: Bool) -> Bool {
  this.m_isFlying = value;
  this.UpdateEnterConditionForFlight();
}


// Flight/InputContext/Extensions/OnEnter.reds

// @wrapMethod(VehicleDriverContextDecisions)
// protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   // FlightLog.Info("[VehicleDriverContextDecisions] EnterCondition");
//   let old = wrappedMethod(stateContext, scriptInterface);
//   // let currentState: Int32 = scriptInterface.localBlackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Vehicle);
//   // let inFlight: StateResultBool = stateContext.GetPermanentBoolParameter(n"isInFlight");
//   // return old && currentState < 8;
//   return old && !this.IsInFlight();
//   // return old && !(scriptInterface.owner as VehicleObject).GetFlightComponent().active;
// }

@wrapMethod(VehiclePassengerContextDecisions)
protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
  return wrappedMethod(stateContext, scriptInterface) && !this.IsInFlight();
}

@wrapMethod(VehicleDriverCombatContextDecisions)
protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
  return wrappedMethod(stateContext, scriptInterface) && !this.IsInFlight();
}

@wrapMethod(VehiclePassengerContextEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
  wrappedMethod(stateContext, scriptInterface);
}

@wrapMethod(VehicleDriverContextEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
  wrappedMethod(stateContext, scriptInterface);
}

@wrapMethod(VehicleDriverCombatContextEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
  wrappedMethod(stateContext, scriptInterface);
}

@wrapMethod(VehicleDriverCombatTPPContextEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
  wrappedMethod(stateContext, scriptInterface);
}

@wrapMethod(VehicleDriverCombatAimContextEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
  wrappedMethod(stateContext, scriptInterface);
}

@wrapMethod(VehicleCombatContextEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
  wrappedMethod(stateContext, scriptInterface);
}

@wrapMethod(VehiclePassengerContextEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
  wrappedMethod(stateContext, scriptInterface);
}

// Flight/InputContext/Extensions/VehicleCombatContextDecisions.reds

@addMethod(VehicleCombatContextDecisions)
protected func UpdateEnterConditionForFlight() -> Void {
  let value = !this.m_isFlying && (this.m_vehicleState == EnumInt(gamePSMVehicle.Combat));
  this.EnableOnEnterCondition(value);
}

@replaceMethod(VehicleCombatContextDecisions)
protected cb func OnVehicleStateChanged(value: Int32) -> Bool {
  this.m_vehicleState = value;
  this.UpdateEnterConditionForFlight();
}

@wrapMethod(VehicleCombatContextDecisions)
protected final func OnAttach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
  wrappedMethod(stateContext, scriptInterface);

  let allBlackboardDef: ref<AllBlackboardDefinitions> = GetAllBlackboardDefs();
  let bb = FlightController.GetInstance().GetBlackboard();

  if IsDefined(bb) {
    this.m_flightCallbackID = bb.RegisterListenerBool(allBlackboardDef.VehicleFlight.IsActive, this, n"OnVehicleFlightChanged");
    this.OnVehicleFlightChanged(bb.GetBool(allBlackboardDef.VehicleFlight.IsActive));
  } else {
    FlightLog.Error("[VehicleCombatContextDecisions] Blackboard not defined");
  }
}


// Flight/InputContext/Extensions/VehicleDriverCombatContextDecisions.reds

@addMethod(VehicleDriverCombatContextDecisions)
protected func UpdateEnterConditionForFlight() -> Void {
  let value = !this.m_isFlying && (this.m_vehicleState == EnumInt(gamePSMVehicle.DriverCombat));
  this.EnableOnEnterCondition(value);
}

@replaceMethod(VehicleDriverCombatContextDecisions)
protected cb func OnVehicleStateChanged(value: Int32) -> Bool {
  this.m_vehicleState = value;
  this.UpdateEnterConditionForFlight();
}
@wrapMethod(VehicleDriverCombatContextDecisions)
protected final func OnAttach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
  wrappedMethod(stateContext, scriptInterface);

  let allBlackboardDef: ref<AllBlackboardDefinitions> = GetAllBlackboardDefs();
  let bb = FlightController.GetInstance().GetBlackboard();

  if IsDefined(bb) {
    this.m_flightCallbackID = bb.RegisterListenerBool(allBlackboardDef.VehicleFlight.IsActive, this, n"OnVehicleFlightChanged");
    this.OnVehicleFlightChanged(bb.GetBool(allBlackboardDef.VehicleFlight.IsActive));
  } else {
    FlightLog.Error("[VehicleDriverCombatContextDecisions] Blackboard not defined");
  }
}

// Flight/InputContext/Extensions/VehicleDriverContextDecisions.reds

@addMethod(VehicleDriverContextDecisions)
protected func UpdateEnterConditionForFlight() -> Void {
  let value = !this.m_isFlying && (this.m_vehicleState == EnumInt(gamePSMVehicle.Driving));
  this.EnableOnEnterCondition(value);
}

@replaceMethod(VehicleDriverContextDecisions)
protected cb func OnVehicleStateChanged(value: Int32) -> Bool {
  this.m_vehicleState = value;
  this.UpdateEnterConditionForFlight();
}

@wrapMethod(VehicleDriverContextDecisions)
protected final func OnAttach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
  wrappedMethod(stateContext, scriptInterface);

  let allBlackboardDef: ref<AllBlackboardDefinitions> = GetAllBlackboardDefs();
  let bb = FlightController.GetInstance().GetBlackboard();

  if IsDefined(bb) {
    this.m_flightCallbackID = bb.RegisterListenerBool(allBlackboardDef.VehicleFlight.IsActive, this, n"OnVehicleFlightChanged");
    this.OnVehicleFlightChanged(bb.GetBool(allBlackboardDef.VehicleFlight.IsActive));
  } else {
    FlightLog.Error("[VehicleDriverContextDecisions] Blackboard not defined");
  }
}


// Flight/InputContext/VehicleFlightCombatContext.reds

public class VehicleFlightCombatContextDecisions extends VehicleFlightContextDecisions {

  protected func UpdateEnterConditionForFlight() -> Void {
    let value = this.m_psmVehicle == EnumInt(gamePSMVehicle.Combat) && this.m_isFlying;
    this.EnableOnEnterCondition(value);
  }

  protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    return true;
  }
}

public class VehicleFlightCombatContextEvents extends VehicleCombatContextEvents {

  protected final func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnUpdate(timeDelta, stateContext, scriptInterface);
    if this.m_gameplaySettings.GetIsInputHintEnabled() && this.m_isGameplayInputHintManagerInitialized {
      this.UpdateVehicleFlightInputHints(stateContext, scriptInterface);
    };
  }

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    this.RemoveVehicleDriverInputHints(stateContext, scriptInterface);
    this.ShowVehicleFlightInputHints(stateContext, scriptInterface);
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnExit(stateContext, scriptInterface);
    this.RemoveVehicleFlightInputHints(stateContext, scriptInterface);
  }
}

// Flight/InputContext/VehicleFlightContext.reds

public class VehicleFlightContextDecisions extends InputContextTransitionDecisions {

  protected let m_stateCallbackID: ref<CallbackHandle>;
  protected let m_flightCallbackID: ref<CallbackHandle>;

  protected let m_psmVehicle: Int32;
  protected let m_isFlying: Bool;

  protected let m_context: ref<StateContext>;

  protected func OnAttach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
    // FlightLog.Info("[VehicleFlightContextDecisions] OnAttach");
    this.m_context = stateContext;
    let allBlackboardDef = GetAllBlackboardDefs();
      
    if IsDefined(scriptInterface.localBlackboard) {
      this.m_stateCallbackID = scriptInterface.localBlackboard.RegisterListenerInt(allBlackboardDef.PlayerStateMachine.Vehicle, this, n"OnVehicleStateChanged");
      this.OnVehicleStateChanged(scriptInterface.localBlackboard.GetInt(allBlackboardDef.PlayerStateMachine.Vehicle));
      
      // FlightController.GetInstance().SetupMountedToCallback(scriptInterface.localBlackboard);
    }
      
    let bb = FlightController.GetInstance().GetBlackboard();

    if IsDefined(bb) {
      this.m_flightCallbackID = bb.RegisterListenerBool(allBlackboardDef.VehicleFlight.IsActive, this, n"OnVehicleFlightChanged");
      this.OnVehicleFlightChanged(bb.GetBool(allBlackboardDef.VehicleFlight.IsActive));
    };

    (scriptInterface.owner as VehicleObject).ToggleFlightComponent(true);
  }

  protected func OnDetach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
    (scriptInterface.owner as VehicleObject).ToggleFlightComponent(false);

    let allBlackboardDef: ref<AllBlackboardDefinitions> = GetAllBlackboardDefs();

    if IsDefined(scriptInterface.localBlackboard) {
      scriptInterface.localBlackboard.UnregisterListenerInt(allBlackboardDef.PlayerStateMachine.Vehicle, this.m_stateCallbackID);
    };

    let bb = FlightController.GetInstance().GetBlackboard();

    if IsDefined(bb) {
      scriptInterface.localBlackboard.UnregisterListenerBool(allBlackboardDef.VehicleFlight.IsActive, this.m_flightCallbackID);
    };

    this.m_stateCallbackID = null;
    this.m_flightCallbackID = null;
  }

  protected func UpdateEnterConditionForFlight() -> Void {
    let value = this.m_psmVehicle == EnumInt(gamePSMVehicle.Driving) && this.m_isFlying;
    // let value = this.m_isFlying;
    this.EnableOnEnterCondition(value);
    // FlightLog.Info("[InputContext] " + this.GetContextName() + " EnterCondition: " + ToString(value));
    
    // let inputState = this.m_context.GetStateMachineCurrentState(n"InputContext");
    // FlightLog.Info("[InputContext] Current: " + NameToString(inputState));
  }

  protected cb func OnVehicleStateChanged(value: Int32) -> Bool {
    this.m_psmVehicle = value;
    this.UpdateEnterConditionForFlight();
  }

  protected cb func OnVehicleFlightChanged(value: Bool) -> Bool {
    this.m_isFlying = value;
    this.UpdateEnterConditionForFlight();
  }

  protected const func DriverCombatTypeEnterCondition(const stateContext: ref<StateContext>) -> Bool {
    let driverCombatType: gamedataDriverCombatType = this.GetDriverCombatType(stateContext);
    return NotEquals(driverCombatType, gamedataDriverCombatType.MountedWeapons);
  }

  protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    if !this.DriverCombatTypeEnterCondition(stateContext) {
      return false;
    };
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(scriptInterface.executionOwner, n"VehicleOnlyForward") {
      return false;
    };
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(scriptInterface.executionOwner, n"NoDriving") {
      return false;
    };
    return true;
  }
}

public class VehicleFlightContextEvents extends InputContextTransitionEvents {

  protected final func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    if this.m_gameplaySettings.GetIsInputHintEnabled() && this.m_isGameplayInputHintManagerInitialized {
      this.UpdateVehicleFlightInputHints(stateContext, scriptInterface);
    };
  }

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
    this.RemoveVehicleDriverInputHints(stateContext, scriptInterface);
    this.ShowVehicleFlightInputHints(stateContext, scriptInterface);
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.RemoveVehicleFlightInputHints(stateContext, scriptInterface);
  }
}

// Flight/InputContext/VehicleFlightDriverCombatAimContext.reds

public class VehicleFlightDriverCombatAimContextDecisions extends VehicleFlightDriverCombatContextDecisions {

  protected const func IsAimingEnterCondition() -> Bool {
    return this.m_isAiming;
  }

  protected const func CameraPerspectiveEnterCondition() -> Bool {
    return true;
  }
}

public class VehicleFlightDriverCombatAimContextEvents extends VehicleFlightDriverCombatContextEvents {

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    this.m_weapon = DefaultTransition.GetActiveWeapon(scriptInterface);
    stateContext.SetPermanentBoolParameter(n"inMeleeDriverCombat", this.m_weapon.IsMelee(), true);
    if this.m_gameplaySettings.GetIsInputHintEnabled() && this.m_isGameplayInputHintManagerInitialized {
      this.ShowVehicleDriverCombatTPPInputHints(stateContext, scriptInterface);
      // this.ShowVehicleFlightInputHints(stateContext, scriptInterface);
    };
    FlightSettings.SetBool("inTPPDriverCombat", true);
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.RemoveVehicleDriverCombatTPPInputHints(stateContext, scriptInterface);
    stateContext.RemovePermanentBoolParameter(n"inMeleeDriverCombat");
    FlightSettings.SetBool("inTPPDriverCombat", false);
  }
}

// Flight/InputContext/VehicleFlightDriverCombatContext.reds

public class VehicleFlightDriverCombatContextDecisions extends VehicleFlightContextDecisions {

  protected let m_tppCallbackID: ref<CallbackHandle>;
  protected let m_upperBodyCallbackID: ref<CallbackHandle>;

  protected let m_inTpp: Bool;
  protected let m_isAiming: Bool;

  protected func OnAttach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnAttach(stateContext, scriptInterface);

    let allBlackboardDef = GetAllBlackboardDefs();
      
    if IsDefined(scriptInterface.localBlackboard) {
      this.m_tppCallbackID = scriptInterface.localBlackboard.RegisterListenerBool(allBlackboardDef.PlayerStateMachine.IsDriverCombatInTPP, this, n"OnVehiclePerspectiveChanged", true);
      this.OnVehiclePerspectiveChanged(scriptInterface.localBlackboard.GetBool(allBlackboardDef.PlayerStateMachine.IsDriverCombatInTPP));

      this.m_upperBodyCallbackID = scriptInterface.localBlackboard.RegisterListenerInt(allBlackboardDef.PlayerStateMachine.UpperBody, this, n"OnUpperBodyStateChanged", true);
      this.OnUpperBodyStateChanged(scriptInterface.localBlackboard.GetInt(allBlackboardDef.PlayerStateMachine.UpperBody));
    }
  }

  protected func OnDetach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnDetach(stateContext, scriptInterface);

    let allBlackboardDef: ref<AllBlackboardDefinitions> = GetAllBlackboardDefs();

    if IsDefined(scriptInterface.localBlackboard) {
      scriptInterface.localBlackboard.UnregisterListenerBool(allBlackboardDef.PlayerStateMachine.IsDriverCombatInTPP, this.m_tppCallbackID);
      scriptInterface.localBlackboard.UnregisterListenerInt(allBlackboardDef.PlayerStateMachine.UpperBody, this.m_upperBodyCallbackID);
    };

    this.m_tppCallbackID = null;
    this.m_upperBodyCallbackID = null;
  }

  protected func UpdateEnterConditionForFlight() -> Void {
    let value = this.m_psmVehicle == EnumInt(gamePSMVehicle.DriverCombat) && this.m_isFlying;
    // let value = this.m_isFlying;
    this.EnableOnEnterCondition(value);
    // FlightLog.Info("[InputContext] " + this.GetContextName() + " EnterCondition: " + ToString(value));
  }

  protected cb func OnVehiclePerspectiveChanged(value: Bool) -> Bool {
    this.m_inTpp = value;
  }

  protected cb func OnUpperBodyStateChanged(value: Int32) -> Bool {
    this.m_isAiming = value == EnumInt(gamePSMUpperBodyStates.Aim);
  }

  protected const func CameraPerspectiveEnterCondition() -> Bool {
    return !this.m_inTpp;
  }

  protected const func IsAimingEnterCondition() -> Bool {
    return !this.m_isAiming;
  }
  
  protected const func DriverCombatTypeEnterCondition(const stateContext: ref<StateContext>) -> Bool {
    let driverCombatType: gamedataDriverCombatType = this.GetDriverCombatType(stateContext);
    return Equals(driverCombatType, gamedataDriverCombatType.Standard) || Equals(driverCombatType, gamedataDriverCombatType.Doors);
  }

  protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    if !this.CameraPerspectiveEnterCondition() || !this.IsAimingEnterCondition() || !this.DriverCombatTypeEnterCondition(stateContext) {
      return false;
    };
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(scriptInterface.executionOwner, n"VehicleOnlyForward") {
      return false;
    };
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(scriptInterface.executionOwner, n"NoDriving") {
      return false;
    };
    // FlightLog.Info("[InputContext] " + this.GetContextName() + " Entering");
    return true;
  }
}

public class VehicleFlightDriverCombatContextEvents extends VehicleDriverCombatContextEvents {

  protected final func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnUpdate(timeDelta, stateContext, scriptInterface);
    if this.m_gameplaySettings.GetIsInputHintEnabled() && this.m_isGameplayInputHintManagerInitialized {
      this.UpdateVehicleFlightInputHints(stateContext, scriptInterface);
    };
  }

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    this.RemoveVehicleDriverInputHints(stateContext, scriptInterface);
    this.ShowVehicleFlightInputHints(stateContext, scriptInterface);
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnExit(stateContext, scriptInterface);
    this.RemoveVehicleFlightInputHints(stateContext, scriptInterface);
  }
}

// Flight/InputContext/VehicleFlightDriverCombatMountedWeaponsContext.reds

public class VehicleFlightDriverCombatMountedWeaponsContextDecisions extends VehicleFlightDriverCombatContextDecisions {

  protected const func CameraPerspectiveEnterCondition() -> Bool {
    return true;
  }

  protected const func IsAimingEnterCondition() -> Bool {
    return true;
  }

  protected const func DriverCombatTypeEnterCondition(const stateContext: ref<StateContext>) -> Bool {
    let driverCombatType: gamedataDriverCombatType = this.GetDriverCombatType(stateContext);
    return Equals(driverCombatType, gamedataDriverCombatType.MountedWeapons);
  }
}

public class VehicleFlightDriverCombatMountedWeaponsContextEvents extends VehicleFlightDriverCombatContextEvents {

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    this.SetInMountedVehicleCombat(true);
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnExit(stateContext, scriptInterface);
    this.SetInMountedVehicleCombat(false);
  }
}


// Flight/InputContext/VehicleFlightDriverCombatTPPContext.reds

public class VehicleFlightDriverCombatTPPContextDecisions extends VehicleFlightDriverCombatContextDecisions {

  protected const func CameraPerspectiveEnterCondition() -> Bool {
    return this.m_inTpp;
  }
}

public class VehicleFlightDriverCombatTPPContextEvents extends VehicleFlightDriverCombatContextEvents {

  protected func UpdateVehicleDriverCombatInputHintsInternal(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.ShowVehicleDriverCombatTPPInputHints(stateContext, scriptInterface);
  }

  protected func RemoveVehicleDriverCombatInputHintsInternal(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.RemoveVehicleDriverCombatTPPInputHints(stateContext, scriptInterface);
  }

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    FlightLog.Info("[InputContext] " + NameToString(this.GetStateName()) + " from " + NameToString(stateContext.GetStateMachineCurrentState(n"InputContext")));
    this.m_weapon = DefaultTransition.GetActiveWeapon(scriptInterface);
    stateContext.SetPermanentBoolParameter(n"inMeleeDriverCombat", this.m_weapon.IsMelee(), true);
    FlightSettings.SetBool("inTPPDriverCombat", true);
    if this.m_gameplaySettings.GetIsInputHintEnabled() && this.m_isGameplayInputHintManagerInitialized {
      this.ShowVehicleDriverCombatTPPInputHints(stateContext, scriptInterface);
      this.ShowVehicleFlightInputHints(stateContext, scriptInterface);
    };
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnExit(stateContext, scriptInterface);
    this.RemoveVehicleDriverCombatTPPInputHints(stateContext, scriptInterface);
    stateContext.RemovePermanentBoolParameter(n"inMeleeDriverCombat");
    FlightSettings.SetBool("inTPPDriverCombat", false);
  }
}

// Flight/InputContext/VehicleFlightDriverMountedWeaponsContext.reds

public class VehicleFlightDriverMountedWeaponsContextDecisions extends VehicleFlightContextDecisions {

  protected const func DriverCombatTypeEnterCondition(const stateContext: ref<StateContext>) -> Bool {
    let driverCombatType: gamedataDriverCombatType = this.GetDriverCombatType(stateContext);
    return Equals(driverCombatType, gamedataDriverCombatType.MountedWeapons);
  }
}

public class VehicleFlightDriverMountedWeaponsContextEvents extends VehicleFlightContextEvents {

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    this.SetInMountedVehicleCombat(true);
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnExit(stateContext, scriptInterface);
    this.SetInMountedVehicleCombat(false);
  }
}


// Flight/StateMachine/VehicleFlight.reds

// public class VehicleFlightInitData extends IScriptable {
// 	let vehicle: wref<GameObject>;
//   let driver: wref<GameObject>;
// }

public class VehicleFlightTransition extends DefaultTransition {

  protected let m_name: String;

  protected func OnAttach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.m_name = NameToString(this.GetStateName());
    DefaultTransition.UppercaseFirstChar(this.m_name);
  }

  protected func OnDetach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
  }

}

public class VehicleFlightEventsTransition extends VehicleFlightTransition {

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    // let param: StateResultCName = this.GetStaticCNameParameter("onEnterCameraParamsName");
    FlightLog.Info("[VehicleFlightEventsTransition] " + this.m_name);
  }

  protected final func HandleFlightCameraInput(scriptInterface: ref<StateGameScriptInterface>) -> Void {
    if scriptInterface.IsActionJustTapped(n"ToggleVehCamera") && !this.IsVehicleCameraChangeBlocked(scriptInterface) {
      this.RequestToggleVehicleFlightCamera(scriptInterface);
    };
    // if scriptInterface.IsActionJustTapped(n"VehicleCameraInverse") {
    //   this.ResetVehicleCamera(scriptInterface);
    // };
  }

  protected final func RequestToggleVehicleFlightCamera(scriptInterface: ref<StateGameScriptInterface>) -> Void {
    let camEvent: ref<vehicleRequestCameraPerspectiveEvent>;
    if scriptInterface.localBlackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Vision) == EnumInt(gamePSMVision.Focus) {
      return;
    };
    camEvent = new vehicleRequestCameraPerspectiveEvent();
    switch (scriptInterface.owner as VehicleObject).GetCameraManager().GetActivePerspective() {
      case vehicleCameraPerspective.FPP:
        if FlightSystem.GetInstance().cameraIndex == 1 {
          camEvent.cameraPerspective = vehicleCameraPerspective.TPPClose;
          this.ExitCustomCamera(scriptInterface);
        } else {
          this.EnterCustomCamera(scriptInterface);
        }
        break;
      case vehicleCameraPerspective.TPPClose:
        camEvent.cameraPerspective = vehicleCameraPerspective.TPPMedium;
        break;
      case vehicleCameraPerspective.TPPMedium:
        camEvent.cameraPerspective = vehicleCameraPerspective.TPPFar;
        break;
      case vehicleCameraPerspective.TPPFar:
        if !scriptInterface.localBlackboard.GetBool(GetAllBlackboardDefs().PlayerStateMachine.IsDriverCombatInTPP) {
          camEvent.cameraPerspective = vehicleCameraPerspective.TPPClose;
        } else {
          camEvent.cameraPerspective = vehicleCameraPerspective.FPP;
        };
        break;
      case vehicleCameraPerspective.DriverCombatClose:
        camEvent.cameraPerspective = vehicleCameraPerspective.TPPClose;
        break;
      case vehicleCameraPerspective.DriverCombatMedium:
        camEvent.cameraPerspective = vehicleCameraPerspective.TPPMedium;
        break;
      case vehicleCameraPerspective.DriverCombatFar:
        camEvent.cameraPerspective = vehicleCameraPerspective.TPPFar;
    };
    scriptInterface.executionOwner.QueueEvent(camEvent);
  }

  public func EnterCustomCamera(scriptInterface: ref<StateGameScriptInterface>) {
    FlightSystem.GetInstance().cameraIndex = 1;
    let camera = (scriptInterface.executionOwner as PlayerPuppet).GetFPPCameraComponent();
    if IsDefined(camera) {
      let slotT: WorldTransform;
      let OccupantSlots = (scriptInterface.owner as VehicleObject).GetVehicleComponent().FindComponentByName(n"OccupantSlots") as SlotComponent;
      OccupantSlots.GetSlotTransform(n"seat_front_left", slotT);
      let roof: WorldTransform;
      let vehicle_slots = (scriptInterface.owner as VehicleObject).GetVehicleComponent().FindComponentByName(n"vehicle_slots") as SlotComponent;
      vehicle_slots.GetSlotTransform(n"CustomFlightCamera", roof);
      let vwt = Matrix.GetInverted((scriptInterface.owner as VehicleObject).GetLocalToWorld());
      let v = (WorldPosition.ToVector4(WorldTransform.GetWorldPosition(roof)) * vwt) - (WorldPosition.ToVector4(WorldTransform.GetWorldPosition(slotT)) * vwt);
      camera.SetLocalPosition(v + Vector4.Vector3To4(FlightSettings.GetVector3("FPVCameraOffset")));
      camera.SetLocalOrientation(EulerAngles.ToQuat(MakeEulerAngles(FlightSettings.GetInstance().fpvCameraPitchOffset, 0.0, 0.0)));
    } 

    // let workspotSystem: ref<WorkspotGameSystem> = scriptInterface.GetWorkspotSystem();
    // workspotSystem.SwitchSeatVehicle(scriptInterface.owner, scriptInterface.executionOwner, n"OccupantSlots", n"CustomFlightCamera");
  }

  public func ExitCustomCamera(scriptInterface: ref<StateGameScriptInterface>) {
    FlightSystem.GetInstance().cameraIndex = 0;
    let camera = (scriptInterface.executionOwner as PlayerPuppet).GetFPPCameraComponent();
    if IsDefined(camera) {
      camera.SetLocalPosition(new Vector4(0.0, 0.0, 0.0, 0.0));
      camera.SetLocalOrientation(EulerAngles.ToQuat(MakeEulerAngles(0.0, 0.0, 0.0)));
    }
    // let workspotSystem: ref<WorkspotGameSystem> = scriptInterface.GetWorkspotSystem();
    // workspotSystem.SwitchSeatVehicle(scriptInterface.owner, scriptInterface.executionOwner, n"OccupantSlots", n"seat_front_left");
  }

  // public final func HandleFlightExitRequest(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  //   let isTeleportExiting: StateResultBool = stateContext.GetPermanentBoolParameter(n"teleportExitActive");
  //   let isScheduledExit: StateResultBool = stateContext.GetPermanentBoolParameter(n"validExitAfterSwitchRequest");
  //   let isSwitchingSeats: StateResultBool = stateContext.GetPermanentBoolParameter(n"validSwitchSeatExitRequest");
  //   if isTeleportExiting.value || isScheduledExit.value || isSwitchingSeats.value {
  //     return;
  //   };
  //   if !this.IsExitVehicleBlocked(scriptInterface) {
  //     let stateTime = this.GetInStateTime();      
  //     let exitActionPressCount = scriptInterface.GetActionPressCount(n"Exit");
  //     let exitPressCountResult = stateContext.GetPermanentIntParameter(n"exitPressCountOnEnter");
  //     let onDifferentExitPress = !exitPressCountResult.valid || exitPressCountResult.value != Cast<Int32>(exitActionPressCount);
  //     if onDifferentExitPress && stateTime >= 0.30 && scriptInterface.GetActionValue(n"Exit") > 0.00 && scriptInterface.GetActionStateTime(n"Exit") > 0.30{
  //       let vehicle = scriptInterface.owner as VehicleObject;
  //       // let inputStateTime = scriptInterface.GetActionStateTime(n"Exit");
  //       let validUnmount = vehicle.CanUnmount(true, scriptInterface.executionOwner);
  //       stateContext.SetPermanentIntParameter(n"vehUnmountDir", EnumInt(validUnmount.direction), true);
  //       // this.ExitWithTeleport(stateContext, scriptInterface, validUnmount, false, true);
  //     }
  //   }
  // }

}

// Flight/StateMachine/VehicleFlightActivating.reds

public class VehicleFlightActivatingDecisions extends VehicleFlightTransition {

}

public class VehicleFlightActivatingEvents extends VehicleFlightEventsTransition {

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    
    // FlightLog.Info("Owner : " + NameToString(scriptInterface.owner.GetRecordID()));
    // FlightLog.Info("EOwner: " + NameToString(scriptInterface.executionOwner.GetRecordID()));

    let vehicle = scriptInterface.owner as VehicleObject;
    if !IsDefined(vehicle) {
      FlightLog.Info("[VehicleFlightActivatingEvents] No vehicle defined in enter");
      return;
    }
      // FlightLog.Info("[VehicleEventsTransition] OnEnterFlight, starting");
    // this.SetSide(stateContext, scriptInterface);
    // this.SetIsVehicleDriver(stateContext, true);
    // this.PlayerStateChange(scriptInterface, 1);
    // this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Vehicle, 8);
    // this.SendAnimFeature(stateContext, scriptInterface);
    // this.SetVehFppCameraParams(stateContext, scriptInterface, false);
    /*
    switch vehicle.GetCameraManager().GetActivePerspective() {
      case vehicleCameraPerspective.FPP:
        FlightSystem.GetInstance().cameraIndex = 0;
        break;
      case vehicleCameraPerspective.TPPClose:
        FlightSystem.GetInstance().cameraIndex = 2;
        break;
      case vehicleCameraPerspective.TPPFar:
        FlightSystem.GetInstance().cameraIndex = 3;
    };
    */
      
      // if !VehicleTransition.CanEnterDriverCombat() {
      //   stateContext.SetPermanentBoolParameter(n"ForceEmptyHands", true, true);
      // };
      // FlightController.GetInstance().Activate();
    // if (!vehicle.GetFlightComponent().active) {
      let evt = new VehicleFlightActivationEvent();
      // evt.vehicle = scriptInterface.owner as VehicleObject;
      vehicle.QueueEvent(evt);
    // }
  }
}

// Flight/StateMachine/VehicleFlightActive.reds

public class VehicleFlightActiveDecisions extends VehicleFlightTransition {

  public const func ToVehicleFlightDeactivating(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    return scriptInterface.IsActionJustTapped(n"Flight_Toggle");
  }

  public const func ToVehicleFlightDisabled(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    let stopFlight = stateContext.GetTemporaryBoolParameter(n"stopVehicleFlight");
    if stopFlight.valid {
      return stopFlight.value;
    }
    return false;
  }
}

public class VehicleFlightActiveEvents extends VehicleFlightEventsTransition {

  protected func OnDetach(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Void {
    if this.IsInFlight() {
      FlightController.GetInstance().GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.ExitedWhileActive, true, true);
      this.SetIsInFlight(false);
    }
  }

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    this.SetIsInFlight(true);
  }

  protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.SetIsInFlight(false);
  }
  
  public final func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    // let fc = FlightController.GetInstance();
    // fc.OnUpdate(timeDelta, stateContext, scriptInterface);
    // fc.sys.OnUpdate(timeDelta);
    // this.SetSide(stateContext, scriptInterface);
    // this.SendAnimFeature(stateContext, scriptInterface);
    if (!FlightController.GetInstance().showOptions) {
      this.HandleFlightCameraInput(scriptInterface);
    }
    // this.HandleFlightExitRequest(stateContext, scriptInterface);
  }

}


// Flight/StateMachine/VehicleFlightDeactivating.reds

public class VehicleFlightDeactivatingDecisions extends VehicleFlightTransition {

}

public class VehicleFlightDeactivatingEvents extends VehicleFlightEventsTransition {

  protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    super.OnEnter(stateContext, scriptInterface);
    let vehicle = scriptInterface.owner as VehicleObject;
    if !IsDefined(vehicle) {
      FlightLog.Info("[VehicleFlightDeactivatingEvents] No vehicle defined in exit");
      return;
    }
      // FlightLog.Info("[VehicleEventsTransition] OnExitFlight, stopping");
    this.ExitCustomCamera(scriptInterface);
    // this.SetIsVehicleDriver(stateContext, false);
    // this.SendAnimFeature(stateContext, scriptInterface);
    // vehicle.ToggleFlightComponent(false);
    // FlightController.GetInstance().Deactivate(false);
    // stateContext.SetPermanentBoolParameter(n"ForceEmptyHands", false, true);
      
    // if (vehicle.GetFlightComponent().active) {
      let evt = new VehicleFlightDeactivationEvent();
      evt.silent = false;
      // evt.vehicle = scriptInterface.owner as VehicleObject;
      vehicle.QueueEvent(evt);
    // }
  }
}


// Flight/StateMachine/VehicleFlightDisabled.reds

public class VehicleFlightDisabledDecisions extends VehicleFlightTransition {
  
  public const func ToVehicleFlightEnabled(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    return this.IsPlayerAllowedToEnterFlight(scriptInterface) && this.CanVehicleEnterFlight(scriptInterface);
      // let fc = scriptInterface.owner.FindComponentByName(n"flightComponent") as FlightComponent;
      // if (scriptInterface.IsActionJustTapped(n"Flight_Toggle") || (IsDefined(fs().playerComponent) && fs().playerComponent.active)) &&
      //     GameInstance.GetQuestsSystem(scriptInterface.GetGame()).GetFact(n"map_blocked") == 0 &&
      //     Equals(this.GetCurrentTier(stateContext), GameplayTier.Tier1_FullGameplay) {
  }

  public const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    return !(this.IsPlayerAllowedToEnterFlight(scriptInterface) && this.CanVehicleEnterFlight(scriptInterface));
  }

}

public class VehicleFlightDisabledEvents extends VehicleFlightEventsTransition {

}

// Flight/StateMachine/VehicleFlightEnabled.reds

public class VehicleFlightEnabledDecisions extends VehicleFlightTransition {
  
  public const func ToVehicleFlightActivating(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
      return scriptInterface.IsActionJustTapped(n"Flight_Toggle");
  }

  public const func ToVehicleFlightActive(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
      return IsDefined(fs().playerComponent) && fs().playerComponent.active;
  }
}

public class VehicleFlightEnabledEvents extends VehicleFlightEventsTransition {

}

// Flight/Thruster/BikeThrusters.reds

// FRONT

public class FlightThrusterFront extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_front";

    let frontPreset = TweakDBInterface.GetVehicleRecord(vehicle.GetRecordID()).VehWheelDimensionsSetup().FrontPreset().GetID();
    FlightLog.Info("Looking for front preset " + TDBID.ToStringDEBUG(frontPreset));
    TDBID.Append(frontPreset, t".thrusterSlotOrientation");
    FlightLog.Info("Looking for thrusterSlotOrientation " + TDBID.ToStringDEBUG(frontPreset));
    let orientation = TweakDBInterface.GetEulerAngles(frontPreset, new EulerAngles());

    // orientation needs to be inverse of suspension_front_offset
    this.vehicle.AddSlot(n"suspension_front_offset", this.slotName, new Vector3(0.0, 0.0, -0.5), EulerAngles.ToQuat(orientation));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterF"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isFront = true;
    this.parentSlotName = n"wheel_front_spring";
    this.radiusName = n"None";
    this.deviationName = n"None";
    return this;
  }
  
  public func SetOGComponents() {
    let comp: ref<IComponent>;
    ArrayClear(this.ogComponents);

    comp = this.flightComponent.FindComponentByName(n"axel_f_01");
    if IsDefined(comp) {
      ArrayPush(this.ogComponents, comp);
    }
    let comps = this.vehicle.GetComponentsUsingSlot(n"wheel_front_rot_set");
    for c in comps {
      if !ArrayContains(this.ogComponents, c) {
        ArrayPush(this.ogComponents, c);
      }
    }
    comp = this.flightComponent.FindComponentByName(n"wheel_f_01");
    if IsDefined(comp) {
      if !ArrayContains(this.ogComponents, comp) {
        ArrayPush(this.ogComponents, comp);
      }
    }
    comp = this.flightComponent.FindComponentByName(n"tire_f_01");
    if IsDefined(comp) {
      if !ArrayContains(this.ogComponents, comp) {
        ArrayPush(this.ogComponents, comp);
      }
    }
  }

  public func GetPitch() -> Float {
    let angle = Vector4.GetAngleDegAroundAxis(FlightUtils.Up(), this.force, FlightUtils.Right());
    if angle < (-this.maxThrusterAnglePitch - this.thrusterAngleAllowance) || angle > (this.maxThrusterAnglePitch + this.thrusterAngleAllowance) {
      angle = 0.0;
    }
    angle *= (1.0 - AbsF(this.torque.Y) * 0.5);
    return -ClampF(angle, -this.maxThrusterAnglePitch, this.maxThrusterAnglePitch);
  }

  public func GetYaw() -> Float {
    if this.flightComponent.active {
      let outside: Float;
      let inside: Float;
      outside = this.maxThrusterAngleOutside;
      inside = this.maxThrusterAngleOutside;
      let angle = Vector4.GetAngleDegAroundAxis(FlightUtils.Up(), this.force, FlightUtils.Forward());
      if angle < (-inside - this.thrusterAngleAllowance) || angle > (outside + this.thrusterAngleAllowance) {
        angle = 0.0;
      }
      return this.torque.Z * 30.0 + ClampF(angle, -inside, outside);
    } else {
      return 180.0;
    }
  }
}

// BACK

public class FlightThrusterBack extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_back";

    let backPreset = TweakDBInterface.GetVehicleRecord(vehicle.GetRecordID()).VehWheelDimensionsSetup().BackPreset().GetID();
    FlightLog.Info("Looking for front preset " + TDBID.ToStringDEBUG(backPreset));
    TDBID.Append(backPreset, t".thrusterSlotOrientation");
    FlightLog.Info("Looking for thrusterSlotOrientation " + TDBID.ToStringDEBUG(backPreset));
    let orientation = TweakDBInterface.GetEulerAngles(backPreset, new EulerAngles());

    this.vehicle.AddSlot(n"suspension_back", this.slotName, new Vector3(0.0, 0.0, -0.5), EulerAngles.ToQuat(orientation));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterB"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.parentSlotName = n"axel_back";
    this.radiusName = n"None";
    this.deviationName = n"None";
    return this;
  }
  
  public func SetOGComponents() {
    let comp: ref<IComponent>;
    ArrayClear(this.ogComponents);

    comp = this.flightComponent.FindComponentByName(n"wheel_b_01");
    if IsDefined(comp) {
      ArrayPush(this.ogComponents, comp);
    }
    comp = this.flightComponent.FindComponentByName(n"tire_b_01");
    if IsDefined(comp) {
      if !ArrayContains(this.ogComponents, comp) {
        ArrayPush(this.ogComponents, comp);
      }
    }
    let comps = this.vehicle.GetComponentsUsingSlot(n"axel_back_wheel");
    for c in comps {
      if !ArrayContains(this.ogComponents, c) {
        ArrayPush(this.ogComponents, c);
      }
    }
    comps = this.vehicle.GetComponentsUsingSlot(n"wheel_back");
    for c in comps {
      if !ArrayContains(this.ogComponents, c) {
        ArrayPush(this.ogComponents, c);
      }
    }
  }

  public func GetPitch() -> Float {
    let angle = Vector4.GetAngleDegAroundAxis(FlightUtils.Up(), this.force, FlightUtils.Right());
    if angle < (-this.maxThrusterAnglePitch - this.thrusterAngleAllowance) || angle > (this.maxThrusterAnglePitch + this.thrusterAngleAllowance) {
      angle = 0.0;
    }
    angle *= (1.0 - AbsF(this.torque.Y) * 0.5);
    return -ClampF(angle, -this.maxThrusterAnglePitch, this.maxThrusterAnglePitch);
  }

  public func GetYaw() -> Float {
    if this.flightComponent.active {
      let outside: Float;
      let inside: Float;
      outside = this.maxThrusterAngleOutside;
      inside = this.maxThrusterAngleOutside;
      let angle = Vector4.GetAngleDegAroundAxis(FlightUtils.Up(), this.force, FlightUtils.Forward());
      if angle < (-inside - this.thrusterAngleAllowance) || angle > (outside + this.thrusterAngleAllowance) {
        angle = 0.0;
      }
      return this.torque.Z * -30.0 - ClampF(angle, -inside, outside);
    } else {
      return 180.0;
    }
  }
}

// Flight/Thruster/CarThrusters.reds

// FRONT LEFT

public class FlightThrusterFL extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_front_left";
    this.vehicle.AddSlot(n"swingarm_front_left", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterFL"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isFront = true;
    this.parentSlotName = n"wheel_front_left";
    this.radiusName = n"veh_rad_w_f_l";
    this.deviationName = n"veh_press_w_f_l";
    return this;
  }
}

// FRONT RIGHT

public class FlightThrusterFR extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_front_right";
    this.vehicle.AddSlot(n"swingarm_front_right", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterFR"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isFront = true;
    this.isRight = true;
    this.parentSlotName = n"wheel_front_right";
    this.radiusName = n"veh_rad_w_f_r";
    this.deviationName = n"veh_press_w_f_r";
    return this;
  }
}

// BACK RIGHT

public class FlightThrusterBR extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_back_right";
    this.vehicle.AddSlot(n"swingarm_back_right", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterBR"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isRight = true;
    this.parentSlotName = n"wheel_back_right";
    this.radiusName = n"veh_rad_w_b_r";
    this.deviationName = n"veh_press_w_b_r";
    return this;
  }
}

// BACK LEFT

public class FlightThrusterBL extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_back_left";
    this.vehicle.AddSlot(n"swingarm_back_left", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterBL"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.parentSlotName = n"wheel_back_left";
    this.radiusName = n"veh_rad_w_b_l";
    this.deviationName = n"veh_press_w_b_l";
    return this;
  }
}

// FRONT LEFT B

public class FlightThrusterFLB extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_front_left_b";
    this.vehicle.AddSlot(n"swingarm_front_left_b", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterFLB"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isFront = true;
    this.isB = true;
    this.parentSlotName = n"wheel_front_left_b";
    this.radiusName = n"veh_rad_w_1_l";
    this.deviationName = n"veh_press_w_1_l";
    return this;
  }
}

// FRONT RIGHT B

public class FlightThrusterFRB extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_front_right_b";
    this.vehicle.AddSlot(n"swingarm_front_right_b", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterFRB"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isFront = true;
    this.isRight = true;
    this.isB = true;
    this.parentSlotName = n"wheel_front_right_b";
    this.radiusName = n"veh_rad_w_1_r";
    this.deviationName = n"veh_press_w_1_r";
    return this;
  }
}

// BACK LEFT B

public class FlightThrusterBLB extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_back_left_b";
    this.vehicle.AddSlot(n"swingarm_back_left_b", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterFLB"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isFront = false;
    this.isB = true;
    this.parentSlotName = n"wheel_back_left_b";
    this.radiusName = n"veh_rad_w_1_l";
    this.deviationName = n"veh_press_w_1_l";
    return this;
  }
}

// BACK RIGHT B

public class FlightThrusterBRB extends IFlightThruster {
  public func Create(vehicle: ref<VehicleObject>, meshComponent: ref<MeshComponent>) -> ref<IFlightThruster> {
    this.vehicle = vehicle;
    this.slotName = n"thruster_back_right_b";
    this.vehicle.AddSlot(n"swingarm_back_right_b", this.slotName, new Vector3(0.0, 0.0, 0.0), new Quaternion(0.0, 0.0, 0.0, 1.0));

    this.meshComponent = meshComponent;
    this.meshComponent.name = n"ThrusterFRB"; 
    this.meshComponent.SetParentTransform(n"vehicle_slots", this.slotName);

    this.isFront = false;
    this.isRight = true;
    this.isB = true;
    this.parentSlotName = n"wheel_back_right_b";
    this.radiusName = n"veh_rad_w_1_r";
    this.deviationName = n"veh_press_w_1_r";
    return this;
  }
}

// Flight/Thruster/IFlightThruster.reds

public abstract native class IFlightThruster extends IScriptable {

  @runtimeProperty("offset", "0x40")
  public native let flightComponent: wref<FlightComponent>;

  @runtimeProperty("offset", "0x58")
  public native let slotName: CName;

  @runtimeProperty("offset", "0x90")
  public native let meshComponent: ref<MeshComponent>;

  @runtimeProperty("offset", "0xA0")
  public native let vehicle: wref<VehicleObject>;

  @runtimeProperty("offset", "0xB0")
  public native let attached: Bool;

  public let parentSlotName: CName;
  public let radiusName: CName;
  public let deviationName: CName;

  public let fxs: array<ref<IFlightThrusterFX>>;

  // public let mainResRef: ResRef = r"user\\jackhumbert\\effects\\ion_thruster.effect";
  // public let mainFxRes: FxResource;
  // public let retroResRef: ResRef = r"user\\jackhumbert\\effects\\retro_thruster.effect";
  // public let retroFxRes: FxResource;
  
  public let bone: Float = 0.0;
  public let boneLerpAmount: Float = 0.25;
  public let maxThrusterAnglePitch: Float = 90.0;
  public let maxThrusterAngleOutside: Float = 60.0;
  public let maxThrusterAngleInside: Float = 15.0;
  public let thrusterAngleAllowance: Float = 15.0;
  public let ogComponents: array<ref<IComponent>>;
  public let componentSizeArray: array<Vector3>;
  // public let mainFx: ref<FxInstance>;
  // public let mainThrusterFactor: Float = 0.05;
  public let mainThrusterYawFactor: Float = 0.5;
  public let hasRetroThruster: Bool = true;
  // public let retroFx: ref<FxInstance>;
  // public let retroThrusterFactor: Float = 0.1;
  public let force: Vector4;
  public let torque: Vector4;
  public let isRight: Bool = false;
  public let isFront: Bool = false;
  public let isMotorcycle: Bool = false;
  public let isB: Bool = false;
  public let id: String;
  public let audioUpdate: ref<FlightAudioUpdate>;
  public let audioPitch: Float;
  public let audioPitchSeparation: Float = 0.001;
  public let wheelIndex: Int32;
  public let initialOrientation: Quaternion;

  public func OnSetup(fc : ref<FlightComponent>) {
    this.flightComponent = fc;
    this.attached = true;
    
    if !this.hasRetroThruster {
      this.mainThrusterYawFactor = 30.0;
    } else {
      this.mainThrusterYawFactor = 5.0;
    }

    this.meshComponent.visualScale = new Vector3(0.0, 0.0, 0.0);
    this.meshComponent.Toggle(false);
    this.initialOrientation = this.meshComponent.GetLocalOrientation();
    this.meshComponent.SetLocalOrientation(this.initialOrientation * EulerAngles.ToQuat(this.GetEulerAngles()));
    // this.meshComponent.SetLocalOrientation(EulerAngles.ToQuat(this.GetEulerAngles()));

    this.id = "vehicle";
    // doesn't seem to have the data to get this here
    // this.audioPitch = this.flightComponent.GetPitch();
    if this.isFront {
      this.id += "F";
      // this.audioPitch *= 1.02;
    } else {
      this.id += "B";
      // this.audioPitch *= 0.5;
      // this.audioPitch *= 2.0;
    }
    if this.isRight {
      this.id += "R";
      // this.audioPitch *= (1.0 + this.audioPitchSeparation);
    } else {
      this.id += "L";
      // this.audioPitch /= (1.0 + this.audioPitchSeparation);
    }
    if this.isB {
      this.id += "B";
      // this.audioPitch *= 0.5;
    }
    // not ready yet
    // this.id += this.flightComponent.GetUniqueID();
    this.id += FloatToString(RandRangeF(0.0, 1.0));
    this.audioUpdate = new FlightAudioUpdate();
  
  }

  public func GetLocalToWorld() -> Matrix {
    if IsDefined(this.meshComponent) {
      return this.meshComponent.GetLocalToWorld();
    } else {
      return Matrix.Identity();
    }
  }

  public func GetLocalOrientation() -> Quaternion {
    if IsDefined(this.meshComponent) {
      return this.meshComponent.GetLocalOrientation();
    } else {
      return new Quaternion(0.0, 0.0, 0.0, 1.0);
    }
  }

  public func GetEulerAngles() -> EulerAngles {
    return MakeEulerAngles(this.GetPitch(), this.GetRoll(), this.GetYaw());
  }

  public func GetPitch() -> Float {
    let angle = Vector4.GetAngleDegAroundAxis(FlightUtils.Up(), this.force, FlightUtils.Right());
    if angle < (-this.maxThrusterAnglePitch - this.thrusterAngleAllowance) || angle > (this.maxThrusterAnglePitch + this.thrusterAngleAllowance) {
      angle = 0.0;
    }
    let dir: Float;
    if this.isRight {
      dir = 1.0;
    } else {
      dir = -1.0;
    }
    angle *= (1.0 - AbsF(this.torque.Y) * 0.5);
    return ClampF(angle, -this.maxThrusterAnglePitch, this.maxThrusterAnglePitch) * dir;
  }

  public func GetRoll() -> Float {
    if this.isRight {
      return 0.0;
    } else {
      return 180.0;
    }
  }

  public func GetYaw() -> Float {
    if this.flightComponent.active {
      let dir: Float;
      let outside: Float;
      let inside: Float;
      if this.isRight {
        dir = 1.0;
        outside = this.maxThrusterAngleInside;
        inside = this.maxThrusterAngleOutside;
      } else {
        dir = -1.0;
        outside = this.maxThrusterAngleOutside;
        inside = this.maxThrusterAngleInside;
      }
      let angle = Vector4.GetAngleDegAroundAxis(FlightUtils.Up(), this.force, FlightUtils.Forward());
      if angle < (-inside - this.thrusterAngleAllowance) || angle > (outside + this.thrusterAngleAllowance) {
        angle = 0.0;
      }
      let tor: Float;
      if this.isFront ^ this.isRight { // FL, BR
        tor = this.torque.Z;
      } else { // FR, BL
        tor = -this.torque.Z;
      }
      return tor * this.mainThrusterYawFactor + ClampF(angle, -inside, outside) * dir;
    } else {
      return 180.0;
    }
  }

  public func SetOGComponents() {
    this.ogComponents = this.vehicle.GetComponentsUsingSlot(this.parentSlotName);
  }

  public func Start() {

    this.SetOGComponents();
    this.HideOGComponents();

    if this.attached {
      if IsDefined(this.meshComponent) {
        for fx in this.fxs {
          fx.Start();
        }
        this.meshComponent.Toggle(true);
      }

    // FlightAudio.Get().StartWithPitch(this.id, "vehicle3_TPP", this.audioPitch);
      FlightAudio.Get().StartWithPitch(this.id, "vehicle3_TPP", this.flightComponent.GetPitch());
    }
  }

  let forceThreshold: Float = 10.0;
  let torqueThreshold: Float = 1.0;

  let animDeviation: Float = 0.3;
  let animRadius: Float = 0.0;

  public func Detach() {
    this.attached = false;
    
    FlightAudio.Get().Stop(this.id);
    
    for fx in this.fxs {
      fx.Stop();
    }
  }

  public func Update(force: Vector4, torque: Vector4) {
    if !this.attached {
      return;
    }

    if Vector4.Length(force) > this.forceThreshold {
      this.force = Vector4.Normalize(force);
    } else {
      this.force = force / this.forceThreshold;
    }
    if Vector4.Length(torque) > this.torqueThreshold {
      this.torque = Vector4.Normalize(torque);
    } else {
      this.torque = torque / this.torqueThreshold;
    }
    
    let vec = new Vector4(1.0, 1.0, 1.0, 1.0);
    if !this.flightComponent.active {
      vec = Vector4.EmptyVector();
    }
    
    let rotatedMatrix: Matrix;
    let volume = 1.0;
    this.audioUpdate = this.flightComponent.audioUpdate;
    this.audioUpdate.scrape = ClampF((this.vehicle as WheeledObject).GetDampedSpringForce(this.wheelIndex) / this.vehicle.GetTotalMass(), 0.0, 1.0);

    if IsDefined(this.meshComponent) {

      let vec_og = Vector4.Vector3To4(this.meshComponent.visualScale);

      this.meshComponent.visualScale = Vector4.Vector4To3(Vector4.Interpolate(vec_og, vec, 0.1));
      this.meshComponent.SetLocalOrientation(Quaternion.Slerp(this.meshComponent.GetLocalOrientation(), this.initialOrientation * EulerAngles.ToQuat(this.GetEulerAngles()), 0.1));
      // this.meshComponent.SetLocalOrientation(Quaternion.Slerp(this.meshComponent.GetLocalOrientation(), EulerAngles.ToQuat(this.GetEulerAngles()), 0.1));

      // scale FX to how much "work" the thruster is actually doing
      let amount = Vector4.Dot(Quaternion.GetUp(this.meshComponent.GetLocalOrientation()), this.force);

      for fx in this.fxs {
        amount += fx.UpdateGetDisplacement();
      }

      // -4, 4 / -10, 10
      let animDeviationCenter = 0.0;

      // how much thrusters move opposite of the force effect
      let animDeviationScale = 0.025;

      // 0, 16
      // let animRadiusCenter = 1.0;
      // let animRadiusScale = -1.0;

      // this.bone = LerpF(this.boneLerpAmount, this.bone, -animScale + ClampF(amount, -1.0, 1.0) * animScale);
      this.animDeviation = LerpF(this.boneLerpAmount, this.animDeviation, animDeviationCenter + amount * animDeviationScale);
      // this.animDeviation = animDeviationCenter + amount * animDeviationScale;
      // this.animRadius = animRadiusCenter + amount * animRadiusScale;
      // AnimationControllerComponent.SetInputFloatToReplicate(this.vehicle, this.deviationName, this.animDeviation);
      // AnimationControllerComponent.SetInputFloatToReplicate(this.vehicle, this.GetRadiusName(), this.animRadius);

      let acc = this.flightComponent.FindComponentByName(n"AnimationController") as AnimationControllerComponent;
      if IsDefined(acc) {
        // between -4.0 & 4.0
        acc.SetInputFloat(this.deviationName, this.animDeviation);
      }
      // AnimationControllerComponent.SetInputFloat(this.vehicle, this.deviationName, this.animDeviation);

      // between 0.0 & 16.0, default to 0.4
      // acc.SetInputFloat(this.GetRadiusName(), this.animRadius);
      
      // amount *= 0.5;
      // this.audioUpdate.surge *= amount;
      // this.audioUpdate.pitch *= amount;
      // this.audioUpdate.yaw *= retroAmount;
      // this.audioUpdate.sway *= retroAmount;
      // this.audioUpdate.lift *= amount;
      // this.audioUpdate.roll *= amount;

      if !this.isFront {
        volume = ClampF(this.flightComponent.stats.d_speed / 100.0, 0.0, 1.0);
      }
      // this.audioUpdate.pitch = retroAmount;
      
      let matrix = this.meshComponent.GetLocalToWorld();
      // rotates the event cone down
      let quat = Matrix.ToQuat(matrix) * new Quaternion(-0.707, 0.0, 0.0, 0.707);
      rotatedMatrix = Quaternion.ToMatrix(quat);
      rotatedMatrix.W = matrix.W;
    }

    FlightAudio.Get().UpdateEvent(this.id, rotatedMatrix, volume, this.audioUpdate);
  }

  public func Stop() {
    if this.attached {
      FlightAudio.Get().Stop(this.id);
      for fx in this.fxs {
        fx.Stop();
      }
    }
    this.ShowOGComponents();
  }

  public func HideOGComponents() {
    for c in this.ogComponents {
      let mc = c as MeshComponent;
      if IsDefined(mc) {
        ArrayPush(this.componentSizeArray, mc.visualScale);
        mc.visualScale = new Vector3(0.0, 0.0, 0.0);
      }
    }
  }

  public func ShowOGComponents() {
    let i = 0;
    for c in this.ogComponents {
      let mc = c as MeshComponent;
      if IsDefined(mc) {
        mc.visualScale = this.componentSizeArray[i];
        i += 1;
      }
    }
    ArrayClear(this.componentSizeArray);
  }
}

// Flight/Thruster/Meshes.reds

public func CreateEmptyThruster() -> ref<MeshComponent> {
  let mc = new MeshComponent();
  return mc;
}

public func CreateCorpoThruster(opt appearanceName: CName) -> ref<MeshComponent> {
  let mc = new PhysicalMeshComponent();
  mc.SetMesh(r"user\\jackhumbert\\meshes\\engine_corpo.mesh");
  if Equals(appearanceName, n"None") {
    mc.meshApperance = n"default";
  } else {
    mc.meshApperance = appearanceName;
  }
  mc.motionBlurScale = 0.1;
  mc.LODMode = entMeshComponentLODMode.Appearance;
  return mc;
}

public func CreateNomadThruster(opt appearanceName: CName) -> ref<MeshComponent> {
  let mc = new PhysicalMeshComponent();
  mc.SetMesh(r"user\\jackhumbert\\meshes\\engine_nomad.mesh");
  if Equals(appearanceName, n"None") {
    mc.meshApperance = n"default";
  } else {
    mc.meshApperance = appearanceName;
  }
  mc.motionBlurScale = 0.1;
  mc.LODMode = entMeshComponentLODMode.Appearance;
  return mc;
}

// Paraglide/Extensions.reds

// @wrapMethod(LocomotionAirDecisions)
// protected const func ToDeathLand(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   let landingType: Int32;
//   if !this.IsTouchingGround(scriptInterface) {
//     return false;
//   };
//   landingType = this.GetLandingType(stateContext);
//   if landingType == EnumInt(LandingType.Death) {
//     return true;
//   };
//   return false;
// }

// @wrapMethod(LocomotionAirDecisions)
// protected const func ToDeathLand(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   let deathLandingHeight: StateResultFloat;
//   let playerPosition: Vector4;
//   if !this.IsTouchingGround(scriptInterface) {
//     return false;
//   };
//   deathLandingHeight = stateContext.GetPermanentFloatParameter(n"DeathLandingHeight");
//   playerPosition = DefaultTransition.GetPlayerPosition(scriptInterface);
//   if deathLandingHeight.valid {
//     if deathLandingHeight.value > playerPosition.Z {
//       return true;
//     };
//   } else {
//     return true;
//   };
//   return false;
// }

// func GetFallingSpeedBasedOnHeight(const scriptInterface: ref<StateGameScriptInterface>, height: Float) -> Float {
//   let acc: Float;
//   let speed: Float;
//   if height <= 0.00 {
//     return 0.00;
//   };
//   acc = AbsF(this.GetStaticFloatParameterDefault("upwardsGravity", this.GetStaticFloatParameterDefault("defaultGravity", -16.00)));
//   speed = 0.00;
//   if acc != 0.00 {
//     speed = acc * SqrtF((2.00 * height) / acc);
//   };
//   return speed * -1.00;
// }

@addMethod(DefaultTransition)
public final func CanParaglide() -> Bool {
  return TweakDBInterface.GetBool(TDBID.Create("player.canParaglide"), false);
}

@addField(LocomotionAirEvents)
public let m_isParagliding: Bool;

@wrapMethod(LocomotionAirEvents)
protected func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  if !this.CanParaglide() {
    wrappedMethod(timeDelta, stateContext, scriptInterface);
    return;
  }
  let deathLandingFallingSpeed: Float;
  let hardLandingFallingSpeed: Float;
  let horizontalSpeed: Float;
  let isInSuperheroFall: Bool;
  let isLeaping: Bool;
  let landingAnimFeature: ref<AnimFeature_Landing>;
  let landingType: LandingType;
  let maxAllowedDistanceToGround: Float;
  let playerVelocity: Vector4;
  let regularLandingFallingSpeed: Float;
  let safeLandingFallingSpeed: Float;
  let verticalSpeed: Float;
  let veryHardLandingFallingSpeed: Float;
  super.OnUpdate(timeDelta, stateContext, scriptInterface);

  if this.IsTouchingGround(scriptInterface) {
    this.m_resetFallingParametersOnExit = true;
    return;
  };
  this.m_resetFallingParametersOnExit = false;
  verticalSpeed = this.GetVerticalSpeed(scriptInterface);

  if FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.ExitedWhileActive) {
    if !this.m_isParagliding && scriptInterface.IsActionJustPressed(n"DeployGlider") {
      this.m_isParagliding = true;
      
      this.RemoveInputHint(scriptInterface, n"DeployGlider", n"Paraglider");
      this.ShowInputHint(scriptInterface, n"PackGlider", n"Paraglider", LocKeyToString(n"Input-Hint-Pack-Glider"));
      // scriptInterface.GetAudioSystem().NotifyGameTone(n"EnterCrouch");
      // this.StartEffect(scriptInterface, n"skif_buff");
      // GameObjectEffectHelper.StartEffectEvent(scriptInterface.executionOwner, n"camera_mask");
      
      // scriptInterface.PushAnimationEvent(n"StaggerHit");

      scriptInterface.PushAnimationEvent(n"Jump");
      this.PlaySound(n"q115_thruster_start", scriptInterface);
      this.SetDetailedState(scriptInterface, gamePSMDetailedLocomotionStates.Jump); // HoverJump, DodgeAir, AirThrusters, Jump
      DefaultTransition.PlayRumbleLoop(scriptInterface, "light");
    }
    if this.m_isParagliding && scriptInterface.IsActionJustPressed(n"PackGlider") {
      this.m_isParagliding = false;
      
      this.RemoveInputHint(scriptInterface, n"PackGlider", n"Paraglider");
      this.ShowInputHint(scriptInterface, n"DeployGlider", n"Paraglider", LocKeyToString(n"Input-Hint-Deploy-Glider"));

      // GameObjectEffectHelper.StopEffectEvent(scriptInterface.executionOwner, n"camera_mask");
      // scriptInterface.GetAudioSystem().NotifyGameTone(n"LeaveCrouch");
      scriptInterface.PushAnimationEvent(n"AirHover");
      this.PlaySound(n"q115_thruster_stop", scriptInterface);
      this.SetDetailedState(scriptInterface, gamePSMDetailedLocomotionStates.Fall);
      DefaultTransition.StopRumbleLoop(scriptInterface, "light");
    }
  }

  FlightLog.Info("[LocomotionAirEvents] " + NameToString(this.GetStateName()) + ": " + ToString(verticalSpeed));

  // // slow fall if exited during flight
  if this.m_isParagliding {
    // let threshold = stateContext.GetFloatParameter(n"HardLandingFallingSpeed", true);
    let threshold = this.GetFallingSpeedBasedOnHeight(scriptInterface, 7.0);
    if verticalSpeed < threshold {
      let velocity = FromVariant<Vector4>(scriptInterface.GetStateVectorParameter(physicsStateValue.LinearVelocity));
      verticalSpeed = threshold;
      velocity.Z = verticalSpeed;

      // scriptInterface.SetStateVectorParameter(physicsStateValue.LinearVelocity, ToVariant(new Vector3(0, 0, this.GetFallingSpeedBasedOnHeight(scriptInterface, 10.0))));
      scriptInterface.SetStateVectorParameter(physicsStateValue.LinearVelocity, ToVariant(velocity));

      // let ev = new PSMImpulse();
      // ev.id = n"impulse";
      // ev.impulse =  new Vector4(0.0, 0.0, 2.0, 1.0);
      // scriptInterface.owner.QueueEvent(ev);
    }
  }



  if this.m_updateInputToggles && verticalSpeed < this.GetFallingSpeedBasedOnHeight(scriptInterface, this.GetStaticFloatParameterDefault("minFallHeightToConsiderInputToggles", 0.00)) {
    this.UpdateInputToggles(stateContext, scriptInterface);
  };
  if scriptInterface.IsActionJustPressed(n"Jump") {
    stateContext.SetConditionBoolParameter(n"CrouchToggled", false, true);
    return;
  };
  if StatusEffectSystem.ObjectHasStatusEffect(scriptInterface.executionOwner, t"BaseStatusEffect.BerserkPlayerBuff") && verticalSpeed < this.GetFallingSpeedBasedOnHeight(scriptInterface, this.GetStaticFloatParameterDefault("minFallHeightToEnterSuperheroFall", 0.00)) {
    stateContext.SetTemporaryBoolParameter(n"requestSuperheroLandActivation", true, true);
  };
  regularLandingFallingSpeed = stateContext.GetFloatParameter(n"RegularLandingFallingSpeed", true);
  safeLandingFallingSpeed = stateContext.GetFloatParameter(n"SafeLandingFallingSpeed", true);
  hardLandingFallingSpeed = stateContext.GetFloatParameter(n"HardLandingFallingSpeed", true);
  veryHardLandingFallingSpeed = stateContext.GetFloatParameter(n"VeryHardLandingFallingSpeed", true);
  deathLandingFallingSpeed = stateContext.GetFloatParameter(n"DeathLandingFallingSpeed", true);
  isLeaping = scriptInterface.localBlackboard.GetBool(GetAllBlackboardDefs().PlayerStateMachine.MeleeLeap) || StatusEffectSystem.ObjectHasStatusEffect(scriptInterface.executionOwner, t"BaseStatusEffect.PlayerMadDashLocomotionBuffer");
  isInSuperheroFall = stateContext.IsStateActive(n"Locomotion", n"superheroFall");
  maxAllowedDistanceToGround = this.GetStaticFloatParameterDefault("maxDistToGroundFromSuperheroFall", 20.00);
  if isInSuperheroFall && !this.m_maxSuperheroFallHeight {
    this.StartEffect(scriptInterface, n"falling");
    this.PlaySound(n"lcm_falling_wind_loop", scriptInterface);
    if DefaultTransition.GetDistanceToGround(scriptInterface) >= maxAllowedDistanceToGround {
      this.m_maxSuperheroFallHeight = true;
      return;
    };
    landingType = LandingType.Superhero;
  } else {
    if isLeaping {
      return;
    };
    // check to see if we exited while flight was active
    if verticalSpeed <= deathLandingFallingSpeed && !FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.ExitedWhileActive) {
      landingType = LandingType.Death;
      this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Fall, EnumInt(gamePSMFallStates.DeathFall));
    } else {
      if verticalSpeed <= veryHardLandingFallingSpeed {
        landingType = LandingType.VeryHard;
        this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Fall, EnumInt(gamePSMFallStates.VeryFastFall));
      } else {
        if verticalSpeed <= hardLandingFallingSpeed {
          landingType = LandingType.Hard;
          if this.GetLandingType(stateContext) != EnumInt(LandingType.Hard) {
            this.StartEffect(scriptInterface, n"falling");
          };
          this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Fall, EnumInt(gamePSMFallStates.FastFall));
        } else {
          if verticalSpeed <= safeLandingFallingSpeed {
            landingType = LandingType.Regular;
            this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Fall, EnumInt(gamePSMFallStates.RegularFall));
            playerVelocity = DefaultTransition.GetLinearVelocity(scriptInterface);
            horizontalSpeed = Vector4.Length2D(playerVelocity);
            if horizontalSpeed <= this.GetStaticFloatParameterDefault("maxHorizontalSpeedToAerialTakedown", 0.00) {
              this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Fall, EnumInt(gamePSMFallStates.SafeFall));
            };
          } else {
            if verticalSpeed <= regularLandingFallingSpeed {
              if this.GetLandingType(stateContext) != EnumInt(LandingType.Regular) {
                this.PlaySound(n"lcm_falling_wind_loop", scriptInterface);
              };
              landingType = LandingType.Regular;
            } else {
              landingType = LandingType.Off;
            };
          };
        };
      };
    };
  };

  if this.m_isParagliding {
    landingType = LandingType.Regular;
    // this.PlaySound(n"lcm_falling_wind_loop", scriptInterface);
  }


  stateContext.SetPermanentIntParameter(n"LandingType", EnumInt(landingType), true);
  stateContext.SetPermanentFloatParameter(n"ImpactSpeed", verticalSpeed, true);
  stateContext.SetPermanentFloatParameter(n"InAirDuration", this.GetInStateTime(), true);
  landingAnimFeature = new AnimFeature_Landing();
  landingAnimFeature.impactSpeed = verticalSpeed;
  landingAnimFeature.type = EnumInt(landingType);
  scriptInterface.SetAnimationParameterFeature(n"Landing", landingAnimFeature);
  this.SetAudioParameter(n"RTPC_Vertical_Velocity", verticalSpeed, scriptInterface);
  this.SetAudioParameter(n"RTPC_Landing_Type", Cast<Float>(EnumInt(landingType)), scriptInterface);
}

// eventually should be triggered by putting away parachute
// @wrapMethod(StandEvents)
// public func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
//   wrappedMethod(stateContext, scriptInterface);
//   // reset exited-while-active once we're on the ground
//   FlightController.GetInstance().GetBlackboard().SetBool(GetAllBlackboardDefs().VehicleFlight.ExitedWhileActive, false, true);
// }

@wrapMethod(FallEvents)
protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  this.m_isParagliding = false;
  wrappedMethod(stateContext, scriptInterface);
  if this.CanParaglide() && FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.ExitedWhileActive) {
    this.ShowInputHint(scriptInterface, n"DeployGlider", n"Paraglider", LocKeyToString(n"Input-Hint-Deploy-Glider"));
  }
}

@addMethod(FallEvents)
protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
  if this.CanParaglide() {
    if this.m_isParagliding {
      this.RemoveInputHint(scriptInterface, n"PackGlider", n"Paraglider");
    } else {
      this.RemoveInputHint(scriptInterface, n"DeployGlider", n"Paraglider");
    }

    // scriptInterface.PushAnimationEvent(n"AirHover");
    this.PlaySound(n"q115_thruster_stop", scriptInterface);
    // this.SetDetailedState(scriptInterface, gamePSMDetailedLocomotionStates.Fall);
    DefaultTransition.StopRumbleLoop(scriptInterface, "light");
  }
  // GameObjectEffectHelper.StopEffectEvent(scriptInterface.executionOwner, n"camera_mask");
  super.OnExit(stateContext, scriptInterface);
}

// Paraglide/LocomotionState.reds

// public class ParaglideDecisions extends LocomotionAirDecisions {

//   protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//     let shouldFall: Bool = this.ShouldFall(stateContext, scriptInterface);
//     if shouldFall {
//       scriptInterface.GetAudioSystem().NotifyGameTone(n"StartFalling");
//     };
//     return shouldFall && scriptInterface.IsActionJustTapped(n"Flight_Toggle");
//     // return scriptInterface.IsActionJustTapped(n"Flight_Toggle");
//   }
// }

// public class ParaglideEvents extends LocomotionAirEvents {

//   public final func OnEnterFromDodge(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
//     if !this.IsTouchingGround(scriptInterface) {
//       stateContext.SetPermanentBoolParameter(n"enteredFallFromAirDodge", true, true);
//       this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Fall, EnumInt(gamePSMFallStates.RegularFall));
//     };
//     this.OnEnter(stateContext, scriptInterface);
//   }

//   public final func OnEnterFromDodgeAir(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
//     stateContext.SetPermanentBoolParameter(n"enteredFallFromAirDodge", true, true);
//     this.OnEnter(stateContext, scriptInterface);
//   }

//   public func ToFall(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//     return scriptInterface.IsActionJustTapped(n"Flight_Toggle");
//   }

//   protected func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
//     super.OnEnter(stateContext, scriptInterface);
//     this.PlaySound(n"lcm_falling_wind_loop", scriptInterface);
//     scriptInterface.PushAnimationEvent(n"Fall");
//     this.SetDetailedState(scriptInterface, gamePSMDetailedLocomotionStates.Fall);    
//     this.ShowInputHint(scriptInterface, n"Flight_Toggle", n"Paraglider", LocKeyToString(n"Input-Hint-Disable-Flight"), inkInputHintHoldIndicationType.FromInputConfig, false, 127);
//   }

//   protected func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {

//     // slow fall if exited during flight
//     // let verticalSpeed = this.GetVerticalSpeed(scriptInterface);
//     // // let threshold = stateContext.GetFloatParameter(n"HardLandingFallingSpeed", true);
//     // let threshold = this.GetFallingSpeedBasedOnHeight(scriptInterface, 15.0);
//     // if verticalSpeed < threshold {
//     //   let velocity = FromVariant<Vector4>(scriptInterface.GetStateVectorParameter(physicsStateValue.LinearVelocity));
//     //   velocity.Z = verticalSpeed;

//     //   // scriptInterface.SetStateVectorParameter(physicsStateValue.LinearVelocity, ToVariant(new Vector3(0, 0, this.GetFallingSpeedBasedOnHeight(scriptInterface, 10.0))));
//     //   scriptInterface.SetStateVectorParameter(physicsStateValue.LinearVelocity, ToVariant(velocity));

//     //   // let ev = new PSMImpulse();
//     //   // ev.id = n"impulse";
//     //   // ev.impulse =  new Vector4(0.0, 0.0, 2.0, 1.0);
//     //   // scriptInterface.owner.QueueEvent(ev);
//     // }

//     super.OnUpdate(timeDelta, stateContext, scriptInterface);
//     this.RemoveOpticalCamoEffect(stateContext, scriptInterface, EnumInt(gamePSMDetailedLocomotionStates.Fall), 1.00);
//   }

//   protected func OnExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
//     this.RemoveInputHint(scriptInterface, n"Flight_Toggle", n"Paraglider");
//     super.OnExit(stateContext, scriptInterface);
//   }
// }

// Paraglide/SpeedExitingDecisions.reds

// @replaceMethod(SpeedExitingDecisions)
// public const func EnterCondition(stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   let exitDirection: vehicleUnmountPosition;
//   let exitRequest: StateResultBool;
//   let vehicle: ref<VehicleObject>;
//   let vehClass: Int32 = stateContext.GetIntParameter(n"vehClass", true);
//   if vehClass == 2 {
//     return false;
//   };
//   if this.IsVehicleExitBlocked1Frame(stateContext, scriptInterface) {
//     return false;
//   };
//   exitRequest = stateContext.GetPermanentBoolParameter(n"validExitRequest");
//   if exitRequest.value {
//     vehicle = scriptInterface.owner as VehicleObject;
//     if vehClass == 1 {
//       exitDirection = vehicle.CanUnmount(true, scriptInterface.executionOwner, vehicleExitDirection.Left);
//       if Equals(exitDirection.direction, vehicleExitDirection.NoDirection) {
//         return false;
//       };
//     };
//     return vehicle.GetCurrentSpeed() > this.GetStaticFloatParameterDefault("highSpeedThreshold", 20.00) || FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.IsActive);
//   };
//   return false;
// }

// @replaceMethod(CoolExitingDecisions)
// public const func EnterCondition(stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
//   let exitRequest: StateResultBool = stateContext.GetPermanentBoolParameter(n"coolExitRequest");
//   if this.IsVehicleExitBlocked1Frame(stateContext, scriptInterface) {
//     return false;
//   };
//   if !exitRequest.value {
//     return false;
//   };
//   stateContext.SetPermanentBoolParameter(n"coolExitRequest", false, true);
//   if !this.IsCoolExitAllowed(stateContext, scriptInterface) && !FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.IsActive) {
//     return false;
//   };
//   return true;
// }

@wrapMethod(SlideFallDecisions)
protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
  return wrappedMethod(stateContext, scriptInterface) 
    && !FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.ExitedWhileActive) 
    && !FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.IsActive);
}

@wrapMethod(SlideExitingDecisions)
public const func EnterCondition(stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
  return wrappedMethod(stateContext, scriptInterface)
    && !FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.ExitedWhileActive) 
    && !FlightController.GetInstance().GetBlackboard().GetBool(GetAllBlackboardDefs().VehicleFlight.IsActive);
}

// Quickhacks/Actions.reds

public class FlightAction extends ScriptableDeviceAction {
  public let m_owner: wref<VehicleObject>;
  public let title: CName;
  public let description: CName;
  public let icon: TweakDBID;
}

public class FlightEnable extends FlightAction {
  public final func SetProperties() -> Void {
    this.SetObjectActionID(t"DeviceAction.FlightEnable");
  }

  public func IsPossible(target: wref<GameObject>, opt actionRecord: wref<ObjectAction_Record>, opt objectActionsCallbackController: wref<gameObjectActionsCallbackController>) -> Bool {
    let v = target as VehicleObject;
    return super.IsPossible(target, actionRecord, objectActionsCallbackController) && v.CanEnterFlight() && !v.m_flightComponent.active;
  }

  public func CompleteAction(gameInstance: GameInstance) -> Void {
    FlightLog.Info("[FlightEnable] CompleteAction");
    super.CompleteAction(gameInstance);
    if !this.m_owner.m_flightComponent.active {
      this.m_owner.ForceEnablePhysics();
      this.m_owner.EndActions();
      this.m_owner.m_flightComponent.Activate(true);
    }
  }
}

public class FlightDisable extends FlightAction {
  public final func SetProperties() -> Void {
    this.SetObjectActionID(t"DeviceAction.FlightDisable");
  }

  public func IsPossible(target: wref<GameObject>, opt actionRecord: wref<ObjectAction_Record>, opt objectActionsCallbackController: wref<gameObjectActionsCallbackController>) -> Bool {
    let v = target as VehicleObject;
    return super.IsPossible(target, actionRecord, objectActionsCallbackController) && v.CanEnterFlight() && v.m_flightComponent.active;
  }

  public func CompleteAction(gameInstance: GameInstance) -> Void {
    FlightLog.Info("[FlightDisable] CompleteAction");
    super.CompleteAction(gameInstance);
    if this.m_owner.m_flightComponent.active {
      this.m_owner.ForceEnablePhysics();
      this.m_owner.EndActions();
      this.m_owner.m_flightComponent.Deactivate(true);
    }
  }
}

public class FlightMalfunction extends FlightAction {
  public final func SetProperties() -> Void {
    this.SetObjectActionID(t"DeviceAction.FlightMalfunction");
  }
}

public class DisableGravity extends FlightAction {
  public final func SetProperties() -> Void {
    this.SetObjectActionID(t"DeviceAction.DisableGravity");
  }

  public func IsPossible(target: wref<GameObject>, opt actionRecord: wref<ObjectAction_Record>, opt objectActionsCallbackController: wref<gameObjectActionsCallbackController>) -> Bool {
    let v = target as VehicleObject;
    return super.IsPossible(target, actionRecord, objectActionsCallbackController) && v.HasGravity();
  }

  public func CompleteAction(gameInstance: GameInstance) -> Void {
    FlightLog.Info("[DisableGravity] CompleteAction");
    super.CompleteAction(gameInstance);
    this.m_owner.ForceEnablePhysics();
    this.m_owner.EndActions();
    this.m_owner.EnableGravity(false);
  }
}

public class EnableGravity extends FlightAction {
  public final func SetProperties() -> Void {
    this.SetObjectActionID(t"DeviceAction.EnableGravity");
  }

  public func IsPossible(target: wref<GameObject>, opt actionRecord: wref<ObjectAction_Record>, opt objectActionsCallbackController: wref<gameObjectActionsCallbackController>) -> Bool {
    let v = target as VehicleObject;
    return super.IsPossible(target, actionRecord, objectActionsCallbackController) && !v.HasGravity();
  }

  public func CompleteAction(gameInstance: GameInstance) -> Void {
    FlightLog.Info("[EnableGravity] CompleteAction");
    super.CompleteAction(gameInstance);
    this.m_owner.EnableGravity(true);
  }
}

public class Funhouse extends FlightAction {
  public final func SetProperties() -> Void {
    this.SetObjectActionID(t"DeviceAction.Funhouse");
  }

  public func IsPossible(target: wref<GameObject>, opt actionRecord: wref<ObjectAction_Record>, opt objectActionsCallbackController: wref<gameObjectActionsCallbackController>) -> Bool {
    let v = target as VehicleObject;
    return super.IsPossible(target, actionRecord, objectActionsCallbackController) && !v.bouncy;
  }

  public func CompleteAction(gameInstance: GameInstance) -> Void {
    FlightLog.Info("[Funhouse] CompleteAction");
    super.CompleteAction(gameInstance);
  }
}

// Individual QH Actions

public func ActionFlightEnable(owner: ref<VehicleObject>) -> ref<FlightEnable> {
    let action: ref<FlightEnable> = new FlightEnable();
    action.clearanceLevel = DefaultActionsParametersHolder.GetTakeOverControl();
    action.m_owner = owner;
    action.SetUp(owner.GetPS());
    action.SetProperties();
    action.AddDeviceName(owner.GetVehiclePS().GetDeviceName());
    action.CreateInteraction();
    action.CreateActionWidgetPackage();

    action.SetExecutor(GetPlayer(owner.GetGame()));
    return action;
}

public func ActionFlightDisable(owner: ref<VehicleObject>) -> ref<FlightDisable> {
    let action: ref<FlightDisable> = new FlightDisable();
    action.clearanceLevel = DefaultActionsParametersHolder.GetTakeOverControl();
    action.m_owner = owner;
    action.SetUp(owner.GetPS());
    action.SetProperties();
    action.AddDeviceName(owner.GetVehiclePS().GetDeviceName());
    action.CreateInteraction();
    action.CreateActionWidgetPackage();

    action.SetExecutor(GetPlayer(owner.GetGame()));
    return action;
}

public func ActionFlightMalfunction(owner: ref<VehicleObject>) -> ref<FlightMalfunction> {
    let action: ref<FlightMalfunction> = new FlightMalfunction();
    action.clearanceLevel = DefaultActionsParametersHolder.GetTakeOverControl();
    action.m_owner = owner;
    action.SetUp(owner.GetPS());
    action.SetProperties();
    action.AddDeviceName(owner.GetVehiclePS().GetDeviceName());
    action.CreateInteraction();
    action.CreateActionWidgetPackage();

    action.SetExecutor(GetPlayer(owner.GetGame()));
    return action;
}

public func ActionDisableGravity(owner: ref<VehicleObject>) -> ref<DisableGravity> {
    let action: ref<DisableGravity> = new DisableGravity();
    action.m_owner = owner;
    action.clearanceLevel = DefaultActionsParametersHolder.GetTakeOverControl();
    action.SetUp(owner.GetPS());
    action.SetProperties();
    action.AddDeviceName(owner.GetVehiclePS().GetDeviceName());
    action.CreateInteraction();
    action.CreateActionWidgetPackage();

    action.SetExecutor(GetPlayer(owner.GetGame()));
    return action;
}

public func ActionEnableGravity(owner: ref<VehicleObject>) -> ref<EnableGravity> {
    let action: ref<EnableGravity> = new EnableGravity();
    action.m_owner = owner;
    action.clearanceLevel = DefaultActionsParametersHolder.GetTakeOverControl();
    action.SetUp(owner.GetPS());
    action.SetProperties();
    action.AddDeviceName(owner.GetVehiclePS().GetDeviceName());
    action.CreateInteraction();
    action.CreateActionWidgetPackage();

    action.SetExecutor(GetPlayer(owner.GetGame()));
    return action;
}

public func ActionFunhouse(owner: ref<VehicleObject>) -> ref<Funhouse> {
    let action: ref<Funhouse> = new Funhouse();
    action.m_owner = owner;
    action.clearanceLevel = DefaultActionsParametersHolder.GetTakeOverControl();
    action.SetUp(owner.GetPS());
    action.SetProperties();
    action.AddDeviceName(owner.GetVehiclePS().GetDeviceName());
    action.CreateActionWidgetPackage();
    action.CreateInteraction();

    action.SetExecutor(GetPlayer(owner.GetGame()));
    // action.ProcessRPGAction(owner.GetGame());
    return action;
}

// Quickhacks/Effectors.reds

public class FlightMalfunctionEffector extends Effector {
  public let m_owner: wref<VehicleObject>;

  protected func Initialize(record: TweakDBID, game: GameInstance, parentRecord: TweakDBID) -> Void {
    FlightLog.Info("[FlightMalfunctionEffector] Initialize");
    // this.m_quickhackLevel = TweakDBInterface.GetFloat(record + t".level", 1.00);
  }

  protected func ActionOn(owner: ref<GameObject>) -> Void {
    FlightLog.Info("[FlightMalfunctionEffector] ActionOn");
    this.m_owner = owner as VehicleObject;
    if IsDefined(this.m_owner) && this.m_owner.CanEnterFlight() {
      this.m_owner.ForceEnablePhysics();
      this.m_owner.EndActions();
      this.m_owner.m_flightComponent.Activate(true);
      this.m_owner.m_flightComponent.lift = 5.0;
    }
  }

  protected func ActionOff(owner: ref<GameObject>) -> Void {
    FlightLog.Info("[FlightMalfunctionEffector] ActionOff");
    if IsDefined(this.m_owner) && this.m_owner.CanEnterFlight() {
      this.m_owner.m_flightComponent.Deactivate(true);
    }
  }

  protected func Uninitialize(game: GameInstance) -> Void {
    FlightLog.Info("[FlightMalfunctionEffector] Uninitialize");
    if !IsDefined(this.m_owner) || !this.m_owner.IsAttached() {
      return;
    };
    this.ActionOff(this.m_owner);
  }
}

public class DisableGravityEffector extends Effector {

}

public class FunhouseEffector extends Effector {
  public let m_owner: wref<GameObject>;

  protected func Initialize(record: TweakDBID, game: GameInstance, parentRecord: TweakDBID) -> Void {
    FlightLog.Info("[FunhouseEffector] Initialize");
    // this.m_quickhackLevel = TweakDBInterface.GetFloat(record + t".level", 1.00);
  }

  protected func ActionOn(owner: ref<GameObject>) -> Void {
    FlightLog.Info("[FunhouseEffector] ActionOn");
    this.m_owner = owner;
    let vehicle = owner as VehicleObject;
    if IsDefined(vehicle) && vehicle.CanEnterFlight() {
      vehicle.bouncy = true;
      vehicle.ignoreImpulses = false;
      vehicle.ForceEnablePhysics();
      vehicle.EndActions();
      vehicle.m_flightComponent.FireVerticalImpulse(0);
    }
  }

  protected func ActionOff(owner: ref<GameObject>) -> Void {
    FlightLog.Info("[FunhouseEffector] ActionOff");
    let vehicle = owner as VehicleObject;
    if IsDefined(vehicle) {
      vehicle.bouncy = false;
    }
  }

  protected func Uninitialize(game: GameInstance) -> Void {
    if !IsDefined(this.m_owner) || !this.m_owner.IsAttached() {
      return;
    };
    this.ActionOff(this.m_owner);
  }
}

// Quickhacks/Quickhacks.reds


// might not be needed in 2.0

@wrapMethod(QuickhackModule)
protected func Process(out task: HUDJob, mode: ActiveMode) -> Void {
  let instruction: ref<QuickhackInstance>;
  if !IsDefined(task.actor) {
    return;
  };
  if IsDefined(this.m_hud.GetCurrentTarget()) && (Equals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.DEVICE) || Equals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.BODY_DISPOSAL_DEVICE) || Equals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.PUPPET) || Equals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.VEHICLE)) {
    if task.actor == this.m_hud.GetCurrentTarget() {
      if this.m_hud.GetCurrentTarget().GetShouldRefreshQHack() {
        this.m_calculateClose = true;
        this.m_hud.GetCurrentTarget().SetShouldRefreshQHack(false);
        instruction = task.instruction.quickhackInstruction;
        if IsDefined(instruction) && IsDefined(task.actor) {
          instruction.SetState(InstanceState.ON, this.DuplicateLastInstance(task.actor));
          instruction.SetContext(this.BaseOpenCheck());
        };
      };
    };
  } else {
    if this.m_calculateClose {
      if !IsDefined(this.m_hud.GetCurrentTarget()) || NotEquals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.DEVICE) || NotEquals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.BODY_DISPOSAL_DEVICE) || NotEquals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.PUPPET) || NotEquals(this.m_hud.GetCurrentTarget().GetType(), HUDActorType.VEHICLE) {
        this.m_calculateClose = false;
        this.m_hud.GetLastTarget().SetShouldRefreshQHack(true);
        QuickhackModule.SendRevealQuickhackMenu(this.m_hud, this.m_hud.GetPlayer().GetEntityID(), false);
      };
    };
  };
}

@wrapMethod(HUDManager)
private final func CanShowHintMessage() -> Bool {
  let attitudeCheck: Bool;
  let currentTargetObj: wref<GameObject>;
  if Equals(this.m_currentTarget.GetType(), HUDActorType.PUPPET) || Equals(this.m_currentTarget.GetType(), HUDActorType.DEVICE) || Equals(this.m_currentTarget.GetType(), HUDActorType.BODY_DISPOSAL_DEVICE) || Equals(this.m_currentTarget.GetType(), HUDActorType.VEHICLE) {
    currentTargetObj = GameInstance.FindEntityByID(this.GetGameInstance(), this.m_currentTarget.GetEntityID()) as GameObject;
    attitudeCheck = NotEquals(GameObject.GetAttitudeTowards(this.GetPlayer(), currentTargetObj), EAIAttitude.AIA_Friendly);
    return this.IsCyberdeckEquipped() && attitudeCheck;
  };
  if Equals(this.m_currentTarget.GetType(), HUDActorType.ITEM) {
    return false;
  };
  return this.IsCyberdeckEquipped();
}

// added in 2.0
// @addMethod(VehicleObject)
// public const func IsQuickHackAble() -> Bool {
//   return true;
// }

// added in 2.0
// @addMethod(VehicleObject)
// public const func IsQuickHacksExposed() -> Bool {
//   return true;
// }

@addMethod(VehicleObject)
public const func ShouldEnableRemoteLayer() -> Bool {
  return this.IsTechie() || this.IsQuickHacksExposed() && this.IsNetrunner();
}

// added in 2.0
// @addMethod(VehicleObject)
// public const func CanRevealRemoteActionsWheel() -> Bool {
//   if !this.ShouldRegisterToHUD() {
//     return false;
//   };
//   if !this.IsQuickHackAble() {
//     return false;
//   };
//   return true;
// }

// @addMethod(VehicleObject)
// protected cb func OnQuickHackPanelStateChanged(evt: ref<QuickHackPanelStateEvent>) -> Bool {
//  this.DetermineInteractionStateByTask();
// }

// added in 2.0
// @addMethod(VehicleObject)
// public const func ShouldRegisterToHUD() -> Bool {
//   return true;
// }

// @addMethod(VehicleObject)
// protected final func DetermineInteractionStateByTask() -> Void {
//   GameInstance.GetDelaySystem(this.GetGame()).QueueTask(this, null, n"DetermineInteractionStateTask", gameScriptTaskExecutionStage.Any);
// }

// @addMethod(VehicleObject)
// protected final func DetermineInteractionStateTask(data: ref<ScriptTaskData>) -> Void {
//   this.DetermineInteractionState();
// }

// @addMethod(VehicleObject)
// protected final func DetermineInteractionState() -> Void {
//   let context: GetActionsContext;
//     context.requestorID = this.GetEntityID();
//     context.requestType = gamedeviceRequestType.Remote;
//     context.processInitiatorObject = GetPlayer(this.GetGame());
//     this.GetPS().DetermineInteractionState(this.m_interactionComponent, context, this.m_objectActionsCallbackCtrl);
// }

// @addMethod(VehicleComponentPS)
// public func OnFlightMalfunction(evt: ref<FlightMalfunction>) -> EntityNotificationType {
//   FlightLog.Info("[VehicleComponentPS] OnFlightMalfunction");
//   return EntityNotificationType.SendThisEventToEntity;
// }

// @addMethod(VehicleObject)
// protected cb func OnFlightMalfunction(evt: ref<FlightMalfunction>) -> Bool {
//   FlightLog.Info("[VehicleObject] OnFlightMalfunction");
// }

// @addMethod(VehicleObject)
// protected cb func OnPerformedAction(evt: ref<PerformedAction>) -> Bool {
//     FlightLog.Info("[VehicleObject] OnPerformedAction");
//   let action: ref<ScriptableDeviceAction>;
//   // let sequenceQuickHacks: ref<ForwardAction>;
//   this.SetScannerDirty(true);
//   action = evt.m_action as ScriptableDeviceAction;
//   // this.ExecuteBaseActionOperation(evt.m_action.GetClassName());
//   if action.CanTriggerStim() {
//     // this.TriggerAreaEffectDistractionByAction(action);
//   };
//   if IsDefined(action) && action.IsIllegal() && !action.IsQuickHack() {
//     // this.ResolveIllegalAction(action.GetExecutor(), action.GetDurationValue());
//   };
//   // if this.IsConnectedToActionsSequencer() && !this.IsLockedViaSequencer() {
//     // sequenceQuickHacks = new ForwardAction();
//     // sequenceQuickHacks.requester = this.GetDevicePS().GetID();
//     // sequenceQuickHacks.actionToForward = action;
//     // GameInstance.GetPersistencySystem(this.GetGame()).QueuePSEvent(this.GetDevicePS().GetActionsSequencer().GetID(), this.GetDevicePS().GetActionsSequencer().GetClassName(), sequenceQuickHacks);
//   // };
//   // this.ResolveQuestImportanceOnPerformedAction(action);
// }

// added in 2.0
// @addMethod(VehicleObject)
// protected func SendQuickhackCommands(shouldOpen: Bool) {
//   // FlightLog.Info("[VehicleObject] SendQuickhackCommands()");
//   let actions: array<ref<DeviceAction>>;
//   let commands: array<ref<QuickhackData>>;
//   // let context: GetActionsContext;
//   let quickSlotsManagerNotification: ref<RevealInteractionWheel> = new RevealInteractionWheel();
//   quickSlotsManagerNotification.lookAtObject = this;
//   quickSlotsManagerNotification.shouldReveal = shouldOpen;
//   if shouldOpen {
//     // FlightLog.Info("[VehicleObject] SendQuickhackCommands() shouldOpen == true");
//     // context = this.GetPS().GenerateContext(gamedeviceRequestType.Remote, Device.GetInteractionClearance(), this.GetPlayerMainObject(), this.GetEntityID());
//     // this.GetPS().GetRemoteActions(actions, context);
    
//     // action.SetInactiveWithReason(false, "LocKey#49279");
//     if this.m_flightComponent.isQuickHackable {
//       ArrayPush(actions, ActionFlightEnable(this));
//       ArrayPush(actions, ActionFlightDisable(this));
//       ArrayPush(actions, ActionFlightMalfunction(this));
//       ArrayPush(actions, ActionDisableGravity(this));
//       ArrayPush(actions, ActionEnableGravity(this));
//       ArrayPush(actions, ActionFunhouse(this));
//     }

//     if this.m_isQhackUploadInProgerss {
//       ScriptableDeviceComponentPS.SetActionsInactiveAll(actions, "LocKey#7020");
//     };
//     this.TranslateActionsIntoQuickSlotCommands(actions, commands);
//     quickSlotsManagerNotification.commands = commands;
//   };
//   // HUDManager.SetQHDescriptionVisibility(this.GetGame(), shouldOpen);
//   GameInstance.GetUISystem(this.GetGame()).QueueEvent(quickSlotsManagerNotification);
// }

@replaceMethod(VehicleObject)
protected func SendQuickhackCommands(shouldOpen: Bool) {
  // FlightLog.Info("[VehicleObject] SendQuickhackCommands()");
  let ltbf_actions: array<ref<DeviceAction>>;
  let actions: array<ref<DeviceAction>>;
  let commands: array<ref<QuickhackData>>;
  let context: GetActionsContext;
  let quickSlotsManagerNotification: ref<RevealInteractionWheel> = new RevealInteractionWheel();
  quickSlotsManagerNotification.lookAtObject = this;
  if shouldOpen {
    // FlightLog.Info("[VehicleObject] SendQuickhackCommands() shouldOpen == true");
    // context = this.GetPS().GenerateContext(gamedeviceRequestType.Remote, Device.GetInteractionClearance(), this.GetPlayerMainObject(), this.GetEntityID());
    // this.GetPS().GetRemoteActions(actions, context);
    
    context = this.GetVehiclePS().GenerateContext(gamedeviceRequestType.Remote, Device.GetInteractionClearance(), GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerControlledGameObject(), this.GetEntityID());
    this.GetVehiclePS().GetRemoteActions(actions, context);
    
    // action.SetInactiveWithReason(false, "LocKey#49279");
    if this.CanEnterFlight() && this.m_flightComponent.isQuickHackable {
      ArrayPush(ltbf_actions, ActionFlightEnable(this));
      ArrayPush(ltbf_actions, ActionFlightDisable(this));
      ArrayPush(ltbf_actions, ActionFlightMalfunction(this));
      ArrayPush(ltbf_actions, ActionDisableGravity(this));
      ArrayPush(ltbf_actions, ActionEnableGravity(this));
      ArrayPush(ltbf_actions, ActionFunhouse(this));
    }

    // if this.m_isQhackUploadInProgerss {
    //   ScriptableDeviceComponentPS.SetActionsInactiveAll(ltbf_actions, "LocKey#7020");
    // };
    if this.m_isQhackUploadInProgress && !this.IsActionQueueEnabled() || this.IsActionQueueFull() {
      ScriptableDeviceComponentPS.SetActionsInactiveAll(ltbf_actions, "LocKey#7020");
      ScriptableDeviceComponentPS.SetActionsInactiveAll(actions, "LocKey#7020");
    };
    if this.IsActionQueueEnabled() {
      QuickHackableQueueHelper.CheckAndSetInactivityReasonForVehicleActions(ltbf_actions, this.m_currentlyUploadingAction);
      QuickHackableQueueHelper.CheckAndSetInactivityReasonForVehicleActions(actions, this.m_currentlyUploadingAction);
    };
    QuickHackableHelper.TranslateActionsIntoQuickSlotCommands(actions, commands, this, this.GetVehiclePS());
    this.TranslateActionsIntoQuickSlotCommands(ltbf_actions, commands);
    quickSlotsManagerNotification.commands = commands;
    quickSlotsManagerNotification.shouldReveal = ArraySize(actions) > 0 || ArraySize(ltbf_actions) > 0;
  };
  // HUDManager.SetQHDescriptionVisibility(this.GetGame(), shouldOpen);
  GameInstance.GetUISystem(this.GetGame()).QueueEvent(quickSlotsManagerNotification);
}

@addMethod(VehicleObject)
protected cb func OnQuickSlotCommandUsed(evt: ref<QuickSlotCommandUsed>) -> Bool {
  this.ExecuteAction(evt.action, GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerControlledGameObject());
}

@addMethod(VehicleObject)
protected final const func ExecuteAction(choice: InteractionChoice, executor: wref<GameObject>, layerTag: CName) -> Void {
  let action: ref<ScriptableDeviceAction>;
  let sAction: ref<ScriptableDeviceAction>;
  let i: Int32 = 0;
  while i < ArraySize(choice.data) {
    action = FromVariant<ref<ScriptableDeviceAction>>(choice.data[i]);
    if IsDefined(action) {
      if ChoiceTypeWrapper.IsType(choice.choiceMetaData.type, gameinteractionsChoiceType.CheckFailed) {
        return;
      };
      this.ExecuteAction(action, executor);
    };
    sAction = action as ScriptableDeviceAction;
    if IsDefined(sAction) {
      sAction.SetInteractionLayer(layerTag);
    };
    i += 1;
  };
}

@addMethod(VehicleObject)
protected final const func ExecuteAction(action: ref<DeviceAction>, opt executor: wref<GameObject>) -> Bool {
  let sAction: ref<ScriptableDeviceAction> = action as ScriptableDeviceAction;
  if sAction != null {
    sAction.RegisterAsRequester(this.GetEntityID());
    if executor != null {
      sAction.SetExecutor(executor);
    };
    sAction.ProcessRPGAction(this.GetGame());
    return true;
  };
  return false;
}

// added in 2.0
// @addField(VehicleObject)
// public let m_isQhackUploadInProgerss: Bool;

// added in 2.0
// @addMethod(VehicleObject)
// protected cb func OnUploadProgressStateChanged(evt: ref<UploadProgramProgressEvent>) -> Bool {
//   // FlightLog.Info("[VehicleObject] OnUploadProgressStateChanged");
//   if Equals(evt.progressBarContext, EProgressBarContext.QuickHack) {
//     if Equals(evt.progressBarType, EProgressBarType.UPLOAD) {
//       if Equals(evt.state, EUploadProgramState.STARTED) {
//         this.m_isQhackUploadInProgerss = true;
//       } else {
//         if Equals(evt.state, EUploadProgramState.COMPLETED) {
//           this.m_isQhackUploadInProgerss = false;
//         };
//       };
//     };
//   };
// }

@addMethod(VehicleObject)
protected cb func OnScanningLookedAt(evt: ref<ScanningLookAtEvent>) -> Bool {
  super.OnScanningLookedAt(evt);
  let playerPuppet: ref<PlayerPuppet> = GameInstance.FindEntityByID(this.GetGame(), evt.ownerID) as PlayerPuppet;
  if IsDefined(playerPuppet) && evt.state {
    if this.IsDead() {
      return IsDefined(null);
    };
    this.UpdateScannerLookAtBB(true);
  } else {
    this.UpdateScannerLookAtBB(false);
  };
}

@addMethod(VehicleObject)
private final func UpdateScannerLookAtBB(b: Bool) -> Void {
  let scannerBlackboard: wref<IBlackboard> = GameInstance.GetBlackboardSystem(this.GetGame()).Get(GetAllBlackboardDefs().UI_Scanner);
  scannerBlackboard.SetBool(GetAllBlackboardDefs().UI_Scanner.ScannerLookAt, b);
}

@addMethod(VehicleObject)
private final const func GetQuickHackDuration(quickHackRecord: wref<ObjectAction_Record>, rootObject: wref<GameObject>, targetID: StatsObjectID, instigatorID: EntityID) -> Float {
  let durationMods: array<wref<ObjectActionEffect_Record>>;
  if !IsDefined(quickHackRecord) {
    return 0.00;
  };
  quickHackRecord.CompletionEffects(durationMods);
  return this.GetObjectActionEffectDurationValue(durationMods, rootObject, targetID, instigatorID);
}

@addMethod(VehicleObject)
private final const func GetQuickHackDuration(quickHackID: TweakDBID, rootObject: wref<GameObject>, targetID: StatsObjectID, instigatorID: EntityID) -> Float {
  let durationMods: array<wref<ObjectActionEffect_Record>>;
  let actionRecord: wref<ObjectAction_Record> = TweakDBInterface.GetObjectActionRecord(quickHackID);
  if !IsDefined(actionRecord) {
    return 0.00;
  };
  actionRecord.CompletionEffects(durationMods);
  return this.GetObjectActionEffectDurationValue(durationMods, rootObject, targetID, instigatorID);
}


@addMethod(VehicleObject)
   private final const func GetIgnoredDurationStats() -> array<wref<StatusEffect_Record>> {
    let result: array<wref<StatusEffect_Record>>;
    ArrayPush(result, TweakDBInterface.GetStatusEffectRecord(t"BaseStatusEffect.WasQuickHacked"));
    ArrayPush(result, TweakDBInterface.GetStatusEffectRecord(t"BaseStatusEffect.QuickHackUploaded"));
    return result;
  }

@addMethod(VehicleObject)
  private final const func GetObjectActionEffectDurationValue(durationMods: array<wref<ObjectActionEffect_Record>>, rootObject: wref<GameObject>, targetID: StatsObjectID, instigatorID: EntityID) -> Float {
    let duration: wref<StatModifierGroup_Record>;
    let durationValue: Float;
    let effectToCast: wref<StatusEffect_Record>;
    let i: Int32;
    let ignoredDurationStats: array<wref<StatusEffect_Record>>;
    let lastMatchingEffect: wref<StatusEffect_Record>;
    let statModifiers: array<wref<StatModifier_Record>>;
    if ArraySize(durationMods) > 0 {
      ignoredDurationStats = this.GetIgnoredDurationStats();
      i = 0;
      while i < ArraySize(durationMods) {
        effectToCast = durationMods[i].StatusEffect();
        if IsDefined(effectToCast) {
          if !ArrayContains(ignoredDurationStats, effectToCast) {
            lastMatchingEffect = effectToCast;
          };
        };
        i += 1;
      };
      effectToCast = lastMatchingEffect;
      duration = effectToCast.Duration();
      duration.StatModifiers(statModifiers);
      durationValue = RPGManager.CalculateStatModifiers(statModifiers, this.GetGame(), rootObject, targetID, Cast<StatsObjectID>(instigatorID));
    };
    return durationValue;
  }

  
@addMethod(VehicleObject)
private final const func GetICELevel() -> Float {
  let statsSystem: ref<StatsSystem> = GameInstance.GetStatsSystem(this.GetGame());
  let playerLevel: Float = statsSystem.GetStatValue(Cast<StatsObjectID>(GetPlayer(this.GetGame()).GetEntityID()), gamedataStatType.Level);
  let targetLevel: Float = statsSystem.GetStatValue(Cast<StatsObjectID>(this.GetEntityID()), gamedataStatType.Level);
  let resistance: Float = statsSystem.GetStatValue(Cast<StatsObjectID>(this.GetEntityID()), gamedataStatType.HackingResistance);
  return resistance + 0.50 * (targetLevel - playerLevel);
}

@addMethod(VehicleObject)
  private final func TranslateActionsIntoQuickSlotCommands(actions: array<ref<DeviceAction>>, out commands: array<ref<QuickhackData>>) -> Void {
    let actionCompletionEffects: array<wref<ObjectActionEffect_Record>>;
    let actionRecord: wref<ObjectAction_Record>;
    let actionStartEffects: array<wref<ObjectActionEffect_Record>>;
    // let choice: InteractionChoice;
    // let emptyChoice: InteractionChoice;
    let i: Int32;
    let i1: Int32;
    let newCommand: ref<QuickhackData>;    
    // let prereqsToCheck: array<wref<IPrereq_Record>>;
    let targetActivePrereqs: array<wref<ObjectActionPrereq_Record>>;
    let sAction: ref<FlightAction>;
    let isOngoingUpload: Bool = GameInstance.GetStatPoolsSystem(this.GetGame()).IsStatPoolAdded(Cast<StatsObjectID>(this.GetEntityID()), gamedataStatPoolType.QuickHackUpload);
    let statModifiers: array<wref<StatModifier_Record>>;
    let playerRef: ref<PlayerPuppet> = GetPlayer(this.GetGame());
    let iceLVL: Float = this.GetICELevel();
    let actionOwnerName: CName = StringToName(this.GetDisplayName());
    if ArraySize(actions) == 0 {
      newCommand = new QuickhackData();
      newCommand.m_title = "LocKey#42171";
      newCommand.m_isLocked = true;
      newCommand.m_actionState = EActionInactivityReson.Invalid;
      newCommand.m_actionOwnerName = StringToName(this.GetDisplayName());
      newCommand.m_description = "LocKey#42172";
      ArrayPush(commands, newCommand);
    } else {
      i = 0;
      while i < ArraySize(actions) {
        newCommand = new QuickhackData();
        ArrayClear(actionStartEffects);
        sAction = actions[i] as FlightAction;
        actionRecord = sAction.GetObjectActionRecord();
        // if NotEquals(actionRecord.ObjectActionType().Type(), gamedataObjectActionType.DeviceQuickHack) {
        // } else {
          newCommand.m_uploadTime = sAction.GetActivationTime();
          // newCommand.m_duration = sAction.GetDurationValue();
          newCommand.m_duration = this.GetQuickHackDuration(actionRecord, this, Cast<StatsObjectID>(this.GetEntityID()), playerRef.GetEntityID());         
          // newCommand.m_title = GetLocalizedTextByKey(sAction.title);
          // if StrLen(newCommand.m_title) == 0 {
            // newCommand.m_title = ToString(sAction.title);
          // };
          // newCommand.m_description = GetLocalizedTextByKey(sAction.description);
          // if StrLen(newCommand.m_description) == 0 {
            // newCommand.m_description = ToString(sAction.title);
          // };
          newCommand.m_actionOwnerName = actionOwnerName;
          newCommand.m_title = LocKeyToString(actionRecord.ObjectActionUI().Caption());
          newCommand.m_description = LocKeyToString(actionRecord.ObjectActionUI().Description());
          newCommand.m_icon = sAction.icon;
          newCommand.m_iconCategory = actionRecord.GameplayCategory().IconName();
          newCommand.m_type = actionRecord.ObjectActionType().Type();
          newCommand.m_actionOwner = this.GetEntityID();
          newCommand.m_isInstant = false;
          newCommand.m_ICELevel = iceLVL;
          newCommand.m_ICELevelVisible = true;
          // newCommand.m_vulnerabilities = this.GetPS().GetActiveQuickHackVulnerabilities();
          newCommand.m_actionState = EActionInactivityReson.Locked;
          // newCommand.m_quality = sAction.quality;
          newCommand.m_costRaw = BaseScriptableAction.GetBaseCostStatic(playerRef, actionRecord);
          newCommand.m_category = actionRecord.HackCategory();
          ArrayClear(actionCompletionEffects);
          actionRecord.CompletionEffects(actionCompletionEffects);
          newCommand.m_actionCompletionEffects = actionCompletionEffects;
          actionRecord.StartEffects(actionStartEffects);
          i1 = 0;
          while i1 < ArraySize(actionStartEffects) {
            if Equals(actionStartEffects[i1].StatusEffect().StatusEffectType().Type(), gamedataStatusEffectType.PlayerCooldown) {
              actionStartEffects[i1].StatusEffect().Duration().StatModifiers(statModifiers);
              newCommand.m_cooldown = RPGManager.CalculateStatModifiers(statModifiers, this.GetGame(), playerRef, Cast<StatsObjectID>(playerRef.GetEntityID()), Cast<StatsObjectID>(playerRef.GetEntityID()));
              newCommand.m_cooldownTweak = actionStartEffects[i1].StatusEffect().GetID();
              ArrayClear(statModifiers);
            };
            if newCommand.m_cooldown != 0.00 {
            }
            i1 += 1;
          };
          // if !IsDefined(this as GenericDevice) {
          //   choice = emptyChoice;
          //   choice = sAction.GetInteractionChoice();
          //   if TDBID.IsValid(choice.choiceMetaData.tweakDBID) {
          //     newCommand.m_titleAlternative = LocKeyToString(TweakDBInterface.GetInteractionBaseRecord(choice.choiceMetaData.tweakDBID).Caption());
          //   };
          // };

          newCommand.m_costRaw = sAction.GetBaseCost();
          newCommand.m_cost = sAction.GetCost();
          if !sAction.IsPossible(this) || !sAction.IsVisible(playerRef) {
            sAction.SetInactiveWithReason(false, "LocKey#7019");
          } else {
            newCommand.m_uploadTime = sAction.GetActivationTime();
            // let interactionChoice = sAction.GetInteractionChoice();
            // let i2 = 0;
            // while i2 < ArraySize(interactionChoice.captionParts.parts) {
            //   if IsDefined(interactionChoice.captionParts.parts[i2] as InteractionChoiceCaptionStringPart) {
            //     newCommand.m_title = GetLocalizedText(interactionChoice.captionParts.parts[i2] as InteractionChoiceCaptionStringPart.content);
            //   };
            //   i2 += 1;
            // };
            if sAction.IsInactive() {
            } else {
              if !sAction.CanPayCost(playerRef) {
                newCommand.m_actionState = EActionInactivityReson.OutOfMemory;
                sAction.SetInactiveWithReason(false, "LocKey#27398");
              };
              if actionRecord.GetTargetActivePrereqsCount() > 0 {
                ArrayClear(targetActivePrereqs);
                actionRecord.TargetActivePrereqs(targetActivePrereqs);
                // i2 = 0;
                // while i2 < ArraySize(targetActivePrereqs) {
                //   ArrayClear(prereqsToCheck);
                //   targetActivePrereqs[i2].FailureConditionPrereq(prereqsToCheck);
                //   if !RPGManager.CheckPrereqs(prereqsToCheck, this) {
                //     sAction.SetInactiveWithReason(false, targetActivePrereqs[i2].FailureExplanation());
                //   }
                //   i2 += 1;
                // };
              };
              if isOngoingUpload {
                sAction.SetInactiveWithReason(false, "LocKey#7020");
              };
            }
          }


          if sAction.IsInactive() {
            newCommand.m_isLocked = true;
            newCommand.m_inactiveReason = sAction.GetInactiveReason();
            if this.HasActiveQuickHackUpload() {
              newCommand.m_action = sAction;
            };
          } else {
            if !sAction.CanPayCost() {
              newCommand.m_actionState = EActionInactivityReson.OutOfMemory;
              newCommand.m_isLocked = true;
              newCommand.m_inactiveReason = "LocKey#27398";
            };
            if GameInstance.GetStatPoolsSystem(this.GetGame()).HasActiveStatPool(Cast<StatsObjectID>(this.GetEntityID()), gamedataStatPoolType.QuickHackUpload) {
              newCommand.m_isLocked = true;
              newCommand.m_inactiveReason = "LocKey#27398";
            };
            if !sAction.IsInactive() || this.HasActiveQuickHackUpload() {
              newCommand.m_action = sAction;
            };
          };
          newCommand.m_actionMatchesTarget = true;
          if !newCommand.m_isLocked {
            newCommand.m_actionState = EActionInactivityReson.Ready;
          };
          ArrayPush(commands, newCommand);
        // };
        i += 1;
      };
    };
    i = 0;
    while i < ArraySize(commands) {
      if commands[i].m_isLocked && IsDefined(commands[i].m_action) {
        (commands[i].m_action as ScriptableDeviceAction).SetInactiveWithReason(false, commands[i].m_inactiveReason);
      };
      i += 1;
    };
    QuickhackModule.SortCommandPriority(commands, this.GetGame());
  }

// */

// 2.0 method that isn't working

// @replaceMethod(VehicleComponentPS)
// protected func GetQuickHackActions(out outActions: array<ref<DeviceAction>>, const context: script_ref<GetActionsContext>) -> Void {
//   let areVehicleQuickhacksAvailable: Bool;
//   let controllerPS: ref<vehicleControllerPS>;
//   let currentAction: ref<ScriptableDeviceAction>;
//   let playerMountedVehicle: wref<VehicleObject>;
//   let playerPuppet: ref<PlayerPuppet>;
//   let vehicleState: vehicleEState;
//   let isValidRange: Bool = false;
//   let isVehicleRemoteControlled: Bool = this.GetOwnerEntity().IsVehicleRemoteControlled();
//   let maxDistance: Float = TweakDBInterface.GetFloat(t"player.vehicleQuickHacks.maxRange", 0.00);
//   if this.GetOwnerEntity().GetDistanceToPlayerSquared() < maxDistance * maxDistance {
//     isValidRange = true;
//   };
//   playerPuppet = GameInstance.GetPlayerSystem(this.GetGameInstance()).GetLocalPlayerMainGameObject() as PlayerPuppet;
//   if PlayerDevelopmentSystem.GetData(playerPuppet).IsNewPerkBoughtAnyLevel(gamedataNewPerkType.Intelligence_Right_Milestone_1) {
//     controllerPS = this.GetVehicleControllerPS();
//     vehicleState = controllerPS.GetState();
//     areVehicleQuickhacksAvailable = this.GetOwnerEntity().IsHackable();
//     if !this.GetIsDestroyed() {
//       if !VehicleComponent.GetVehicle(playerPuppet.GetGame(), playerPuppet.GetEntityID(), playerMountedVehicle) {
//         currentAction = this.ActionToggleTakeOverControl();
//         currentAction.SetObjectActionID(t"DeviceAction.TakeControlVehicleClassHack");
//         currentAction.SetExecutor(GetPlayer(this.GetGameInstance()));
//         currentAction.SetDurationValue(currentAction.GetDurationTime());
//         ArrayPush(outActions, currentAction);
//         if !isValidRange || isVehicleRemoteControlled || Equals(this.GetOwnerEntity().GetVehicleType(), gamedataVehicleType.Bike) && playerPuppet.CheckIsStandingOnVehicle(this.GetOwnerEntity().GetEntityID()) {
//           currentAction.SetInactiveWithReason(false, "LocKey#7003");
//         };
//       };
//       currentAction = this.ActionVehicleOverrideForceBrakes();
//       currentAction.SetObjectActionID(t"DeviceAction.VehicleForceBrakesClassHack");
//       currentAction.SetExecutor(GetPlayer(this.GetGameInstance()));
//       currentAction.SetDurationValue(TweakDBInterface.GetFloat(t"player.vehicleQuickHacks.forceBrakesDuration", 0.00));
//       if !isValidRange || isVehicleRemoteControlled {
//         currentAction.SetInactiveWithReason(false, "LocKey#7003");
//       } else {
//         if this.GetOwnerEntity().IsVehicleForceBrakesQuickhackActive() {
//           currentAction.SetInactiveWithReason(false, "LocKey#7004");
//         };
//       };
//       ArrayPush(outActions, currentAction);
//       currentAction = this.ActionVehicleOverrideExplode();
//       currentAction.SetObjectActionID(t"DeviceAction.VehicleExplodeClassHack");
//       currentAction.SetExecutor(GetPlayer(this.GetGameInstance()));
//       currentAction.SetDurationValue(currentAction.GetDurationTime());
//       ArrayPush(outActions, currentAction);
//       if !isValidRange {
//         currentAction.SetInactiveWithReason(false, "LocKey#7003");
//       };
//       currentAction = this.ActionVehicleOverrideAccelerate();
//       currentAction.SetObjectActionID(t"DeviceAction.VehicleAccelerateClassHack");
//       currentAction.SetExecutor(GetPlayer(this.GetGameInstance()));
//       currentAction.SetDurationValue(TweakDBInterface.GetFloat(t"player.vehicleQuickHacks.accelerateDuration", 0.00));
//       if !isValidRange || isVehicleRemoteControlled {
//         currentAction.SetInactiveWithReason(false, "LocKey#7003");
//       } else {
//         if this.GetOwnerEntity().IsVehicleAccelerateQuickhackActive() {
//           currentAction.SetInactiveWithReason(false, "LocKey#7004");
//         };
//       };
//       ArrayPush(outActions, currentAction);

//       // Flight QuickHacks
//       // ArrayPush(outActions, ActionFlightEnable(this.GetOwnerEntity()));
//       // ArrayPush(outActions, ActionFlightDisable(this.GetOwnerEntity()));
//       // ArrayPush(outActions, ActionFlightMalfunction(this.GetOwnerEntity()));
//       // ArrayPush(outActions, ActionDisableGravity(this.GetOwnerEntity()));
//       // ArrayPush(outActions, ActionEnableGravity(this.GetOwnerEntity()));
//       // ArrayPush(outActions, ActionFunhouse(this.GetOwnerEntity()));
//     };
//     if !areVehicleQuickhacksAvailable || Equals(vehicleState, vehicleEState.Destroyed) || Equals(vehicleState, vehicleEState.Disabled) || this.GetOwnerEntity().IsVehicleInsideInnerAreaOfAreaSpeedLimiter() {
//       ScriptableDeviceComponentPS.SetActionsInactiveAll(outActions, "LocKey#27694");
//     };
//   };
//   this.FinalizeGetQuickHackActions(outActions, context);
// }

// @wrapMethod(QuickhacksListGameController)
// private final func SelectData(data: ref<QuickhackData>) -> Void {
//   wrappedMethod(data);
//   // let description: String = GetLocalizedText(this.m_selectedData.m_description);
//   // if StrLen(description) == 0 || Equals(description, "Loading") {
//       let description = ToString(this.m_selectedData.m_description);
//   // };
//   inkTextRef.SetText(this.m_description, description);
// }


@wrapMethod(QuickHackDescriptionGameController)
protected cb func OnQuickHackDataChanged(value: Variant) -> Bool {
  wrappedMethod(value);
  this.m_selectedData = FromVariant<ref<QuickhackData>>(value);
  if IsDefined(this.m_selectedData) {
    let title: String = GetLocalizedText(this.m_selectedData.m_title);
    if StrLen(title) == 0 {
      title = ToString(this.m_selectedData.m_title);
    }
    inkTextRef.SetText(this.m_subHeader, title);

    let description: String = GetLocalizedText(this.m_selectedData.m_description);
    if StrLen(description) == 0 {
      description = ToString(this.m_selectedData.m_description);
    }
    inkTextRef.SetText(this.m_description, description);
  }
}

// UI/hudFlightController.reds


public class FlightUIVehicleHealthStatPoolListener extends CustomValueStatPoolsListener {

  public let m_owner: wref<hudFlightController>;
  public let m_vehicle: wref<VehicleObject>;

  public func OnStatPoolValueChanged(oldValue: Float, newValue: Float, percToPoints: Float) -> Void {
    if IsDefined(this.m_owner) {
      this.m_owner.ReactToHPChange(newValue);
    };
  }
}

public class hudFlightController extends inkHUDGameController {

  @runtimeProperty("ModSettings.mod", "Let There Be Flight")
  @runtimeProperty("ModSettings.category", "UI-Settings-Flight-UI-Settings")
  @runtimeProperty("ModSettings.displayName", "UI-Settings-Enabled")
  public let enabled: Bool = true;

  private let m_Date: inkTextRef;
  private let m_Timer: inkTextRef;
  private let m_CameraID: inkTextRef;
  private let healthStatus: inkTextRef;
  private let m_MessageText: inkTextRef;
  private let m_pitchFluff: inkTextRef;
  private let m_yawFluff: inkTextRef;
  private let m_leftPart: inkWidgetRef;
  private let m_rightPart: inkWidgetRef;
  // @default(hudFlightController, -838.0f)
  private let offsetLeft: Float;
  // @default(hudFlightController, 1495.0f)
  private let offsetRight: Float;
  private let currentTime: GameTime;
  private let m_currentHealth: Int32;
  private let m_previousHealth: Int32;
  private let m_maximumHealth: Int32;
  private let m_playerObject: wref<GameObject>;
  private let m_playerPuppet: wref<GameObject>;
  private let m_gameInstance: GameInstance;
  private let m_animationProxy: ref<inkAnimProxy>;

  private let m_bbPlayerStats: wref<IBlackboard>;
  private let m_scannerBlackboard: wref<IBlackboard>;
  private let m_vehicleBlackboard: wref<IBlackboard>;
  private let m_vehicleFlightBlackboard: wref<IBlackboard>;
  private let m_psmBlackboard: wref<IBlackboard>;

  private let m_uiScannerVisibleCallbackID: ref<CallbackHandle>;
  private let m_bbPlayerEventId: ref<CallbackHandle>;
  private let m_PSM_BBID: ref<CallbackHandle>;
  private let m_playerStateBBConnectionId: ref<CallbackHandle>;
  private let m_vehicleBBUIActivId: ref<CallbackHandle>;
  private let m_vehicleBBActivId: ref<CallbackHandle>;
  private let m_vehicleBBModeId: ref<CallbackHandle>;
  private let m_vehicleRollID: ref<CallbackHandle>;
  private let m_vehiclePitchID: ref<CallbackHandle>;
  private let m_mountedCombatID: ref<CallbackHandle>;
  private let m_isMountedCombat: Bool;
  private let m_tppBBConnectionId: ref<CallbackHandle>;
  private let m_isTPP: Bool;

  public let m_healthStatPoolListener: ref<FlightUIVehicleHealthStatPoolListener>;
  private let m_hp_mask: inkWidgetRef;
  private let m_hp_condition_text: inkTextRef;
  private let m_currentZoom: Float;

  protected cb func OnInitialize() -> Bool {
    FlightLog.Info("[hudFlightController] OnInitialize");
    // let delayInitialize: ref<DelayedHUDInitializeEvent>;
    // inkTextRef.SetText(this.m_Date, "XX-XX-XXXX");
    // delayInitialize = new DelayedHUDInitializeEvent();
    // GameInstance.GetDelaySystem(this.GetPlayerControlledObject().GetGame()).DelayEvent(this.GetPlayerControlledObject(), delayInitialize, 0.10);
    // this.GetPlayerControlledObject().RegisterInputListener(this);
    this.offsetLeft = -838.0;
    this.offsetRight = 1495.0;
    this.GetRootWidget().SetVisible(false);
    // this.PlayLibraryAnimation(n"outro");

    let vehicle = FlightSystem.GetInstance().playerComponent.GetVehicle();
    this.m_healthStatPoolListener = new FlightUIVehicleHealthStatPoolListener();
    this.m_healthStatPoolListener.m_owner = this;
    this.m_healthStatPoolListener.m_vehicle = vehicle;
    let stats = GameInstance.GetStatPoolsSystem(vehicle.GetGame());
    if IsDefined(stats) {  
      stats.RequestRegisteringListener(Cast<StatsObjectID>(vehicle.GetEntityID()), gamedataStatPoolType.Health, this.m_healthStatPoolListener);
    }
    
    LTBF_RegisterListener(this);
  }

  protected cb func OnUninitialize() -> Bool {
    LTBF_UnregisterListener(this);
    FlightLog.Info("[hudFlightController] OnUninitialize");
    // TakeOverControlSystem.CreateInputHint(this.GetPlayerControlledObject().GetGame(), false);
    // SecurityTurret.CreateInputHint(this.GetPlayerControlledObject().GetGame(), false);
    if IsDefined(this.m_healthStatPoolListener) {
      GameInstance.GetStatPoolsSystem(this.m_gameInstance).RequestUnregisteringListener(Cast(this.m_healthStatPoolListener.m_vehicle.GetEntityID()), gamedataStatPoolType.Health, this.m_healthStatPoolListener);
    }
  }

  private func UpdateTime() -> Void {
    this.currentTime = GameInstance.GetTimeSystem(this.m_gameInstance).GetGameTime();
    inkTextRef.SetText(this.m_Timer, ToString(GameTime.Hours(this.currentTime)) + ":" + ToString(GameTime.Minutes(this.currentTime)) + ":" + ToString(GameTime.Seconds(this.currentTime)));
  }

  private final func IsUIactive() -> Bool {
    if IsDefined(this.m_vehicleFlightBlackboard) && this.m_vehicleFlightBlackboard.GetBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive) {
      return true;
    };
    return false;
  }

  private final func IsActive() -> Bool {
    if IsDefined(this.m_vehicleFlightBlackboard) && this.m_vehicleFlightBlackboard.GetBool(GetAllBlackboardDefs().VehicleFlight.IsActive) {
      return true;
    };
    return false;
  }

  protected cb func OnActivateUI(activate: Bool) -> Bool {
    this.ActivateUI(activate);
  }

  protected cb func OnActivate(activate: Bool) -> Bool {
    if this.IsUIactive() {
      this.ActivateUI(activate);
    }
  }

  protected cb func OnModeChange(mode: Int32) -> Bool {
    inkTextRef.SetText(this.m_CameraID, FlightSystem.GetInstance().playerComponent.GetFlightMode().GetDescription());
  }

  protected cb func OnCameraModeChanged(tpp: Bool) -> Bool {
    this.m_isTPP = tpp;
    this.UpdateCrosshairVisibility();
    // let hp_gauge = this.GetRootCompoundWidget().GetWidget(n"hp_gauge");
    // if IsDefined(hp_gauge) {
      // if tpp {
      // } else {
      //   hp_gauge.SetMargin(new inkMargin(2150.0, 32.0 - 100.0, 0.0, 0.0));
      // }

      // right of LB hud stuff
      // hp_gauge.SetMargin(new inkMargin(2150.0, 32.0, 0.0, 0.0));
      // above of LB hud stuff
      // hp_gauge.SetMargin(new inkMargin(1520.0, -290.0, 0.0, 0.0));
    // }
  }

  
  private let m_crosshairAnimationProxy: ref<inkAnimProxy>;

  protected func ShouldShowCrosshair() -> Bool {
    return (this.m_isMountedCombat && !this.m_isTPP);
  }

  protected func UpdateCrosshairVisibility() -> Void {
    let widget = this.GetRootCompoundWidget().GetWidget(n"crosshairContainer");

    let opacityInterpolator = new inkAnimTransparency();
    opacityInterpolator.SetDuration(0.3);
    opacityInterpolator.SetStartTransparency(widget.GetOpacity());
    opacityInterpolator.SetEndTransparency(this.ShouldShowCrosshair() ? 1.0 : 0.0);
    opacityInterpolator.SetType(inkanimInterpolationType.Quintic);
    opacityInterpolator.SetMode(inkanimInterpolationMode.EasyInOut);
    let animation = new inkAnimDef();
    animation.AddInterpolator(opacityInterpolator);
    // let options: inkAnimOptions;

    if IsDefined(this.m_crosshairAnimationProxy) && this.m_crosshairAnimationProxy.IsPlaying() {
      this.m_crosshairAnimationProxy.Stop(true);
    };
    widget.SetVisible(true);
    this.m_crosshairAnimationProxy = widget.PlayAnimation(animation);
    this.m_crosshairAnimationProxy.RegisterToCallback(inkanimEventType.OnFinish, this, n"OnCrosshairAnimationFinished");
  }

  protected cb func OnCrosshairAnimationFinished(anim: ref<inkAnimProxy>) -> Bool {
    this.GetRootCompoundWidget().GetWidget(n"crosshairContainer").SetVisible(this.ShouldShowCrosshair());
  }

  protected cb func OnVehicleRollChanged(roll: Float) -> Bool {
    // if FlightSystem.GetInstance().playerComponent.GetFlightMode().usesRightStickInput && !FlightSystem.GetInstance().ctlr.isTPP {
    if !FlightSystem.GetInstance().ctlr.isTPP { // FPP
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/rulers").SetRotation(0);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/rulers/h").SetRotation(-roll);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/rotation").SetRotation(-roll);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/mask").SetVisible(false);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/mask").SetRotation(0);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch_mask").SetVisible(true);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/mask").SetRotation(0);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/mask").SetScale(new Vector2(1.0, 1.0));
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/crosshair").SetRotation(0);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/crosshair/reticle").SetRotation(-roll);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/RADIUS").SetRotation(-roll);
    } else { // TPP
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/rulers").SetRotation(roll);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/rulers/h").SetRotation(-roll);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/rotation").SetRotation(0);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/mask").SetVisible(true);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/mask").SetRotation(roll);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch_mask").SetVisible(false);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch_mask").SetRotation(roll);
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/mask").SetScale(new Vector2(1.0, 1.0));
      // this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/crosshair").SetRotation(roll);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/crosshair/reticle").SetRotation(0);
      this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/RADIUS").SetRotation(roll);
    }
  }

  protected cb func OnVehiclePitchChanged(pitch: Float) -> Bool {
    this.GetRootCompoundWidget().GetWidget(n"crosshairContainer/pitch/rotation/translation").SetTranslation(new Vector2(0.0, pitch/90.0 * 900.0));
  }

  protected cb func OnMountedCombatChanged(value: Bool) -> Bool {
    this.m_isMountedCombat = value;
    this.UpdateCrosshairVisibility();
  }

  private let m_introAnimationProxy: ref<inkAnimProxy>;
  private let m_outroAnimationProxy: ref<inkAnimProxy>;

  private func ActivateUI(activate: Bool) -> Void {

    FlightLog.Info("[hudFlightController] ActivateUI");
    if activate {
      if this.enabled {
        let vehicle = FlightSystem.GetInstance().playerComponent.GetVehicle();
        if IsDefined(vehicle) {
          inkTextRef.SetText(this.m_hp_condition_text, vehicle.GetDisplayName());
          let stats = GameInstance.GetStatPoolsSystem(this.m_gameInstance);
          this.ReactToHPChange(stats.GetStatPoolValue(Cast<StatsObjectID>(vehicle.GetEntityID()), gamedataStatPoolType.Health, true));  
        }
        inkTextRef.SetText(this.m_CameraID, FlightSystem.GetInstance().playerComponent.GetFlightMode().GetDescription());

        let hp_gauge = this.GetRootCompoundWidget().GetWidget(n"hp_gauge");
        if IsDefined(hp_gauge) {
          // right of LB hud stuff
          // hp_gauge.SetMargin(new inkMargin(2150.0, 32.0, 0.0, 0.0));
          // above of LB hud stuff
          hp_gauge.SetMargin(new inkMargin(1520.0, -370.0, 0.0, 0.0));
        }
        
        this.GetRootWidget().SetVisible(true);
        let options: inkAnimOptions;
        options.executionDelay = 0.50;
        if IsDefined(this.m_outroAnimationProxy) && this.m_outroAnimationProxy.IsPlaying() {
          this.m_outroAnimationProxy.Stop();
        }
        this.m_introAnimationProxy = this.PlayLibraryAnimation(n"intro", options);
        // this.PlayAnim(n"intro", n"OnIntroComplete");
        // optionIntro.executionDelay = 0.25;
        // this.PlayLibraryAnimation(n"Malfunction_off", optionIntro);
        // this.PlayAnim(n"Malfunction_timed", n"OnMalfunction");
        // this.UpdateJohnnyThemeOverride(true);
      }
    } else {
      // this.GetRootWidget().SetVisible(false);
      // this.PlayLibraryAnimation(n"outro");
      // this.PlayLibraryAnimation(n"Malfunction");
      let options: inkAnimOptions;
      if IsDefined(this.m_introAnimationProxy) && this.m_introAnimationProxy.IsPlaying() {
        this.m_introAnimationProxy.Stop();
      }
      this.m_outroAnimationProxy = this.PlayLibraryAnimation(n"outro", options);

      // this.PlayAnim(n"outro", n"OnOutroComplete");
      // this.UpdateJohnnyThemeOverride(false);
    }
  }

  protected cb func OnPlayerAttach(playerPuppet: ref<GameObject>) -> Bool {
    FlightLog.Info("[hudFlightController] OnPlayerAttach");
    this.m_playerObject = playerPuppet;
    this.m_playerPuppet = playerPuppet;
    this.m_gameInstance = playerPuppet.GetGame();
    // this.UpdateTime();
    this.m_vehicleBlackboard = FlightSystem.GetInstance().playerComponent.GetVehicle().GetBlackboard();
    this.m_vehicleFlightBlackboard = FlightController.GetInstance().GetBlackboard();
    this.m_scannerBlackboard = GameInstance.GetBlackboardSystem(this.m_gameInstance).Get(GetAllBlackboardDefs().UI_Scanner);
    this.RegisterBB();
    this.UpdateCrosshairVisibility();
    this.ActivateUI(this.IsUIactive() && this.IsActive());
  }

  protected func RegisterBB() {
    // this.m_bbPlayerStats = this.GetBlackboardSystem().Get(GetAllBlackboardDefs().UI_PlayerBioMonitor);
    // this.m_bbPlayerEventId = this.m_bbPlayerStats.RegisterListenerVariant(GetAllBlackboardDefs().UI_PlayerBioMonitor.PlayerStatsInfo, this, n"OnStatsChanged");    
    // this.m_psmBlackboard = this.GetPSMBlackboard(this.m_playerPuppet);
    // if IsDefined(this.m_psmBlackboard) {
    //   this.m_PSM_BBID = this.m_psmBlackboard.RegisterDelayedListenerFloat(GetAllBlackboardDefs().PlayerStateMachine.ZoomLevel, this, n"OnZoomChange");
    // };

    if IsDefined(this.m_vehicleFlightBlackboard) {
      if !IsDefined(this.m_vehicleBBUIActivId) {
        this.m_vehicleBBUIActivId = this.m_vehicleFlightBlackboard.RegisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive, this, n"OnActivateUI");
      }
      if !IsDefined(this.m_vehicleBBActivId) {
        this.m_vehicleBBActivId = this.m_vehicleFlightBlackboard.RegisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsActive, this, n"OnActivate");
      };
      if !IsDefined(this.m_vehicleBBModeId) {
        this.m_vehicleBBModeId = this.m_vehicleFlightBlackboard.RegisterListenerInt(GetAllBlackboardDefs().VehicleFlight.Mode, this, n"OnModeChange");
      };
      if !IsDefined(this.m_vehicleRollID) {
        this.m_vehicleRollID = this.m_vehicleFlightBlackboard.RegisterListenerFloat(GetAllBlackboardDefs().VehicleFlight.Roll, this, n"OnVehicleRollChanged");
      };
      if !IsDefined(this.m_vehiclePitchID) {
        this.m_vehiclePitchID = this.m_vehicleFlightBlackboard.RegisterListenerFloat(GetAllBlackboardDefs().VehicleFlight.Pitch, this, n"OnVehiclePitchChanged");
      };
      if !IsDefined(this.m_mountedCombatID) {
        this.m_mountedCombatID = this.m_vehicleFlightBlackboard.RegisterListenerBool(GetAllBlackboardDefs().VehicleFlight.InMountedVehicleCombat, this, n"OnMountedCombatChanged");
      };
    };
    this.m_tppBBConnectionId = GameInstance.GetBlackboardSystem(this.m_gameInstance).Get(GetAllBlackboardDefs().UI_ActiveVehicleData).RegisterListenerBool(GetAllBlackboardDefs().UI_ActiveVehicleData.IsTPPCameraOn, this, n"OnCameraModeChanged");
    this.OnCameraModeChanged(GameInstance.GetBlackboardSystem(this.m_gameInstance).Get(GetAllBlackboardDefs().UI_ActiveVehicleData).GetBool(GetAllBlackboardDefs().UI_ActiveVehicleData.IsTPPCameraOn));
    if IsDefined(this.m_scannerBlackboard) && !IsDefined(this.m_uiScannerVisibleCallbackID) {
      this.m_uiScannerVisibleCallbackID = this.m_scannerBlackboard.RegisterListenerBool(GetAllBlackboardDefs().UI_Scanner.UIVisible, this, n"OnScannerUIVisibleChanged");
    };
  }

  protected func UnregisterBB() {
    // if IsDefined(this.m_bbPlayerStats) {
      // this.m_bbPlayerStats.UnregisterListenerVariant(GetAllBlackboardDefs().UI_PlayerBioMonitor.PlayerStatsInfo, this.m_bbPlayerEventId);
    // };
    // if IsDefined(this.m_psmBlackboard) && IsDefined(this.m_PSM_BBID) {
    //   this.m_psmBlackboard.UnregisterDelayedListener(GetAllBlackboardDefs().PlayerStateMachine.ZoomLevel, this.m_PSM_BBID);
    // };
    if IsDefined(this.m_vehicleFlightBlackboard) {
      if IsDefined(this.m_vehicleBBUIActivId) {
        this.m_vehicleFlightBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsUIActive, this.m_vehicleBBUIActivId);
      }
      if IsDefined(this.m_vehicleBBActivId) {
        this.m_vehicleFlightBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().VehicleFlight.IsActive, this.m_vehicleBBActivId);
      };
      if IsDefined(this.m_vehicleBBModeId) {
        this.m_vehicleFlightBlackboard.UnregisterListenerInt(GetAllBlackboardDefs().VehicleFlight.Mode, this.m_vehicleBBModeId);
      };
      if IsDefined(this.m_vehicleRollID) {
        this.m_vehicleFlightBlackboard.UnregisterListenerFloat(GetAllBlackboardDefs().VehicleFlight.Roll, this.m_vehicleRollID);
      };
      if IsDefined(this.m_vehiclePitchID) {
        this.m_vehicleFlightBlackboard.UnregisterListenerFloat(GetAllBlackboardDefs().VehicleFlight.Pitch, this.m_vehiclePitchID);
      };
    }
    if IsDefined(this.m_tppBBConnectionId) {
      GameInstance.GetBlackboardSystem(this.m_gameInstance).Get(GetAllBlackboardDefs().UI_ActiveVehicleData).UnregisterListenerBool(GetAllBlackboardDefs().UI_ActiveVehicleData.IsTPPCameraOn, this.m_tppBBConnectionId);
    }
    if IsDefined(this.m_scannerBlackboard) {
      if IsDefined(this.m_uiScannerVisibleCallbackID) {
        this.m_scannerBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().UI_Scanner.UIVisible, this.m_uiScannerVisibleCallbackID);
      }
    }
  }

  protected cb func OnPlayerDetach(playerPuppet: ref<GameObject>) -> Bool {
    FlightLog.Info("[hudFlightController] OnPlayerDetach");
    this.UnregisterBB();
  }

  // protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
  //   let yaw: Float = ClampF(this.m_playerPuppet.GetWorldYaw(), -300.00, 300.00);
  //   inkTextRef.SetText(this.m_yawFluff, ToString(yaw));
  //   inkTextRef.SetText(this.m_pitchFluff, ToString(yaw * 1.50));
  //   inkWidgetRef.SetMargin(this.m_leftPart, new inkMargin(yaw, this.offsetLeft, 0.00, 0.00));
  //   inkWidgetRef.SetMargin(this.m_rightPart, new inkMargin(this.offsetRight, yaw, 0.00, 0.00));
  //   this.UpdateTime();
  // }
  
  protected cb func OnZoomChange(evt: Float) -> Bool {
    // if evt > this.m_currentZoom {
    //     this.PlayLibraryAnimation(n"zoomUp");
    // } else {
    //     this.PlayLibraryAnimation(n"zoomDown");
    // }
    // this.m_currentZoom = evt;
  }

  protected cb func OnIntroComplete(anim: ref<inkAnimProxy>) -> Bool {
    // GameInstance.GetAudioSystem(this.GetPlayerControlledObject().GetGame()).Play(n"ui_main_menu_cc_loading");
  }
  protected cb func OnOutroComplete(anim: ref<inkAnimProxy>) -> Bool {
      // this.GetRootWidget().SetVisible(false);
  }

  protected cb func OnStatsChanged(value: Variant) -> Bool {
    // let incomingData: PlayerBioMonitor = FromVariant<PlayerBioMonitor>(value);
    // this.m_previousHealth = this.m_currentHealth;
    // this.m_maximumHealth = incomingData.maximumHealth;
       
   
    // this.m_currentHealth = CeilF(GameInstance.GetStatPoolsSystem(this.m_playerObject.GetGame()).GetStatPoolValue(Cast<StatsObjectID>(GetPlayer(this.m_playerObject.GetGame()).GetEntityID()), gamedataStatPoolType.Health, false));
    // this.m_currentHealth = Clamp(this.m_currentHealth, 0, this.m_maximumHealth);
  }

  protected cb func OnScannerUIVisibleChanged(visible: Bool) -> Bool {
    if this.IsUIactive() && this.IsActive() {
      this.ActivateUI(!visible);
    }
  }

  public func ReactToHPChange(value: Float) -> Void {
    inkTextRef.SetText(this.healthStatus, IntToString(RoundF(value)) + "/100");
    inkWidgetRef.SetMargin(this.m_hp_mask, new inkMargin(-1720.0 - ((100.0 - value) * 9.0), 826.66638183, 0, 0));
  }

  protected cb func OnDelayedHUDInitializeEvent(evt: ref<DelayedHUDInitializeEvent>) -> Bool {
    // TakeOverControlSystem.CreateInputHint(this.GetPlayerControlledObject().GetGame(), true);
    // SecurityTurret.CreateInputHint(this.GetPlayerControlledObject().GetGame(), true);
  }

  public final func PlayAnim(animName: CName, opt callBack: CName, opt animOptions: inkAnimOptions) -> Void {
    if IsDefined(this.m_animationProxy) && this.m_animationProxy.IsPlaying() {
      this.m_animationProxy.Stop(true);
    };
    this.m_animationProxy = this.PlayLibraryAnimation(animName, animOptions);
    if NotEquals(callBack, n"") {
      this.m_animationProxy.RegisterToCallback(inkanimEventType.OnFinish, this, callBack);
    };
  }

  private final func UpdateJohnnyThemeOverride(value: Bool) -> Void {
    let uiSystem: ref<UISystem>;
    let controlledPuppet: wref<gamePuppetBase> = GetPlayer(this.m_gameInstance);
    if IsDefined(controlledPuppet) && controlledPuppet.IsJohnnyReplacer() {
      uiSystem = GameInstance.GetUISystem(this.m_gameInstance);
      if IsDefined(uiSystem) {
        if value {
          uiSystem.SetGlobalThemeOverride(n"Johnny");
        } else {
          uiSystem.ClearGlobalThemeOverride();
        };
      };
    };
  }
}


// Utils/FlightUtils.reds

public class FlightUtils {
    public static func SqrtCurve(input: Float) -> Float {
        if input != 0.0 {
            return SqrtF(AbsF(input)) * AbsF(input) / input;
        } else {
            return 0.0;
        }
    }
    public static func IdentCurve(input: Float) -> Float {
        return input;
    }

    public static func Right() -> Vector4 = new Vector4(1.0, 0.0, 0.0, 0.0);
    public static func Left() -> Vector4 = new Vector4(-1.0, 0.0, 0.0, 0.0);
    public static func Forward() -> Vector4 = new Vector4(0.0, 1.0, 0.0, 0.0);
    public static func Backward() -> Vector4 = new Vector4(0.0, -1.0, 0.0, 0.0);
    public static func Up() -> Vector4 = new Vector4(0.0, 0.0, 1.0, 0.0);
    public static func Down() -> Vector4 = new Vector4(0.0, 0.0, -1.0, 0.0);
    
	public static func ElectricBlue() -> HDRColor = new HDRColor(0.368627, 0.964706, 1.0, 1.0)
	public static func Bittersweet() -> HDRColor = new HDRColor(1.1761, 0.3809, 0.3476, 1.0)
	public static func Dandelion() -> HDRColor = new HDRColor(1.1192, 0.8441, 0.2565, 1.0)
	public static func LightGreen() -> HDRColor = new HDRColor(0.113725, 0.929412, 0.513726, 1.0)
	public static func BlackPearl() -> HDRColor = new HDRColor(0.054902, 0.054902, 0.090196, 1.0)

	public static func RedOxide() -> HDRColor = new HDRColor(0.411765, 0.086275, 0.090196, 1.0)
	public static func Bordeaux() -> HDRColor = new HDRColor(0.262745, 0.086275, 0.094118, 1.0)

	public static func PureBlack() -> HDRColor = new HDRColor(0.0, 0.0, 0.0, 1.0)
	public static func PureWhite() -> HDRColor = new HDRColor(1.0, 1.0, 1.0, 1.0)
}

// Utils/OperatorHelpers.reds

// Vector3 Wrapper (IScriptable-derived)

public class Vector3Wrapper {
  public let vector: Vector3;
  public static func Create(v: Vector3) -> ref<Vector3Wrapper> {
    let vw = new Vector3Wrapper();
    vw.vector = v;
    return vw;
  }
}

// Matrix

public static func OperatorMultiply(m: Matrix, v: Vector4) -> Vector4 {
  return Vector4.Transform(m, v);
}
public static func OperatorMultiply(v: Vector4, m: Matrix) -> Vector4 {
  return m * v;
}

public static func OperatorAssignMultiply(out v: Vector4, m: Matrix) -> Vector4 {
  v = m * v;
  return v;
}

// Quaternion

public static func OperatorXor(q: Quaternion, n: Int32) -> Quaternion {
  let out = q;
  while (n > 0) {
    Quaternion.SetInverse(out);
    n -= 1;
  }
  return out;
}

// EulerAngles

public static func MakeEulerAngles(Pitch: Float, Yaw: Float, Roll: Float) -> EulerAngles {
  let ea = new EulerAngles();
  ea.Roll = Roll;
  ea.Pitch = Pitch;
  ea.Yaw = Yaw;
  return ea;
}

public static func Cast(a: EulerAngles) -> Vector4 {
  let v = Vector4.EmptyVector();
  v.X = a.Pitch;
  v.Y = a.Roll;
  v.Z = a.Yaw;
  return v;
}

public static func Cast(a: EulerAngles) -> WorldTransform {
  let wt = new WorldTransform();
  WorldTransform.SetOrientation(wt, EulerAngles.ToQuat(a));
  return wt;
}

public static func OperatorMultiply(e: EulerAngles, f: Float) -> EulerAngles {
  let out = e;
  e.Roll *= f;
  e.Yaw *= f;
  e.Pitch += f;
  return out;
}

public static func OperatorAssignMultiply(out e: EulerAngles, f: Float) -> EulerAngles {
  e = e * f;
  return e;
}

public static func OperatorDivide(e: EulerAngles, f: Float) -> EulerAngles {
  let out = e;
  e.Roll /= f;
  e.Yaw /= f;
  e.Pitch /= f;
  return out;
}

public static func OperatorAdd(e: EulerAngles, v: Vector4) -> Vector4 {
  let out = v;
  v.X += e.Pitch;
  v.Y += e.Roll;
  v.Z += e.Yaw;
  return out;
}

public static func OperatorAdd(v: Vector4, e: EulerAngles) -> Vector4 {
  return e + v;
}

public static func OperatorAssignAdd(out v: Vector4, e: EulerAngles) -> Vector4 {
  v = e + v;
  return v;
}

// Vector3

public static func OperatorAdd(a: Vector4, b: Vector3) -> Vector4 {
  return a + Vector4.Vector3To4(b);
}

// FxResource

public static native func ResRefToFxResource(a: ResRef) -> FxResource;


public static func OperatorEqual(a: Vector3, b: Vector3) -> Bool {
  return a.X == b.X && a.Y == b.Y && a.Z == b.Z;
}

public static func OperatorEqual(a: Vector4, b: Vector4) -> Bool {
  return a.X == b.X && a.Y == b.Y && a.Z == b.Z && a.W == b.W;
}

public static func OperatorNotEqual(a: Vector3, b: Vector3) -> Bool {
  return !OperatorEqual(a, b);
}

public static func OperatorNotEqual(a: Vector4, b: Vector4) -> Bool {
  return !OperatorEqual(a, b);
}


// Utils/PID.reds

public class PID {
  private let valueFloat: Float;
  // private let valueVector: Vector4;
  private let inputFloat: Float;
  // private let inputVector: Vector4;
  private let P: Float;
  private let I: Float;
  private let D: Float;
  public let integralFloat: Float;
  // private let integralVector: Vector4;
  private let lastErrorFloat: Float;
  // private let lastErrorVector: Vector4;
  public static func Create(P: Float, I: Float, D: Float) -> ref<PID> {
    let instance: ref<PID> = new PID();
    instance.P = P;
    instance.I = I;
    instance.D = D;
    instance.Reset();
    return instance;
  }
  public static func Create(v: Vector3) -> ref<PID> {
    return PID.Create(v.X, v.Y, v.Z);
  }
  public static func Create(P: Float, I: Float, D: Float, initialValue: Float) -> ref<PID> {
    let instance: ref<PID> = PID.Create(P, I, D);
    instance.valueFloat = initialValue;
    return instance;
  }
  // public static func Create(P: Float, I: Float, D: Float, initialValue: Vector4) -> ref<PID> {
  //   let instance: ref<PID> = PID.Create(P, I, D);
  //   instance.valueVector = initialValue;
  //   return instance;
  // }
  public func Update(P: Float, I: Float, D: Float) -> Void {
    this.P = P;
    this.I = I;
    this.D = D;
  }
  
  public func UpdateP(P: Float) -> Void {
    this.P = P;
  }
  
  public func UpdateI(I: Float) -> Void {
    this.I = I;
  }

  public func UpdateD(D: Float) -> Void {
    this.D = D;
  }

  public func SetInput(input: Float) {
    this.inputFloat = input;
  }
  // public func SetInput(input: Vector4) {
  //   this.inputVector = input;
  // }
  public func GetValue(timeDelta: Float) -> Float {
    let error: Float = this.inputFloat - this.valueFloat;
    this.valueFloat += this.GetCorrection(error, timeDelta);
    return this.valueFloat;
  } 
  public func GetValue() -> Float {
    return this.valueFloat;
  } 
  public func GetInput() -> Float {
    return this.inputFloat;
  }
  // public func GetValue(timeDelta: Float) -> Vector4 {
  //   let error: Vector4 = this.inputVector - this.valueVector;
  //   this.valueVector += this.GetCorrection(error)
  //   return this.valueVector;
  // }
  public func GetValue(input: Float, timeDelta: Float) -> Float {
    this.SetInput(input);
    return this.GetValue(timeDelta);
  }
  // public func GetValue(input: Vector4, timeDelta: Float) -> Vector4 {
  //   this.SetInput(input);
  //   return GetValue(timeDelta);
  // }
  public func GetCorrection(error: Float, timeDelta: Float) -> Float { 
    let derivative: Float = (error - this.lastErrorFloat) / timeDelta;
    // if error < 0.01 || error * this.lastErrorFloat < 0.0 {
    //   this.integralFloat = 0.0;
    // } else {
    this.integralFloat = ClampF(error * timeDelta + this.integralFloat, -100.0, 100.0);
    // }
    this.lastErrorFloat = error;
    return this.P * error + this.I * this.integralFloat + this.D * derivative;
  }
  // public func GetCorrection(error: Vector4, timeDelta: Float) -> Vector4 { 
  //   let derivative: Vector4 = (error - this.lastErrorVector) / timeDelta;
  //   this.integralVector = Vector4.ClampLength(error * timeDelta + this.integralVector, -100.0, 100.0);
  //   this.lastErrorVector = error;
  //   return this.P * error + this.I * this.integralFloat + this.D * derivative;
  // }
  public func GetCorrectionClamped(error: Float, timeDelta: Float, clamp: Float) -> Float {
    return ClampF(this.GetCorrection(error, timeDelta), -clamp, clamp);
  }
  public func Reset(opt input: Float) -> Void {
    this.inputFloat = input;
    this.integralFloat = 0.0;
    this.lastErrorFloat = 0.0;
  }
}

public class InputPID extends PID {
  private let P_dec: Float;
  public static func Create(P: Float, P_dec: Float) -> ref<InputPID> {
    let instance: ref<InputPID> = new InputPID();
    instance.P = P;
    instance.P_dec = P_dec;
    instance.Reset();
    return instance;
  }

  public func UpdatePd(Pd: Float) -> Void {
    this.P_dec = Pd;
  }

  public func GetCorrection(error: Float, timeDelta: Float) -> Float { 
    if AbsF(this.inputFloat) > AbsF(this.valueFloat) || this.inputFloat * this.valueFloat < 0.0 {
      return this.P * error;
    } else {
      return this.P_dec * error;
    }
  }
}

public class DualPID extends PID {
  private let P_aux: Float;
  private let I_aux: Float;
  private let D_aux: Float;
  private let ratio: Float;
  public static func Create(P: Float, I: Float, D: Float, P_aux: Float, I_aux: Float, D_aux: Float) -> ref<DualPID> {
    let instance: ref<DualPID> = new DualPID();
    instance.P = P;
    instance.I = I;
    instance.D = D;
    instance.P_aux = P_aux;
    instance.I_aux = I_aux;
    instance.D_aux = D_aux;
    instance.Reset();
    return instance;
  }
  public static func Create(P: Float, I: Float, D: Float, P_aux: Float, I_aux: Float, D_aux: Float, initialValue: Float) -> ref<DualPID> {
    let instance: ref<DualPID> = DualPID.Create(P, I, D, P_aux, I_aux, D_aux);
    instance.valueFloat = initialValue;
    return instance;
  }
  public func SetRatio(ratio: Float) {
    this.ratio = ratio;
  }
  public func GetCorrection(error: Float, timeDelta: Float) -> Float { 
    let derivative: Float = (error - this.lastErrorFloat) / timeDelta;
    // if error < 0.01 || error * this.lastErrorFloat < 0.0 {
    //   this.integralFloat = 0.0;
    // } else {
    this.integralFloat = ClampF(error * timeDelta + this.integralFloat, -100.0, 100.0) * 0.95;
    // }
    this.lastErrorFloat = error;
    let pri = this.P * error + this.I * this.integralFloat + this.D * derivative;
    let aux = this.P_aux * error + this.I_aux * this.integralFloat + this.D_aux * derivative;
    return pri * (1.0 - this.ratio) + aux * (this.ratio);
  }
  public func UpdateAux(P_aux: Float, I_aux: Float, D_aux: Float) -> Void {
    this.P_aux = P_aux;
    this.I_aux = I_aux;
    this.D_aux = D_aux;
  }
}

