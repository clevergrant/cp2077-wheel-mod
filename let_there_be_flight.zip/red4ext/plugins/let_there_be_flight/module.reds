module LetThereBeFlight

public func GetVersionString() -> String {
  return "v0.3.17";
}

public func GetVersion() -> Int32 {
  return 0 * 10000 + 3 * 100 + 17;
}
